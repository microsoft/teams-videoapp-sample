# How to use the test app?

1. Ensure you are in Windows, and your computer has a camera. Use OBS virtual camera if you don't have a camera.
2. Run `vxTestApp.exe`.
3. After the application is opened, a camera is selected by default. You can change the camera via the dropdown.
4. Input your video app's url. Deploying the video app in https server is preferred.
5. Click `Load`. The sample app will be loaded if the `Video app url` is blank.

# How to test performance?

1. Load video app following commands in the above section.
2. To evaluate processing time, click `Real-time Evaluation` or `Full Evaluation` under `Time per Frame'. 
    - `Real-time Evaluation` logs the average and range of processing time in millisecond in each second.
    - `Full Evaluation` logs both the processing time and the distribution of processing time.
3. To evaluate memory usage, click `Real-time Evaluation` or `Full Evaluation` under `Memory Usage'. 
    - `Real-time Evaluation` logs the average and range of both active heap size and total heap size for each frame.
    - `Full Evaluation` logs both the heap size and the distribution of heap size.
4. To test video app under different resolutions, select another value of the resolution dropdown. 

# How to change to your own video app?

1. Input your video app's url.
2. Click `Load`. This will destroy current video app and load a new one with the app url.

# FAQ
## How to change camera resolution?

We can change the video frame resolution by changing this configuration file: `%appdata%\Roaming\Microsoft\electron\SkypeRT\persistent.conf`

Please append the following key-value to the json file: `"RtmCodecsConfig": {"MinVideoSourceResolution":"83886800", "MaxVideoSourceResolution":"83886800"}`

Here are the allowed number corresponding to specific resolution:

```
(640, 360)   = 0x02800168 = 41943400
(1280, 720)  = 0x050002D0 = 83886800
(1920, 1080) = 0x07800438 = 125830200
```

After saving the persistent.conf, restart the test-app, it should grab video frame from camera with the given resolution.
 
The RtmCodecsConfig key-value will be removed every time restarting the test-app, it's expected. But the resolution will be remembered in the test-app future running.

## There's no device shown in the camera device dropdown.

1. Make sure your camera has been plugged into your computer.
2. Delete `%appdata%\Microsoft\electron`

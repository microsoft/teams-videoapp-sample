/// <reference path="../../deps/electron/electron.d.ts" />

declare namespace Electron {
  interface WebContentsOptions extends WebPreferences {
    isBackgroundPage?: boolean;
  }

  class WebContentsEx extends WebContents {
    static create(options: WebContentsOptions): WebContentsEx;

    destroy(): void;
  }
}

declare namespace NodeJS {
  interface V8UtilBinding {
    getHiddenValue<T>(obj: Object, key: string): T;
    lowMemoryNotification(): void;
  }

  interface Process {
    electronBinding(name: 'v8_util'): V8UtilBinding;
  }
}

import { EventEmitter } from 'events';

export class IpcEventEmitter extends EventEmitter
{
    public constructor(private _webContents: Electron.WebContents)
    {
        super();

        this._webContents.on('ipc-message', this._handler);
        this._webContents.on('ipc-message-sync', this._handler);
    }

    public destroy()
    {
        if (this._webContents) {
            this._webContents.removeListener('ipc-message', this._handler);
            this._webContents.removeListener('ipc-message-sync', this._handler);
            this._webContents = undefined;
        }
    }

    private _handler = (event: Electron.Event, channel: string, ...args: any[]) => {
        this.emit(channel, event, ...args);
    }
}

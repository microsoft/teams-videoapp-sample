"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
function isMac() {
    return process.platform === 'darwin';
}
const appMenu = {
    label: 'Electron',
    submenu: [
        {
            role: 'about',
        },
        {
            type: 'separator',
        },
        {
            role: 'services',
            submenu: [],
        },
        {
            type: 'separator',
        },
        {
            role: 'hide',
        },
        {
            role: 'hideOthers',
        },
        {
            role: 'unhide',
        },
        {
            type: 'separator',
        },
        {
            role: 'quit',
        },
    ],
};
const fileMenu = {
    label: 'File',
    submenu: [
        {
            role: 'quit',
        }
    ],
};
const editMenu = {
    label: 'Edit',
    submenu: [
        {
            role: 'undo',
        },
        {
            role: 'redo',
        },
        {
            type: 'separator',
        },
        {
            role: 'cut',
        },
        {
            role: 'copy',
        },
        {
            role: 'paste',
        },
        {
            role: 'pasteAndMatchStyle',
        },
        {
            role: 'delete',
        },
        {
            role: 'selectAll',
        },
    ],
};
const viewMenu = {
    label: 'View',
    submenu: [
        {
            role: 'reload',
        },
        {
            role: 'forceReload',
        },
        {
            role: 'toggleDevTools',
        },
        {
            type: 'separator',
        },
        {
            role: 'resetZoom',
        },
        {
            role: 'zoomIn',
        },
        {
            role: 'zoomOut',
        },
        {
            type: 'separator',
        },
        {
            role: 'togglefullscreen',
        },
    ],
};
const windowMenu = {
    role: 'window',
    submenu: isMac()
        ? [
            {
                role: 'close',
            },
            {
                role: 'minimize',
            },
            {
                role: 'zoom',
            },
            {
                type: 'separator',
            },
            {
                role: 'front',
            },
        ]
        : [
            {
                role: 'minimize',
            },
            {
                role: 'close',
            },
        ],
};
const helpMenu = {
    role: 'help',
    submenu: [
        {
            label: 'Electron',
            click() {
                electron_1.shell.openExternal('https://electronjs.org');
            },
        },
        {
            label: 'SlimCoreElectron',
            click() {
                electron_1.shell.openExternal('https://skype.visualstudio.com/DefaultCollection/SCC/_git/client-shared_electron_slimcore');
            },
        },
        {
            type: 'separator',
        },
        {
            label: 'Open userData path',
            click() {
                electron_1.shell.openPath(electron_1.app.getPath('userData'));
            },
        },
    ],
};
exports.menu = electron_1.Menu.buildFromTemplate([
    isMac() ? appMenu : fileMenu,
    editMenu,
    viewMenu,
    windowMenu,
    helpMenu,
]);
//# sourceMappingURL=menu.js.map
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const electron_1 = require("electron");
function defer() {
    let resolve;
    let reject;
    // tslint:disable-next-line: promise-must-complete
    const promise = new Promise((resolveFn, rejectFn) => {
        resolve = resolveFn;
        reject = rejectFn;
    });
    return { promise, resolve, reject };
}
exports.defer = defer;
function log(...args) {
    console.log((new Date()).toISOString(), ...args);
}
exports.log = log;
function getPreloadPath(filename, sandbox = false) {
    const pathObject = path.parse(getAppFilePath(filename));
    return path.format({
        dir: pathObject.dir,
        name: `${pathObject.name}${sandbox ? '-bundle' : ''}`,
        ext: pathObject.ext,
    });
}
exports.getPreloadPath = getPreloadPath;
function getAppFilePath(filename) {
    return path.resolve(electron_1.app.getAppPath(), filename);
}
exports.getAppFilePath = getAppFilePath;
function getUserDataPath(filename) {
    return path.resolve(electron_1.app.getPath('userData'), filename);
}
exports.getUserDataPath = getUserDataPath;
function handleSync(emitter, channel, handler) {
    emitter.on(channel, (event, ...args) => __awaiter(this, void 0, void 0, function* () {
        try {
            event.returnValue = [null, yield handler(event, ...args)];
        }
        catch (error) {
            event.returnValue = [error];
        }
    }));
}
exports.handleSync = handleSync;
//# sourceMappingURL=utils.js.map
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const fs = require("fs");
const events_1 = require("events");
const sharing_indicator_1 = require("slimcore/lib/sharing-indicator");
const native_renderer_1 = require("slimcore/lib/native-renderer");
const plugin_host_1 = require("./plugin-host");
const ipc_event_emitter_1 = require("./ipc-event-emitter");
const utils = require("./utils");
const kInitPluginHostTimeout = 1000 * 10;
class MainWindow extends events_1.EventEmitter {
    constructor(args) {
        super();
        this._window = null;
        this._ipc = null;
        this._pluginHost = null;
        this._sharingIndicator = null;
        this._nativeRenderer = null;
        this._nextPopupId = 1;
        this._compositorWindow = null;
        if (!args.isVideoExtensibilityTestApp) {
            this._window = new electron_1.BrowserWindow({
                title: args.title,
                webPreferences: {
                    preload: utils.getPreloadPath('src/renderer/main-window/preload.js', args.enableSandbox),
                    allowVideoRendererInSandbox: true,
                    worldSafeExecuteJavaScript: true,
                    contextIsolation: args.enableContextIsolation,
                    sandbox: args.enableSandbox,
                    additionalArguments: ['--ms-renderer-type=main-window'],
                },
            });
        }
        else {
            electron_1.ipcMain.on('video.sendMessagePortToMainWindow', (event) => {
                const [port] = event.ports;
                this._window.webContents.postMessage('video.sendMessagePortToMainWindow', null, [port]);
            });
            this._window = new electron_1.BrowserWindow({
                title: args.title,
                width: 1200,
                height: 900,
                webPreferences: {
                    preload: utils.getPreloadPath('src/renderer/video-extensibility/preload.js', args.enableSandbox),
                    allowVideoRendererInSandbox: true,
                    worldSafeExecuteJavaScript: true,
                    contextIsolation: false,
                    sandbox: args.enableSandbox,
                    webviewTag: true,
                    additionalArguments: ['--ms-renderer-type=main-window'],
                },
            });
            this._window.webContents.on('will-attach-webview', (e, webPreferences, ps) => {
                webPreferences.preload = utils.getPreloadPath('src/renderer/video-extensibility/videoapp/preload.js', true);
                webPreferences.contextIsolation = true;
                webPreferences.allowVideoRendererInSandbox = true;
                webPreferences.allowVideoExtensibilityInSandbox = true;
                webPreferences.sandbox = true;
                webPreferences.worldSafeExecuteJavaScript = true;
                webPreferences.additionalArguments = ['--enable-precise-memory-info'];
            });
        }
        this._ipc = new ipc_event_emitter_1.IpcEventEmitter(this._webContents);
        utils.handleSync(this._ipc, 'get-options', () => {
            this._log('get-options');
            return this._getOptions(args);
        });
        utils.handleSync(this._ipc, 'get-preload-main-world', () => __awaiter(this, void 0, void 0, function* () {
            this._log('get-preload-main-world');
            return fs.promises.readFile(utils.getPreloadPath('src/renderer/main-window/preload-main-world.js', true), 'utf8');
        }));
        utils.handleSync(this._ipc, 'init-plugin-host', () => {
            this._log('init-plugin-host');
            return this._initPluginHost(args);
        });
        this._ipc.on('open-popup', (event, args) => {
            this._log('open-popup');
            event.returnValue = this._openPopup(args);
        });
        this._ipc.on('open-compositor', (event) => {
            this._log('open-compositor');
            this._openCompositor();
            event.returnValue = true;
        });
        this._ipc.on('open-native-compositor', (event) => {
            this._log('open-native-compositor');
            this._openNativeCompositor();
            this._log('leave event open-native-compositor');
            event.returnValue = true;
        });
        this._ipc.on('page-ready', (event) => {
            this._log('page-ready');
        });
        this._ipc.on('video-extensibility-ready', (event) => {
            this._log('video-extensibility-ready');
        });
        this._window.once('closed', () => {
            this._log('closed');
            this._window.removeAllListeners();
            this._window = null;
            this._ipc.removeAllListeners();
            this._ipc = null;
            this._hideSharingIndicator();
            this._destroyPluginHost();
            this.emit('closed');
        });
        this._webContents.on('render-process-gone', (event, details) => {
            this._log('render-process-gone', details);
            this._hideSharingIndicator();
            this._destroyPluginHost();
        });
        this._webContents.on('will-navigate', () => {
            this._log('will-navigate');
        });
        this._webContents.on('did-navigate', () => {
            this._log('did-navigate');
            this._hideSharingIndicator();
            this._destroyPluginHost();
            if (args.usePluginHost && args.preloadPluginHost) {
                try {
                    this._pluginHost = this._createPluginHost(args);
                }
                catch (error) {
                    this._log(`_createPluginHost failed: ${error}`);
                }
            }
        });
        this._webContents.on('did-finish-load', () => {
            this._log('did-finish-load');
        });
        this._webContents.on('did-fail-load', () => {
            this._log('did-fail-load');
        });
        this._ipc.on('native-renderer:start', (event, nativeHandle) => {
            this._log('_ipc.on(native-renderer:start)');
            if (this._nativeRenderer == null) {
                this._nativeRenderer = new native_renderer_1.NativeRenderer({
                    windowId: nativeHandle,
                });
            }
            event.returnValue = this._nativeRenderer.start();
        });
        this._ipc.on('native-renderer:stop', (event, nativeHandle) => {
            this._log('_ipc.on(native-renderer:stop)');
            if (this._nativeRenderer != null) {
                this._nativeRenderer.stop();
            }
        });
        this._ipc.on('sharing-indicator:show', (event, position) => {
            this._showSharingIndicator(position);
        });
        this._ipc.on('sharing-indicator:hide', (event) => {
            this._hideSharingIndicator();
        });
        this._ipc.on('sharing-indicator:setPosition', (event, position) => {
            if (this._sharingIndicator) {
                this._sharingIndicator.setPosition(position);
            }
        });
        this._ipc.on('sharing-indicator:setWindow', (event, windowId) => {
            if (this._sharingIndicator) {
                this._sharingIndicator.setWindow(windowId);
            }
        });
        this._ipc.on('sharing-indicator:displayVideoDeviceSetting', (event, deviceId) => {
            const parentWindowHandle = this._window.getNativeWindowHandle();
            if (sharing_indicator_1.displayVideoDeviceSetting) {
                sharing_indicator_1.displayVideoDeviceSetting(parentWindowHandle, deviceId);
            }
        });
        this._ipc.on('create-regular-renderer', (event, ...args) => {
            this._compositorWindow.webContents.send('create-regular-renderer', ...args);
        });
        this._ipc.on('create-compositor-renderer', (event, ...args) => {
            this._compositorWindow.webContents.send('create-compositor-renderer', ...args);
        });
        this._log('loadURL');
        if (args.openBlankPage) {
            this._window.loadURL('about:blank');
        }
        else if (args.isVideoExtensibilityTestApp) {
            this._window.loadFile('src/renderer/video-extensibility/index.html');
        }
        else {
            this._window.loadFile('src/renderer/main-window/index.html');
        }
        if (args.openMainWindowDevTools) {
            this._webContents.openDevTools();
        }
        this._handleDisplaysChanged();
    }
    get _webContents() {
        return this._window && this._window.webContents;
    }
    _getOptions(args) {
        return {
            usePluginHost: args.usePluginHost,
            enableTextureSharing: args.enableTextureSharing,
            enableTextureUpload: args.enableTextureUpload,
            enableWatchdog: args.enableWatchdog,
            pluginHostDirectChannel: args.pluginHostDirectChannel,
            pluginHostTracing: args.pluginHostTracing,
            pluginHostLatencyTracing: args.pluginHostLatencyTracing,
            pluginHostWatchdog: args.pluginHostWatchdog,
            slimcoreStdoutLogging: args.slimcoreStdoutLogging,
            slimcoreDataPath: utils.getUserDataPath('skylib'),
            slimcoreMediaLogsPath: utils.getUserDataPath('media-stack'),
            decoupledTrouterClient: args.decoupledTrouterClient,
            useTestAppSpecificECSPlatformID: args.useTestAppSpecificECSPlatformID,
        };
    }
    _createPluginHost(args) {
        return new plugin_host_1.PluginHost({
            enableWatchdog: args.enableWatchdog,
            enableTracing: args.pluginHostTracing,
            mainWindowId: this._webContents.id,
            openDevTools: args.openPluginHostDevTools,
        });
    }
    _initPluginHost(args) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this._pluginHost) {
                this._pluginHost = this._createPluginHost(args);
            }
            return this._pluginHost.waitForReady(kInitPluginHostTimeout);
        });
    }
    _destroyPluginHost() {
        if (this._pluginHost) {
            this._pluginHost.destroy();
            this._pluginHost = null;
        }
    }
    _showSharingIndicator(position) {
        this._hideSharingIndicator();
        this._sharingIndicator = new sharing_indicator_1.SharingIndicator({
            position: position,
            borderColor: { red: 1.0, green: 0.0, blue: 0.0, alpha: 1.0 },
            lineWidth: 5.0,
            modulePath: __dirname + '/../node_modules/slimcore',
        });
    }
    _hideSharingIndicator() {
        if (this._sharingIndicator) {
            this._sharingIndicator.dispose();
            this._sharingIndicator = null;
        }
    }
    _openPopup(args) {
        let popup = new electron_1.BrowserWindow({
            webPreferences: {
                preload: utils.getPreloadPath('src/renderer/popup/preload.js', true),
                additionalArguments: ['--ms-renderer-type=popup'],
                allowVideoRendererInSandbox: true,
                enableRemoteModule: false,
                contextIsolation: true,
                worldSafeExecuteJavaScript: true,
                sandbox: true,
            },
        });
        popup.loadFile('src/renderer/popup/index.html', {
            hash: JSON.stringify(args),
        });
        const popupId = this._nextPopupId++;
        let popupIpc = new ipc_event_emitter_1.IpcEventEmitter(popup.webContents);
        utils.handleSync(popupIpc, 'get-preload-main-world', () => __awaiter(this, void 0, void 0, function* () {
            return fs.promises.readFile(utils.getPreloadPath('src/renderer/popup/preload-main-world.js', true), 'utf8');
        }));
        popupIpc.on('frame-sink-invoke', (event, method, ...args) => {
            this._webContents.send(`frame-sink-invoke-${popupId}`, method, ...args);
        });
        popup.once('closed', () => {
            this._webContents.send(`popup-closed-${popupId}`);
            popup = null;
            popupIpc.removeAllListeners();
            popupIpc.destroy();
            popupIpc = null;
        });
        return popupId;
    }
    _openCompositor() {
        if (this._compositorWindow != null)
            return;
        this._compositorWindow = new electron_1.BrowserWindow({
            webPreferences: {
                preload: utils.getPreloadPath('src/renderer/compositor-test/preload.js', false),
                additionalArguments: ['--ms-renderer-type=compositor-test'],
                allowVideoRendererInSandbox: true,
                sandbox: false,
            },
        });
        this._compositorWindow.loadFile('src/renderer/compositor-test/index.html');
        let popupIpc = new ipc_event_emitter_1.IpcEventEmitter(this._compositorWindow.webContents);
        popupIpc.on('compositor-frame-sink-invoke', (event, bufferName, method, ...args) => {
            this._webContents.send(`compositor-frame-sink-invoke`, bufferName, method, ...args);
        });
        popupIpc.on('compositor-view-update', (event, bufferName, id, x, y, w, h) => {
            this._webContents.send('compositor-view-update', bufferName, id, x, y, w, h);
        });
        popupIpc.on('compositor-update', (event, w, h) => {
            this._webContents.send('compositor-update', 0, 0, w, h);
        });
        popupIpc.on('compositor-window-ready', (event) => {
            this._log(`compositor-window-ready ${this._compositorWindow.webContents}`);
            this._webContents.send('compositor-window-ready');
        });
        this._compositorWindow.once('closed', () => {
            this._webContents.send(`compositor-closed`);
            this._compositorWindow = null;
            popupIpc.removeAllListeners();
            popupIpc.destroy();
            popupIpc = null;
        });
    }
    _openNativeCompositor() {
        if (this._compositorWindow != null)
            return;
        this._compositorWindow = new electron_1.BrowserWindow({
            webPreferences: {
                preload: utils.getPreloadPath('src/renderer/native-compositor/preload.js', false),
                sandbox: false,
            },
            backgroundColor: '#00aaaaaa',
        });
        this._compositorWindow.loadFile('src/renderer/native-compositor/index.html');
        let popupIpc = new ipc_event_emitter_1.IpcEventEmitter(this._compositorWindow.webContents);
        popupIpc.on('compositor-view-update', (event, bufferName, id, x, y, w, h) => {
            this._webContents.send('compositor-view-update', bufferName, id, x, y, w, h);
        });
        popupIpc.on('compositor-update', (event, x, y, w, h) => {
            this._webContents.send('compositor-update', x, y, w, h);
        });
        popupIpc.on('compositor-window-ready', (event) => {
            this._log(`compositor-window-ready ${this._compositorWindow.webContents}`);
            this._webContents.send('compositor-window-ready', this._compositorWindow.getNativeWindowHandle());
        });
        this._compositorWindow.once('closed', () => {
            this._webContents.send(`compositor-closed`);
            this._compositorWindow = null;
            popupIpc.removeAllListeners();
            popupIpc.destroy();
            popupIpc = null;
        });
    }
    _handleDisplaysChanged() {
        const handleDisplaysChanged = () => {
            if (this._webContents) {
                this._webContents.send('displays-changed');
            }
        };
        electron_1.screen.on('display-added', handleDisplaysChanged);
        electron_1.screen.on('display-removed', handleDisplaysChanged);
        electron_1.screen.on('display-metrics-changed', handleDisplaysChanged);
    }
    _log(message, ...args) {
        utils.log(`MainWindow - ${message}`, ...args);
    }
}
exports.MainWindow = MainWindow;
//# sourceMappingURL=main-window.js.map
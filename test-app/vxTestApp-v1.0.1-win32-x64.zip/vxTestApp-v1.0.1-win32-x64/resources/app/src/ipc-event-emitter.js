"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
class IpcEventEmitter extends events_1.EventEmitter {
    constructor(_webContents) {
        super();
        this._webContents = _webContents;
        this._handler = (event, channel, ...args) => {
            this.emit(channel, event, ...args);
        };
        this._webContents.on('ipc-message', this._handler);
        this._webContents.on('ipc-message-sync', this._handler);
    }
    destroy() {
        if (this._webContents) {
            this._webContents.removeListener('ipc-message', this._handler);
            this._webContents.removeListener('ipc-message-sync', this._handler);
            this._webContents = undefined;
        }
    }
}
exports.IpcEventEmitter = IpcEventEmitter;
//# sourceMappingURL=ipc-event-emitter.js.map
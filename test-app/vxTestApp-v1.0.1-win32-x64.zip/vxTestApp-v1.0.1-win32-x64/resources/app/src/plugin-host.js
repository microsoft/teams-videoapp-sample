"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const ipc_event_emitter_1 = require("./ipc-event-emitter");
const utils = require("./utils");
const webContentsEx = electron_1.webContents;
class PluginHost {
    constructor(args) {
        this._webContents = null;
        this._ipc = null;
        this._webContents = webContentsEx.create({
            isBackgroundPage: true,
            enableRemoteModule: false,
            nodeIntegration: false,
            preload: utils.getPreloadPath('src/renderer/plugin-host/preload.js'),
            additionalArguments: ['--ms-renderer-type=plugin-host'],
        });
        if (args.openDevTools) {
            this._webContents.openDevTools();
        }
        this._ipc = new ipc_event_emitter_1.IpcEventEmitter(this._webContents);
        this._webContents.once('destroyed', () => {
            this._log('destroyed');
        });
        utils.handleSync(this._ipc, 'get-options', () => {
            this._log('get-options');
            return args;
        });
        this._webContents.on('render-process-gone', (event, details) => {
            this._log('render-process-gone', details);
        });
        this._webContents.on('will-navigate', (event) => {
            this._log('will-navigate');
            event.preventDefault();
        });
        this._webContents.on('did-navigate', () => {
            this._log('did-navigate');
        });
        const deferred = utils.defer();
        let ready = false;
        this._ipc.on('plugin-host-ready', () => {
            this._log('plugin-host-ready');
            ready = true;
        });
        this._webContents.on('did-finish-load', () => {
            this._log('did-finish-load');
            if (ready) {
                deferred.resolve(this._webContents.id);
            }
            else {
                deferred.reject(new Error('not ready'));
            }
        });
        this._webContents.on('did-fail-load', (event, errorCode, errorDescription) => {
            this._log(`did-fail-load: ${errorDescription}`);
            deferred.reject(new Error(errorDescription));
        });
        this._webContents.on('preload-error', (event, preloadPath, error) => {
            this._log(`preload-error: ${error}`);
            deferred.reject(error);
        });
        this._initPromise = deferred.promise;
        this._log('loadURL');
        this._webContents.loadURL('about:blank');
    }
    destroy() {
        this._log('destroy');
        if (this._webContents) {
            this._webContents.removeAllListeners();
            this._webContents.destroy();
            this._webContents = null;
        }
        if (this._ipc) {
            this._ipc.removeAllListeners();
            this._ipc.destroy();
            this._ipc = null;
        }
        this._initPromise = null;
    }
    waitForReady(timeout) {
        return new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => reject(new Error('timeout')), timeout);
            this._initPromise.then(resolve, reject).then(() => clearTimeout(timeoutId));
        });
    }
    _log(message, ...args) {
        utils.log(`PluginHost - ${message}`, ...args);
    }
}
exports.PluginHost = PluginHost;
//# sourceMappingURL=plugin-host.js.map
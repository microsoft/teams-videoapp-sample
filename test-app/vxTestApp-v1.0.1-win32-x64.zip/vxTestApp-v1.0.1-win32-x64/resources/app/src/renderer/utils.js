"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
exports.electronIpc = {
    send: electron_1.ipcRenderer.send.bind(electron_1.ipcRenderer),
    sendSync: electron_1.ipcRenderer.sendSync.bind(electron_1.ipcRenderer),
    on: electron_1.ipcRenderer.on.bind(electron_1.ipcRenderer),
    once: electron_1.ipcRenderer.once.bind(electron_1.ipcRenderer),
};
function invokeSync(command, ...args) {
    const [error, result] = electron_1.ipcRenderer.sendSync(command, ...args);
    if (error) {
        throw error;
    }
    else {
        return result;
    }
}
exports.invokeSync = invokeSync;
function executePreload(preload) {
    electron_1.webFrame.executeJavaScript(`(() => {${preload}})();`);
}
exports.executePreload = executePreload;
function createFrameSinkReaderImpl(bufferName) {
    const reader = new electron_1.FrameSinkReader();
    reader.on('log', (level, message) => {
        postMessage({ bufferName, level, message }, '*');
    });
    const processFrame = () => {
        const frame = reader.getFrame();
        if (frame !== undefined) {
            postMessage({ bufferName, frame }, '*');
        }
    };
    if (!reader.connect(bufferName, true)) {
        throw new Error('FrameSinkReader.prototype.connect() failed');
    }
    let handle;
    const tick = () => {
        processFrame();
        handle = requestAnimationFrame(tick);
    };
    if (reader.isNewFrameEventAvailable) {
        reader.on('new-frame', processFrame);
    }
    else {
        handle = requestAnimationFrame(tick);
    }
    return {
        dispose: () => {
            cancelAnimationFrame(handle);
            reader.disconnect();
        },
    };
}
exports.createFrameSinkReader = electron_1.FrameSinkReader ? createFrameSinkReaderImpl : undefined;
//# sourceMappingURL=utils.js.map
import * as electron from 'electron';
import { EventEmitter } from 'events';

function exposeModules()
{
    // tslint:disable-next-line:no-require-imports
    global['electronIpc'] = electron.ipcRenderer;
    global['EventEmitter'] = EventEmitter;
    global['exports'] = {};
}

if (location.origin === 'file://') {
    exposeModules();
}

console.log('pid', process.pid);

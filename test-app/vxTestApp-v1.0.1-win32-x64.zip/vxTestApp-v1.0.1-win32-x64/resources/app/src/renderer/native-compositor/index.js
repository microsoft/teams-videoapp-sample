"use strict";
/// <reference path="../../../../lib/slimcore.d.ts" />
/// <reference path="../../../../lib/video-renderer.d.ts" />
Object.defineProperty(exports, "__esModule", { value: true });
function getDpiAwareClientSize() {
    const w = Math.round(window.devicePixelRatio * document.documentElement.clientWidth);
    const h = Math.round(window.devicePixelRatio * document.documentElement.clientHeight);
    return { left: 10, top: 30, right: w - 20, bottom: h - 20, height: h, width: w };
}
document.addEventListener('DOMContentLoaded', () => {
    console.log(`compositor window loaded`);
    electronIpc.on(`create-compositor-renderer`, (event, bufferName, layout, count) => {
        const clientSize = getDpiAwareClientSize();
        electronIpc.send('compositor-update', clientSize.left, clientSize.top, clientSize.right, clientSize.bottom);
        console.log(`popup create-compositor-renderer`);
        for (let i = 0; i < 2; ++i) {
            electronIpc.send('compositor-view-update', '', i, 0, i * 360 / 2, 640, 360 / 2);
        }
        window.addEventListener('resize', (event) => {
            const clientSize = getDpiAwareClientSize();
            electronIpc.send('compositor-update', clientSize.left, clientSize.top, clientSize.right, clientSize.bottom);
        });
    });
    electronIpc.send('compositor-window-ready');
    console.log(`leaving compositor window loaded`);
});
//# sourceMappingURL=index.js.map
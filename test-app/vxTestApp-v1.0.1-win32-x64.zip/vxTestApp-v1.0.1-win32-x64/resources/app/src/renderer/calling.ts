import { CanvasVideoRenderer } from './canvas-video-renderer';
import { LatencyTracer } from './latency-tracer';
import { RemoteClient } from '../remote-host/remote-client';

// types
import { MainWindowOptions } from './ipc';
import { RemoteHostConnection } from '../remote-host/remote-client';

interface SlimCoreOptions extends MainWindowOptions {
    initPluginHost(): RemoteHostConnection;
}

function initPluginHostClient(options: SlimCoreOptions)
{
    const timeStart = performance.now();
    const host = options.initPluginHost();
    const duration = performance.now() - timeStart;

    const client = new RemoteClient(host, {
        enableDirectChannel: options.pluginHostDirectChannel,
        enableTracing: options.pluginHostTracing,
    });

    client.on('using-direct-channel-changed', (value: boolean) => {
        console.log('using-direct-channel-changed', value);
    });

    if (options.pluginHostLatencyTracing) {
        const latencyTracer = new LatencyTracer();
        latencyTracer.functionCall('initPluginHost', { duration });
        global['latencyTracer'] = latencyTracer;
        client.hooks = latencyTracer;
        client.require('ping');
    }

    return client;
}

let pluginHostClient: RemoteClient;

function requireEx(name: string, options: SlimCoreOptions)
{
    if (!options.usePluginHost) {
        return module.require(name);
    }

    pluginHostClient = pluginHostClient || initPluginHostClient(options);

    return pluginHostClient.require(name);
}

function setConstructorName(object: Object, name: string)
{
    object.constructor = () => { /* noop */ };
    Object.defineProperty(object.constructor, 'name', { value: name });
}

function loadSlimCore(options: SlimCoreOptions)
{
    const slimcore = requireEx('slimcore', options);
    setConstructorName(slimcore, 'SlimCoreElectron');

    return slimcore;
}

function defineGetter(target: Object, name: string, init: () => any)
{
    let value: any;

    Object.defineProperty(target, name, {
        get: () => value || (value = init()),
        enumerable: false,
        configurable: false,
    });
}

function initSlimCore(options: SlimCoreOptions)
{
    // https://domoreexp.visualstudio.com/Teamspace/_wiki/wikis/Teamspace.wiki/7258/Skype-Consumer-Client-IDs-(aka-Platform-IDs)
    const TEST_APP_PLATFORM_ID = 99005;

    if (!options.decoupledTrouterClient) {
        const slimcore = loadSlimCore(options);

        defineGetter(window, 'slimcore', () => {
            const platformId = options.useTestAppSpecificECSPlatformID ? TEST_APP_PLATFORM_ID : ((process.platform === 'darwin') ? 28 : 27);
            const logFileName = 'debug-' + new Date().getTime() + '.log';
            console.log(`Using platform id ${platformId}`);

            const slimCoreOptions = {
                version: `${platformId}/1.0.0.0/test/`,
                logFileName: logFileName,
                dataPath: options.slimcoreDataPath,
                mediaLogsPath: options.slimcoreMediaLogsPath,
                stdoutLogging: options.slimcoreStdoutLogging,
                isEncrypted: false,
            };

            const rtn = slimcore.createSlimCoreInstance(slimCoreOptions);
            rtn.setupSetStr('*Lib/ECS/Servers/1', 'https://config.teams.microsoft.com/config/v1/Teams/');
            return rtn;
        });

        return slimcore;
    } else {
        const platform = requireEx('slimcore/lib/platform', options);
        platform.init({
            logFilePath: `${options.slimcoreDataPath}/debug.log`,
            // The code above does isEncrypted: false, but it is not actually
            // taken into account inside SlimCore, so encrypt to behave the same
            logFileEncrypted: true,
            logToConsole: options.slimcoreStdoutLogging,
        });

        const trouterClient = requireEx('slimcore/lib/trouter-client', options);
        defineGetter(window, 'trouterclient', () => trouterClient);

        const slimcore = loadSlimCore(options);

        defineGetter(window, 'slimcore', () => {
            const platformId = options.useTestAppSpecificECSPlatformID ? TEST_APP_PLATFORM_ID : ((process.platform === 'darwin') ? 28 : 27);
            console.log(`Using platform id ${platformId}`);

            const slimCoreOptions = {
                version: `${platformId}/1.0.0.0/test/`,
                dataPath: options.slimcoreDataPath,
                skipRootToolsInit: true,
                externalTrouterClient: trouterClient.getNativeFunctions(),
            };

            const rtn = slimcore.createSlimCoreInstance(slimCoreOptions);
            rtn.setupSetStr('*Lib/ECS/Servers/1', 'https://config.teams.microsoft.com/config/v1/Teams/');
            return rtn;
        });

        return slimcore;
    }
}

export function exposeSlimCore(options: SlimCoreOptions)
{
    // tslint:disable-next-line:no-require-imports
    const videoRenderer = require('slimcore/lib/video-renderer');

    window['VideoRenderer'] = videoRenderer;
    window['CanvasVideoRenderer'] = CanvasVideoRenderer;

    defineGetter(window, 'SlimCore', () => initSlimCore(options));
}

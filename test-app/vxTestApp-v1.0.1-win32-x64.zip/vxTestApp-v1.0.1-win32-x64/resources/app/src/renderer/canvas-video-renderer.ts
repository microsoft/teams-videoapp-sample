/// <reference path="../../../lib/slimcore.d.ts" />
/// <reference path="../../../lib/video-renderer.d.ts" />

'use strict';

import { EventEmitter } from 'events';

declare const createFrameSinkReader: (bufferName: string) => SlimCore.Disposable;

import CropInfo = Electron.MSCropInfo;
import ImageInfo = Electron.MSImageInfo;
import VideoFrame = Electron.MSVideoFrame;

import ConstructorArgs = SlimCore.VideoRenderer.ConstructorArgs;
import ScalingMode = SlimCore.VideoRenderer.ScalingMode;
import LogLevel = SlimCore.FrameSink.LogLevel;
import Logger = SlimCore.VideoRenderer.Logger;

const SET_VIDEO_PREFERENCE_DEBOUNCE_TIMEOUT = 1000;

// -----------------------------------------------------------------------------

const VERTEX_SHADER =
`
    attribute vec4 position;
    attribute vec2 texCoord;

    varying vec2 v_texCoord;

    void main()
    {
        gl_Position = position;
        v_texCoord = texCoord;
    }
`;

const FRAGMENT_SHADER_COMMON =
`
    precision mediump float;
    varying vec2 v_texCoord;

    vec4 yuv2rgb(float y, float u, float v)
    {
        y = (y - 0.0625) * 1.164;
        u = u - 0.5;
        v = v - 0.5;

        float r = y             + 2.018 * v;
        float g = y - 0.391 * u - 0.813 * v;
        float b = y + 1.596 * u            ;

        return vec4(r, g, b, 1.0);
    }
`;

type TextureInfo = {
    data: ArrayBufferView;
    width: number;
    height: number;
    stride: number;
    format: number;
};

type FormatInfo = {
    mapping(gl: WebGLRenderingContext, frame: VideoFrame): TextureInfo[];
    shader: string;
};

const formats: { [key: string]: FormatInfo } =
{
    'BGRA':
    {
        'mapping': (gl: WebGLRenderingContext, frame: VideoFrame) =>
        {
            return [{
                'data': new Uint8Array(frame.data),
                'width': frame.info.width,
                'height': frame.info.height,
                'stride': frame.info.stride,
                'format': gl.RGBA,
            }];
        },
        'shader': `
            uniform sampler2D tex0;

            void main()
            {
                gl_FragColor = texture2D(tex0, v_texCoord).bgra;
            }
        `,
    },
    'I420':
    {
        'mapping': (gl: WebGLRenderingContext, frame: VideoFrame) =>
        {
            const width = frame.info.width;
            const height = frame.info.height;
            const stride = frame.info.stride;

            const offset0 = 0;
            const size0 = stride * height;

            const offset1 = offset0 + size0;
            const size1 = size0 / 4;

            const offset2 = offset1 + size1;
            const size2 = size0 / 4;

            return [{
                'data': new Uint8Array(frame.data, offset0, size0),
                'width': width,
                'height': height,
                'stride': stride,
                'format': gl.LUMINANCE,
            }, {
                'data': new Uint8Array(frame.data, offset1, size1),
                'width': width / 2,
                'height': height / 2,
                'stride': stride / 2,
                'format': gl.LUMINANCE,
            }, {
                'data': new Uint8Array(frame.data, offset2, size2),
                'width': width / 2,
                'height': height / 2,
                'stride': stride / 2,
                'format': gl.LUMINANCE,
            }];
        },
        'shader': `
            uniform sampler2D tex0;
            uniform sampler2D tex1;
            uniform sampler2D tex2;

            void main()
            {
                float y = texture2D(tex0, v_texCoord)[0];
                float u = texture2D(tex1, v_texCoord)[0];
                float v = texture2D(tex2, v_texCoord)[0];

                gl_FragColor = yuv2rgb(y, u, v);
            }
        `,
    },
    'NV12':
    {
        'mapping': (gl: WebGLRenderingContext, frame: VideoFrame) =>
        {
            const width = frame.info.width;
            const height = frame.info.height;
            const stride = frame.info.stride;

            const offset0 = 0;
            const size0 = stride * height;

            const offset1 = offset0 + size0;
            const size1 = size0 / 2;

            return [{
                'data': new Uint8Array(frame.data, offset0, size0),
                'width': width,
                'height': height,
                'stride': stride,
                'format': gl.LUMINANCE,
            }, {
                'data': new Uint8Array(frame.data, offset1, size1),
                'width': width / 2,
                'height': height / 2,
                'stride': stride,
                'format': gl.LUMINANCE_ALPHA,
            }];
        },
        'shader': `
            uniform sampler2D tex0;
            uniform sampler2D tex1;

            void main()
            {
                float y = texture2D(tex0, v_texCoord)[0];
                float u = texture2D(tex1, v_texCoord)[0];
                float v = texture2D(tex1, v_texCoord)[%alpha%];

                gl_FragColor = yuv2rgb(y, u, v);
            }
        `,
    },
    'IMC4':
    {
        'mapping': (gl: WebGLRenderingContext, frame: VideoFrame) =>
        {
            const width = frame.info.width;
            const height = frame.info.height;
            const stride = frame.info.stride;

            const offset0 = 0;
            const size0 = stride * height;

            const offset1 = offset0 + size0;
            const size1 = size0 / 2;

            return [{
                'data': new Uint8Array(frame.data, offset0, size0),
                'width': width,
                'height': height,
                'stride': stride,
                'format': gl.LUMINANCE,
            }, {
                'data': new Uint8Array(frame.data, offset1, size1),
                'width': width,
                'height': height / 2,
                'stride': stride,
                'format': gl.LUMINANCE,
            }];
        },
        'shader': `
            uniform sampler2D tex0;
            uniform sampler2D tex1;

            void main()
            {
                float y = texture2D(tex0, v_texCoord)[0];
                float u = texture2D(tex1, vec2(v_texCoord.x * 0.5,       v_texCoord.y))[0];
                float v = texture2D(tex1, vec2(v_texCoord.x * 0.5 + 0.5, v_texCoord.y))[0];

                gl_FragColor = yuv2rgb(y, u, v);
            }
        `,
    },
};

// -----------------------------------------------------------------------------

class GlResource implements SlimCore.Disposable
{
    private _context: WebGL2RenderingContext;
    private _handle: WebGLObject;
    private _isDisposed = false;

    public constructor(gl: WebGL2RenderingContext, handle: WebGLObject)
    {
        this._context = gl;
        this._handle = handle;
    }

    public get gl() {
        return this._context;
    }

    public get handle() {
        return this._handle;
    }

    public dispose()
    {
        delete this._context;
        delete this._handle;

        this._isDisposed = true;
    }

    public isDisposed()
    {
        return this._isDisposed;
    }
}

// -----------------------------------------------------------------------------

class GlTexture extends GlResource
{
    private static _textureUnpackAlignmentMap = [ 8, 1, 2, 1, 4, 1, 2, 1 ];

    private _width: number;
    private _height: number;
    private _format: number;

    public constructor(gl: WebGL2RenderingContext)
    {
        const texture = gl.createTexture();

        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

        super(gl, texture);

        this._width = null;
        this._height = null;
        this._format = null;
    }

    public static alignStride(stride: number)
    {
        // tslint:disable-next-line:no-bitwise
        return GlTexture._textureUnpackAlignmentMap[stride & 7];
    }

    public bind(unit: number)
    {
        this.gl.activeTexture(this.gl.TEXTURE0 + (unit || 0));
        this.gl.bindTexture(this.gl.TEXTURE_2D, this.handle);
    }

    public update(width: number, height: number, format: number, data: ArrayBufferView)
    {
        this.gl.bindTexture(this.gl.TEXTURE_2D, this.handle);

        const internalFormat = this._getInternalFormat(format);

        if (this._width !== width || this._height !== height || this._format !== format) {
            this.gl.texImage2D(this.gl.TEXTURE_2D, 0, internalFormat, width, height, 0, format, this.gl.UNSIGNED_BYTE, data);
        } else {
            this.gl.texSubImage2D(this.gl.TEXTURE_2D, 0, 0, 0, width, height, format, this.gl.UNSIGNED_BYTE, data);
        }

        this._width = width;
        this._height = height;
        this._format = format;
    }

    public dispose()
    {
        if (this.handle) {
            this.gl.deleteTexture(this.handle);
        }

        super.dispose();

        delete this._width;
        delete this._height;
        delete this._format;
    }

    private _getInternalFormat(format: number)
    {
        switch (format) {
            case this.gl.RED:
                return this.gl.R8;

            case this.gl.RG:
                return this.gl.RG8;

            default:
                return format;
        }
    }
}

// -----------------------------------------------------------------------------

class GlArrayBuffer extends GlResource
{
    private _data: ArrayBufferView = null;

    public constructor(gl: WebGL2RenderingContext)
    {
        super(gl, gl.createBuffer());
    }

    public bind()
    {
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.handle);
    }

    public update(data: ArrayBufferView)
    {
        if (isArrayBufferViewEqual(data, this._data)) {
            return;
        }

        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.handle);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, data, this.gl.STATIC_DRAW);

        this._data = data;
    }

    public dispose()
    {
        if (this.handle) {
            this.gl.deleteBuffer(this.handle);
        }

        super.dispose();
    }
}

// -----------------------------------------------------------------------------

class GlShader extends GlResource
{
    public constructor(gl: WebGL2RenderingContext, shaderType: number, shaderSource: string)
    {
        const shader = gl.createShader(shaderType);

        gl.shaderSource(shader, shaderSource);
        gl.compileShader(shader);

        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS) && !gl.isContextLost())
        {
            const lastError = gl.getShaderInfoLog(shader);
            gl.deleteShader(shader);

            throw new Error(`Shader compilation failed: ${lastError}`);
        }

        super(gl, shader);
    }

    public dispose()
    {
        if (this.handle) {
            this.gl.deleteShader(this.handle);
        }

        super.dispose();
    }
}

// -----------------------------------------------------------------------------

class GlProgram extends GlResource
{
    public constructor(gl: WebGL2RenderingContext, vertexShader: GlShader, fragmentShader: GlShader)
    {
        const program = gl.createProgram();

        gl.attachShader(program, vertexShader.handle);
        gl.attachShader(program, fragmentShader.handle);

        gl.linkProgram(program);

        gl.detachShader(program, vertexShader.handle);
        gl.detachShader(program, fragmentShader.handle);

        vertexShader.dispose();
        fragmentShader.dispose();

        if (!gl.getProgramParameter(program, gl.LINK_STATUS) && !gl.isContextLost())
        {
            const lastError = gl.getProgramInfoLog(program);
            gl.deleteProgram(program);

            throw new Error(`Program linking failed: ${lastError}`);
        }

        super(gl, program);
    }

    public getAttribLocation(name: string) {
        return this.gl.getAttribLocation(this.handle, name);
    }

    public getUniformLocation(name: string) {
        return this.gl.getUniformLocation(this.handle, name);
    }

    public dispose()
    {
        if (this.handle) {
            this.gl.deleteProgram(this.handle);
        }

        super.dispose();
    }
}

// -----------------------------------------------------------------------------

function isArrayBufferViewEqual(buf1: ArrayBufferView, buf2: ArrayBufferView)
{
    if (buf1 === buf2) return true;
    if (!buf1 || !buf2) return false;

    const array1 = new Int8Array(buf1.buffer, buf1.byteOffset, buf1.byteLength);
    const array2 = new Int8Array(buf2.buffer, buf2.byteOffset, buf2.byteLength);

    if (array1.length !== array2.length) return false;

    for (let i = 0; i !== array1.length; i++) {
        if (array1[i] !== array2[i]) return false;
    }

    return true;
}

// -----------------------------------------------------------------------------

class Point
{
    public x: number;
    public y: number;

    public constructor(x: number, y: number)
    {
        this.x = x;
        this.y = y;
    }

    public static swap(p1: Point, p2: Point)
    {
        const x = p2.x;
        const y = p2.y;

        p2.x = p1.x;
        p2.y = p1.y;

        p1.x = x;
        p1.y = y;
    }

    public transpose()
    {
        const tmp = this.x;
        this.x = this.y;
        this.y = tmp;
    }

    public translate(offset: Point)
    {
        this.x += offset.x;
        this.y += offset.y;
    }
}

// -----------------------------------------------------------------------------

class Rectangle
{
    public p1: Point;
    public p2: Point;

    public constructor(p1: Point, p2: Point)
    {
        this.p1 = p1;
        this.p2 = p2;
    }

    public static uniform()
    {
        return new Rectangle(
            new Point(-1.0, -1.0),
            new Point(+1.0, +1.0),
        );
    }

    public applyScalingMode(mode: ScalingMode, inputRatio: number, outputRatio: number)
    {
        for (const point of [this.p1, this.p2])
        {
            if (mode === ScalingMode.Fit)
            {
                if (inputRatio > outputRatio) {
                    point.y = point.y / inputRatio * outputRatio;
                } else {
                    point.x = point.x * inputRatio / outputRatio;
                }
            }
            else if (mode === ScalingMode.Crop)
            {
                if (inputRatio < outputRatio) {
                    point.y = point.y / inputRatio * outputRatio;
                } else {
                    point.x = point.x * inputRatio / outputRatio;
                }
            }
        }
    }

    public applyCropOffset(offset: Point, bounds: Rectangle)
    {
        const x = Math.max(Math.min(offset.x, bounds.p1.x - this.p1.x), bounds.p2.x - this.p2.x);
        const y = Math.max(Math.min(offset.y, bounds.p1.y - this.p1.y), bounds.p2.y - this.p2.y);

        const safeOffset = new Point(x, y);

        this.p1.translate(safeOffset);
        this.p2.translate(safeOffset);
    }

    public getCenterPoint()
    {
        const x = (this.p1.x + this.p2.x) / 2;
        const y = (this.p1.y + this.p2.y) / 2;

        return new Point(x, y);
    }

    public toVertices()
    {
        return new Vertices([
            new Point(this.p1.x, this.p1.y),
            new Point(this.p1.x, this.p2.y),
            new Point(this.p2.x, this.p2.y),
            new Point(this.p2.x, this.p1.y),
        ]);
    }
}

// -----------------------------------------------------------------------------

class Vertices
{
    private _vertices: Point[];

    public constructor(vertices: Point[])
    {
        this._vertices = vertices;
    }

    public mirror()
    {
        Point.swap(this._vertices[1], this._vertices[2]);
        Point.swap(this._vertices[0], this._vertices[3]);
    }

    public getTriangleData()
    {
        const data: number[] = [];
        const indexes = [0, 1, 2, 2, 3, 0];

        for (const i of indexes) {
            data.push(this._vertices[i].x, this._vertices[i].y);
        }

        return new Float32Array(data);
    }
}

// -----------------------------------------------------------------------------

class NoopLogger implements Logger
{
    public createChild() { return this; }

    public log()   { /* noop */ }
    public debug() { /* noop */ }
    public info()  { /* noop */ }
    public warn()  { /* noop */ }
    public error() { /* noop */ }
}

class LoggerProxy
{
    public constructor(private _context: string, private _logger: Logger, private _frameSink: SlimCore.FrameSink)
    {
    }

    public log(message: string)
    {
        this._logger.log(message);
        this._log(LogLevel.Default, message);
    }

    public debug(message: string)
    {
        this._logger.debug(message);
        this._log(LogLevel.Debug, message);
    }

    public info(message: string)
    {
        this._logger.info(message);
        this._log(LogLevel.Info, message);
    }

    public warn(message: string)
    {
        this._logger.warn(message);
        this._log(LogLevel.Warning, message);
    }

    public error(message: string)
    {
        this._logger.error(message);
        this._log(LogLevel.Error, message);
    }

    private _log(level: LogLevel, message: string)
    {
        try {
            if (this._frameSink.log) {
                this._frameSink.log(level, `${this._context}: ${message}`);
            }
        }
        catch (error) {
            // ignore
        }
    }
}

// -----------------------------------------------------------------------------

type WebGLPowerPreference = 'default' | 'low-power' | 'high-performance';

interface WebGLContextAttributesEx extends WebGLContextAttributes {
    powerPreference?: WebGLPowerPreference;
}

// -----------------------------------------------------------------------------

let uniqueId = 0;

function getUniqueId() {
    return ++uniqueId;
}

// -----------------------------------------------------------------------------

export class CanvasVideoRenderer extends EventEmitter implements SlimCore.VideoRenderer
{
    private _logger: LoggerProxy;
    private _context: WebGL2RenderingContext = null;
    private _contextIsWebGL2 = false;
    private _scalingMode: ScalingMode = ScalingMode.Stretch;
    private _program: GlProgram = null;
    private _verticesBuffer: GlArrayBuffer = null;
    private _texCoordBuffer: GlArrayBuffer = null;
    private _textures: GlTexture[] = [];
    private _textureLocations: WebGLUniformLocation[] = [];
    private _mirror = false;
    private _format: string = null;
    private _timer: number = null;
    private _cropInfo: CropInfo = null;
    private _alignment: number = null;
    private _videoWidth = 0;
    private _videoHeight = 0;
    private _pendingTimeout: NodeJS.Timer = null;
    private _cleanupHandlers: Function[] = [];
    private _frameSinkReader: SlimCore.Disposable;
    private _currentFrame: VideoFrame;

    public constructor(args: ConstructorArgs, private _frameSink: SlimCore.ChromiumFrameSink)
    {
        super();

        const context = `CanvasVideoRenderer #${getUniqueId()}`;
        const childLogger = (args.logger || new NoopLogger()).createChild(context);
        this._logger = new LoggerProxy(context, childLogger, _frameSink);
        this._scalingMode = args.scalingMode;

        this._logger.debug(`constructor - args: ${JSON.stringify({
            transparent: args.transparent,
            scalingMode: getScalingMode(args.scalingMode),
        })}`);

        this._initialize(args);
    }

    public static isAvailable()
    {
        if (!createFrameSinkReader) {
            return false;
        }

        const attributes: WebGLContextAttributesEx = {
            'powerPreference': 'low-power',
        };

        return !!document.createElement('canvas').getContext('webgl', attributes);
    }

    public getFrameSink()
    {
        return this._frameSink;
    }

    public getVideoSize()
    {
        return {
            'width': this._videoWidth,
            'height': this._videoHeight,
        };
    }

    public setScalingMode(mode: ScalingMode): Promise<void>
    {
        this._logger.debug(`setScalingMode: ${mode}`);

        this._scalingMode = mode;
        this._render();

        return Promise.resolve();
    }

    public dispose()
    {
        if (this._logger) {
            this._logger.debug('dispose');
        }

        if (this._timer) {
            cancelAnimationFrame(this._timer);
        }

        if (this._program) {
            this._program.dispose();
        }

        if (this._verticesBuffer) {
            this._verticesBuffer.dispose();
        }

        if (this._texCoordBuffer) {
            this._texCoordBuffer.dispose();
        }

        if (this._textures) {
            this._textures.forEach((texture) => texture.dispose());
        }

        if (this._context && this._context.canvas) {
            this._context.canvas.remove();
        }

        if (this._frameSink) {
            this._frameSink.dispose();
        }

        if (this._frameSinkReader) {
            this._frameSinkReader.dispose();
        }

        if (this._pendingTimeout) {
            clearTimeout(this._pendingTimeout);
        }

        if (this._cleanupHandlers) {
            this._cleanupHandlers.forEach((handler) => handler());
        }

        delete this._logger;
        delete this._frameSink;
        delete this._frameSinkReader;
        delete this._context;
        delete this._scalingMode;
        delete this._program;
        delete this._verticesBuffer;
        delete this._texCoordBuffer;
        delete this._textures;
        delete this._textureLocations;
        delete this._mirror;
        delete this._format;
        delete this._timer;
        delete this._cropInfo;
        delete this._alignment;
        delete this._videoWidth;
        delete this._videoHeight;
        delete this._pendingTimeout;
        delete this._cleanupHandlers;
        delete this._currentFrame;
    }

    private _createContext(canvas: HTMLCanvasElement, args: ConstructorArgs)
    {
        const attributes: WebGLContextAttributesEx = {
            'alpha': args.transparent,
            'depth': false,
            'stencil': false,
            'antialias': false,
            'premultipliedAlpha': false,
            'preserveDrawingBuffer': false,
            'powerPreference': 'low-power',
        };

        const context = canvas.getContext('webgl2', attributes) || canvas.getContext('webgl', attributes);
        if (!context) {
            this._logger.error('WebGL context init failed');
            throw new Error('WebGL context init failed');
        }

        return context;
    }

    private _createProgram(format: string)
    {
        const gl = this._context;

        if (!format) return null;

        const formatInfo = formats[format];

        if (!formatInfo) {
            this._logger.warn(`Invalid format: ${format}`);
            return null;
        }

        const fragmentShaderSource = FRAGMENT_SHADER_COMMON
            + formatInfo.shader.replace('%alpha%', this._contextIsWebGL2 ? '1' : '3');

        const vertexShader = new GlShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
        const fragmentShader = new GlShader(gl, gl.FRAGMENT_SHADER, fragmentShaderSource);

        return new GlProgram(gl, vertexShader, fragmentShader);
    }

    private _initProgram(format: string)
    {
        const gl = this._context;

        const program = this._createProgram(format);

        if (!program) {
            this._textureLocations = [];
            return null;
        }

        const positionLocation = program.getAttribLocation('position');

        this._getVerticesBuffer().bind();
        gl.enableVertexAttribArray(positionLocation);
        gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);

        const texCoordLocation = program.getAttribLocation('texCoord');

        this._getTexCoordBuffer().bind();
        gl.enableVertexAttribArray(texCoordLocation);
        gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);

        this._textureLocations = [
            program.getUniformLocation('tex0'),
            program.getUniformLocation('tex1'),
            program.getUniformLocation('tex2'),
        ];

        return program;
    }

    private _mapTextureFormat(format: number)
    {
        const gl = this._context;

        switch (format) {
            case gl.LUMINANCE:
                return gl.RED;

            case gl.LUMINANCE_ALPHA:
                return gl.RG;

            default:
                return format;
        }
    }

    private _mapFrameToTextures(frame: VideoFrame)
    {
        if (!frame) return [];

        const formatInfo = formats[frame.info.format];
        if (!formatInfo) return [];

        const result = formatInfo.mapping(this._context, frame);
        if (!this._contextIsWebGL2) return result;

        for (const item of result) {
            item.format = this._mapTextureFormat(item.format);
        }

        return result;
    }

    private _setUnpackAlignment(alignment: number)
    {
        const gl = this._context;

        if (this._alignment !== alignment) {
            gl.pixelStorei(gl.UNPACK_ALIGNMENT, alignment);
        }

        this._alignment = alignment;
    }

    private _updateTextures(frame: VideoFrame)
    {
        const input = this._mapFrameToTextures(frame);

        while (this._textures.length < input.length) {
            this._textures.push(new GlTexture(this._context));
        }

        input.forEach((item, i) => {
            this._setUnpackAlignment(GlTexture.alignStride(item.stride));
            this._textures[i].update(item.width, item.height, item.format, item.data);
        });

        while (this._textures.length > input.length) {
            this._textures.pop().dispose();
        }
    }

    private _updateProgram(format: string)
    {
        const gl = this._context;

        if (format === this._format) return;

        this._logger.debug(`format: ${format}`);

        if (this._program) {
            this._program.dispose();
        }

        const program = this._initProgram(format);

        this._program = program;
        this._format = format;

        gl.useProgram(program ? program.handle : null);
    }

    private _getCropOffset(cropInfo: CropInfo)
    {
        const rect = Rectangle.uniform();

        const p1 = new Point(this._mirror ? cropInfo.rightOffset : cropInfo.leftOffset, cropInfo.bottomOffset);
        const p2 = new Point(this._mirror ? cropInfo.leftOffset : cropInfo.rightOffset, cropInfo.topOffset);

        rect.p1.x -= p1.x / this._videoWidth * 2;
        rect.p1.y -= p1.y / this._videoHeight * 2;
        rect.p2.x += p2.x / this._videoWidth * 2;
        rect.p2.y += p2.y / this._videoHeight * 2;

        rect.applyScalingMode(this._scalingMode, this._getInputRatio(), this._getOutputRatio());

        return rect.getCenterPoint();
    }

    private _updateVertices()
    {
        const rect = Rectangle.uniform();

        rect.applyScalingMode(this._scalingMode, this._getInputRatio(), this._getOutputRatio());

        if (this._cropInfo && this._scalingMode === ScalingMode.Crop)
        {
            const offset = this._getCropOffset(this._cropInfo);
            const bounds = Rectangle.uniform();

            rect.applyCropOffset(offset, bounds);
        }

        const vertices = rect.toVertices();

        if (this._mirror) {
            vertices.mirror();
        }

        this._getVerticesBuffer().update(vertices.getTriangleData());
    }

    private _updateTextureCoords(info: ImageInfo)
    {
        const left   = 0.0 + (info && info.width  ? info.padding.leftOffset   / info.width  : 0);
        const right  = 1.0 - (info && info.width  ? info.padding.rightOffset  / info.width  : 0);
        const top    = 0.0 + (info && info.height ? info.padding.topOffset    / info.height : 0);
        const bottom = 1.0 - (info && info.height ? info.padding.bottomOffset / info.height : 0);

        const texels = new Vertices([
            new Point(left, bottom),
            new Point(left, top),
            new Point(right, top),
            new Point(right, bottom),
        ]);

        this._getTexCoordBuffer().update(texels.getTriangleData());
    }

    private _getVerticesBuffer()
    {
        if (!this._verticesBuffer) {
            this._verticesBuffer = new GlArrayBuffer(this._context);
        }

        return this._verticesBuffer;
    }

    private _getTexCoordBuffer()
    {
        if (!this._texCoordBuffer) {
            this._texCoordBuffer = new GlArrayBuffer(this._context);
        }

        return this._texCoordBuffer;
    }

    private _getInputRatio()
    {
        return this._videoWidth / this._videoHeight;
    }

    private _getOutputRatio()
    {
        return this._context.drawingBufferWidth / this._context.drawingBufferHeight;
    }

    private _render()
    {
        const gl = this._context;

        gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);

        gl.clearColor(0, 0, 0, 0);
        gl.clear(gl.COLOR_BUFFER_BIT);

        if (!this._program || this._textures.length === 0) return;

        this._textures.forEach((texture, i) => {
            texture.bind(i);
            gl.uniform1i(this._textureLocations[i], i);
        });

        this._updateVertices();

        gl.drawArrays(gl.TRIANGLES, 0, 6);
    }

    private _resize()
    {
        const gl = this._context;

        const scale = window.devicePixelRatio || 1;

        const displayWidth  = Math.floor(gl.canvas.clientWidth  * scale);
        const displayHeight = Math.floor(gl.canvas.clientHeight * scale);

        if (gl.canvas.width !== displayWidth || gl.canvas.height !== displayHeight)
        {
            gl.canvas.width  = displayWidth;
            gl.canvas.height = displayHeight;

            this._setVideoPreference(gl.drawingBufferWidth, gl.drawingBufferHeight);

            return true;
        }

        return false;
    }

    private _checkVideoSize(frame: VideoFrame)
    {
        const videoWidth = frame ? frame.info.origWidth : 0;
        const videoHeight = frame ? frame.info.origHeight : 0;

        if (this._videoWidth !== videoWidth || this._videoHeight !== videoHeight)
        {
            this._videoWidth = videoWidth;
            this._videoHeight = videoHeight;

            this._logger.debug(`video-size-changed: ${videoWidth} x ${videoHeight}`);
            this.emit('video-size-changed', this.getVideoSize());
        }
    }

    private _updateFrame(frame: VideoFrame)
    {
        this._checkVideoSize(frame);

        this._updateProgram(frame ? frame.info.format : null);
        this._updateTextureCoords(frame ? frame.info : null);
        this._updateTextures(frame);

        this._cropInfo = frame ? frame.info.cropInfo : null;
        this._mirror = frame ? frame.info.mirror : false;
    }

    private _drawFrame()
    {
        if (!this._frameSink) return;

        const frame = this._currentFrame;
        const frameUpdated = frame !== undefined;

        this._currentFrame = undefined;

        if (frameUpdated) {
            this._updateFrame(frame);
        }

        if (this._resize() || frameUpdated) {
            this._render();
        }

        this._timer = requestAnimationFrame(this._drawFrame.bind(this));
    }

    private _handleContextRestored()
    {
        this._logger.debug('requestAnimationFrame');
        this._timer = requestAnimationFrame(this._drawFrame.bind(this));
    }

    private _handleContextLost()
    {
        this._logger.debug('cancelAnimationFrame');
        cancelAnimationFrame(this._timer);

        this._program = null;
        this._verticesBuffer = null;
        this._texCoordBuffer = null;
        this._textures = [];
        this._textureLocations = [];
        this._format = null;
        this._timer = null;
        this._alignment = null;
    }

    private _initialize(args: ConstructorArgs)
    {
        const document = args.container.ownerDocument;
        const canvas = document.createElement('canvas');

        this._addElementToContainer(canvas, args.container);

        this._addEventListener(canvas, 'webglcontextcreationerror', (event: WebGLContextEvent) => {
            this._logger.error(event.statusMessage);
        });

        this._context = this._createContext(canvas, args) as WebGL2RenderingContext;
        this._contextIsWebGL2 = this._context instanceof WebGL2RenderingContext;

        this._logger.info(`Using WebGL context version: ${this._contextIsWebGL2 ? '2' : '1'}`);

        this._addEventListener(this._context.canvas, 'webglcontextlost', (event) => {
            this._logger.warn('WebGLRenderingContext lost');
            event.preventDefault();
            this._handleContextLost();
        });

        this._addEventListener(this._context.canvas, 'webglcontextrestored', (event) => {
            this._logger.warn('WebGLRenderingContext restored');
            this._handleContextRestored();
        });

        const bufferName = this._frameSink.getBufferName();

        this._addEventListener(document.defaultView, 'message', (event: MessageEvent) => {
            if (event.data.bufferName === bufferName) {
                if (event.data.frame !== undefined) {
                    this._currentFrame = event.data.frame;
                }

                if (event.data.message !== undefined) {
                    this._log(event.data.level, event.data.message);
                }
            }
        });

        this._frameSinkReader = createFrameSinkReader(bufferName);

        this._handleContextRestored();
    }

    private _addElementToContainer(element: HTMLElement, container: HTMLElement)
    {
        element.style.width = '100%';
        element.style.height = '100%';

        if (container.hasChildNodes()) {
            this._logger.warn('Appending to a non-empty container');
        }

        container.appendChild(element);
    }

    private _addEventListener(element: HTMLElement | Window, type: string, listener: EventListener)
    {
        element.addEventListener(type, listener);
        this._cleanupHandlers.push(() => element.removeEventListener(type, listener));
    }

    private _setVideoPreference(width: number, height: number)
    {
        if (this._pendingTimeout) {
            clearTimeout(this._pendingTimeout);
        }

        const handler = () => {
            this._pendingTimeout = null;
            this._logger.debug(`setVideoPreference: ${width} x ${height} @dpi ${devicePixelRatio}`);
            this._frameSink.setVideoPreference(width, height);
        };

        this._pendingTimeout = setTimeout(handler, SET_VIDEO_PREFERENCE_DEBOUNCE_TIMEOUT);
    }

    private _log(level: 'default' | 'debug' | 'info' | 'warning' | 'error', message: string)
    {
        switch (level) {
            case 'default':
                this._logger.log(message);
                break;

            case 'debug':
                this._logger.debug(message);
                break;

            case 'info':
                this._logger.info(message);
                break;

            case 'warning':
                this._logger.warn(message);
                break;

            case 'error':
                this._logger.error(message);
                break;

            default:
                throw new Error(`Unexpected level: ${level}`);
        }
    }
}

// -----------------------------------------------------------------------------

function getScalingMode(mode: ScalingMode)
{
    switch (mode) {
        case ScalingMode.Stretch:
            return 'stretch';

        case ScalingMode.Crop:
            return 'crop';

        case ScalingMode.Fit:
            return 'fit';

        default:
            return undefined;
    }
}

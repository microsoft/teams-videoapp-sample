"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron = require("electron");
const events_1 = require("events");
function exposeModules() {
    // tslint:disable-next-line:no-require-imports
    const videoRenderer = require('slimcore/lib/video-renderer');
    global['electronIpc'] = electron.ipcRenderer;
    global['VideoRenderer'] = videoRenderer;
    global['EventEmitter'] = events_1.EventEmitter;
    global['exports'] = {};
}
if (location.origin === 'file://') {
    exposeModules();
}
console.log('pid', process.pid);
//# sourceMappingURL=preload.js.map
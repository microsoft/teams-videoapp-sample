/// <reference path="../../../../lib/slimcore.d.ts" />
/// <reference path="../../../../lib/video-renderer.d.ts" />

// types
import * as eventsModule from 'events';
import { CompositorLayout } from '../ipc';

declare const EventEmitter: typeof eventsModule.EventEmitter;
declare const electronIpc: Pick<Electron.IpcRenderer, 'send' | 'sendSync' | 'on' | 'once'>;
declare const VideoRenderer: SlimCore.VideoRendererModule;

const videoRenderers: SlimCore.VideoRenderer[] = [];

class View
{
    private area: { x: number, y: number, width: number, height: number };

    private offsetX = 0;
    private offsetY = 0;

    public constructor(private id: number, x: number, y: number, width: number, height: number) {
        this.area = { x, y, width, height };
    }

    public contains(x: number, y: number): boolean {
        return x > this.area.x && x < this.area.x + this.area.width && y > this.area.y && y < this.area.y + this.area.height;
    }

    public beginMove(x: number, y: number): void
    {
        this.offsetX = this.area.x - x;
        this.offsetY = this.area.y - y;
    }

    public move(x: number, y: number): void
    {
        this.area.x = x + this.offsetX;
        this.area.y = y + this.offsetY;
        this.update();
    }

    public update(): void
    {
        electronIpc.send('compositor-view-update', '', this.id, this.area.x, this.area.y, this.area.width, this.area.height);
    }
}

const viewLayout: View[] = [];
let movingView: View = null;

class FrameSinkProxy extends EventEmitter implements SlimCore.ChromiumFrameSink
{
    private _isDisposed = false;

    public constructor(private _bufferName: string) {
        super();
    }

    public dispose() {
        this._isDisposed = true;
    }

    public isDisposed() {
        return this._isDisposed;
    }

    public setVideoPreference(width: number, height: number) {
        this.invoke('setVideoPreference', width, height);
    }

    public setIgnoreMirroring(ignore: boolean) {
        this.invoke('setIgnoreMirroring', ignore);
    }

    public setTextureSharingSupported(supported: boolean) {
        this.invoke('setTextureSharingSupported', supported);
    }

    public _setForceI420(enabled: boolean) {
        this.invoke('_setForceI420', enabled);
    }

    public getBufferName() {
        return this._bufferName;
    }

    public getStats(): SlimCore.ChromiumFrameSink.Stats {
        return undefined;
    }

    public getFrameType(): SlimCore.FrameSink.FrameType {
        return undefined;
    }

    public getMetadata(): SlimCore.FrameSink.Metadata {
        return undefined;
    }

    public log(level: SlimCore.FrameSink.LogLevel, message: string) {
        this.invoke('log', level, message);
    }

    private invoke(method: string, ...args: any[]) {
        electronIpc.send('compositor-frame-sink-invoke', this._bufferName, method, ...args);
    }
}

document.addEventListener('DOMContentLoaded', () =>
{
    console.log(`compositor window loaded`);
    electronIpc.on(`create-compositor-renderer`, (event: Electron.IpcRendererEvent, bufferName: string, layout: CompositorLayout, count: number) =>
    {
        electronIpc.send('compositor-update', 640, 360);
        console.log(`popup create-compositor-renderer with layout ${layout} and ${count} views`);

        if (layout === CompositorLayout.PictureInPicture && count !== 2) {
            throw new Error(`Invalid count for layout ${layout}: ${count}`);
        }

        for (let i = 0; i < count; ++i) {
            let view: View = null;

            if (layout === CompositorLayout.Vertical) {
                view = new View(i, 0, i * 360 / count, 640, 360 / count);
            }
            else if (layout === CompositorLayout.PictureInPicture) {
                if (i === 0)
                    view = new View(i, 0, 0, 640, 360);
                else
                    view = new View(i, 460, 270, 180, 90);
            }
            else if (layout === CompositorLayout.NewsAnchor) {
                if (i === 0)
                    view = new View(i, 0, 0, 640, 360);
                else
                    view = new View(i, 270, 270, 180, 90);
            }

            viewLayout.push(view);
            view.update();
        }
        const container = document.createElement('div');
        container.classList.add('resizable');
        container.addEventListener('mousedown', (ev: MouseEvent) =>
        {
            for (let i = 0; i < viewLayout.length; ++i)
            {
                if (viewLayout[i].contains(ev.clientX, ev.clientY))
                {
                    movingView = viewLayout[i];
                    movingView.beginMove(ev.clientX, ev.clientY);
                    break;
                }
            }
        });
        container.addEventListener('mouseleave', (ev: MouseEvent) =>
        {
            movingView = null;
        });
        container.addEventListener('mouseup', (ev: MouseEvent) =>
        {
            movingView = null;
        });
        container.addEventListener('mousemove', (ev: MouseEvent) =>
        {
            if (movingView != null)
            {
                movingView.move(ev.clientX, ev.clientY);
            }
        });
        document.body.appendChild(container);
        const args: SlimCore.VideoRenderer.ConstructorArgs = {
            container: container,
            transparent: false,
            scalingMode: SlimCore.VideoRenderer.ScalingMode.Fit,
            useBufferSharing: true,
        };
        const frameSink = new FrameSinkProxy(bufferName);
        const videoRenderer = VideoRenderer.createChromiumVideoRenderer(frameSink, args);
        const vr = videoRenderer as any;
        vr._videoElement.addEventListener('msRendererSizeChanged', (event: Event) => {
            electronIpc.send('compositor-update', 640, 360);
        });
        videoRenderer.on('video-size-changed', (args) => {
            console.log('video-size-changed', args);
        });
        videoRenderers.push(videoRenderer);
    });
    console.log(`leaving compositor window loaded`);
    electronIpc.send('compositor-window-ready');
});

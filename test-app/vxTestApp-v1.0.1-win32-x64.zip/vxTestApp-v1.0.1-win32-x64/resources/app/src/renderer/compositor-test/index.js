"use strict";
/// <reference path="../../../../lib/slimcore.d.ts" />
/// <reference path="../../../../lib/video-renderer.d.ts" />
Object.defineProperty(exports, "__esModule", { value: true });
const videoRenderers = [];
class View {
    constructor(id, x, y, width, height) {
        this.id = id;
        this.offsetX = 0;
        this.offsetY = 0;
        this.area = { x, y, width, height };
    }
    contains(x, y) {
        return x > this.area.x && x < this.area.x + this.area.width && y > this.area.y && y < this.area.y + this.area.height;
    }
    beginMove(x, y) {
        this.offsetX = this.area.x - x;
        this.offsetY = this.area.y - y;
    }
    move(x, y) {
        this.area.x = x + this.offsetX;
        this.area.y = y + this.offsetY;
        this.update();
    }
    update() {
        electronIpc.send('compositor-view-update', '', this.id, this.area.x, this.area.y, this.area.width, this.area.height);
    }
}
const viewLayout = [];
let movingView = null;
class FrameSinkProxy extends EventEmitter {
    constructor(_bufferName) {
        super();
        this._bufferName = _bufferName;
        this._isDisposed = false;
    }
    dispose() {
        this._isDisposed = true;
    }
    isDisposed() {
        return this._isDisposed;
    }
    setVideoPreference(width, height) {
        this.invoke('setVideoPreference', width, height);
    }
    setIgnoreMirroring(ignore) {
        this.invoke('setIgnoreMirroring', ignore);
    }
    setTextureSharingSupported(supported) {
        this.invoke('setTextureSharingSupported', supported);
    }
    _setForceI420(enabled) {
        this.invoke('_setForceI420', enabled);
    }
    getBufferName() {
        return this._bufferName;
    }
    getStats() {
        return undefined;
    }
    getFrameType() {
        return undefined;
    }
    getMetadata() {
        return undefined;
    }
    log(level, message) {
        this.invoke('log', level, message);
    }
    invoke(method, ...args) {
        electronIpc.send('compositor-frame-sink-invoke', this._bufferName, method, ...args);
    }
}
document.addEventListener('DOMContentLoaded', () => {
    console.log(`compositor window loaded`);
    electronIpc.on(`create-compositor-renderer`, (event, bufferName, layout, count) => {
        electronIpc.send('compositor-update', 640, 360);
        console.log(`popup create-compositor-renderer with layout ${layout} and ${count} views`);
        if (layout === 1 /* PictureInPicture */ && count !== 2) {
            throw new Error(`Invalid count for layout ${layout}: ${count}`);
        }
        for (let i = 0; i < count; ++i) {
            let view = null;
            if (layout === 0 /* Vertical */) {
                view = new View(i, 0, i * 360 / count, 640, 360 / count);
            }
            else if (layout === 1 /* PictureInPicture */) {
                if (i === 0)
                    view = new View(i, 0, 0, 640, 360);
                else
                    view = new View(i, 460, 270, 180, 90);
            }
            else if (layout === 2 /* NewsAnchor */) {
                if (i === 0)
                    view = new View(i, 0, 0, 640, 360);
                else
                    view = new View(i, 270, 270, 180, 90);
            }
            viewLayout.push(view);
            view.update();
        }
        const container = document.createElement('div');
        container.classList.add('resizable');
        container.addEventListener('mousedown', (ev) => {
            for (let i = 0; i < viewLayout.length; ++i) {
                if (viewLayout[i].contains(ev.clientX, ev.clientY)) {
                    movingView = viewLayout[i];
                    movingView.beginMove(ev.clientX, ev.clientY);
                    break;
                }
            }
        });
        container.addEventListener('mouseleave', (ev) => {
            movingView = null;
        });
        container.addEventListener('mouseup', (ev) => {
            movingView = null;
        });
        container.addEventListener('mousemove', (ev) => {
            if (movingView != null) {
                movingView.move(ev.clientX, ev.clientY);
            }
        });
        document.body.appendChild(container);
        const args = {
            container: container,
            transparent: false,
            scalingMode: 2 /* Fit */,
            useBufferSharing: true,
        };
        const frameSink = new FrameSinkProxy(bufferName);
        const videoRenderer = VideoRenderer.createChromiumVideoRenderer(frameSink, args);
        const vr = videoRenderer;
        vr._videoElement.addEventListener('msRendererSizeChanged', (event) => {
            electronIpc.send('compositor-update', 640, 360);
        });
        videoRenderer.on('video-size-changed', (args) => {
            console.log('video-size-changed', args);
        });
        videoRenderers.push(videoRenderer);
    });
    console.log(`leaving compositor window loaded`);
    electronIpc.send('compositor-window-ready');
});
//# sourceMappingURL=index.js.map
import { exposeSlimCore } from '../calling';

// types
import { MainWindowOptions } from '../ipc';
import { RemoteHostConnection } from '../../remote-host/remote-client';

declare const options: MainWindowOptions;
declare function initPluginHost(): RemoteHostConnection;

window['Buffer'] = Buffer;
exposeSlimCore({ ...options, initPluginHost });

try {
    delete window['initPluginHost'];
} catch (error) {
    // ignore
}

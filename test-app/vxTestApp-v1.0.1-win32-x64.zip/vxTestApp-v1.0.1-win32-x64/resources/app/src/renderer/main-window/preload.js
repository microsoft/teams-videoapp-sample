"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const calling_1 = require("../calling");
const utils_1 = require("../utils");
const options = utils_1.invokeSync('get-options');
if (process.sandboxed || process.contextIsolated) {
    options.usePluginHost = true;
}
if (options.enableWatchdog) {
    process.startWatchdog(5000, { pingInterval: 1000 });
}
function initPluginHost() {
    const pluginHostId = utils_1.invokeSync('init-plugin-host');
    return {
        id: pluginHostId,
        contextId: process.contextId,
        send(channel, args) {
            return electron_1.ipcRenderer.sendToRenderer(pluginHostId, channel, args);
        },
        sendSync(channel, args, watchdogApi) {
            return electron_1.ipcRenderer.sendToRendererSync(pluginHostId, channel, args, watchdogApi);
        },
        connect() {
            return electron_1.ipcRenderer.connectToRenderer(pluginHostId);
        },
        on(channel, listener) {
            electron_1.ipcRenderer.on(channel, (event, ...args) => {
                if (event.senderId === pluginHostId) {
                    listener(event, ...args);
                }
            });
        },
    };
}
function exposeGlobal(name, value) {
    if (process.contextIsolated) {
        electron_1.contextBridge.exposeInMainWorld(name, value);
    }
    else {
        global[name] = value;
    }
}
function exposeModules() {
    exposeGlobal('options', options);
    exposeGlobal('electronIpc', utils_1.electronIpc);
    exposeGlobal('crash', process.crash);
    exposeGlobal('hang', process.hang);
    exposeGlobal('createFrameSinkReader', utils_1.createFrameSinkReader);
    if (process.contextIsolated) {
        electron_1.contextBridge.exposeInMainWorld('initPluginHost', initPluginHost);
        utils_1.executePreload(utils_1.invokeSync('get-preload-main-world'));
    }
    else {
        process.once('loaded', () => { window['Buffer'] = Buffer; });
        calling_1.exposeSlimCore(Object.assign({}, options, { initPluginHost }));
    }
}
if (location.origin === 'file://' || location.href === 'about:blank') {
    exposeModules();
}
// index.js: Object.defineProperty(exports, "__esModule", { value: true });
electron_1.webFrame.executeJavaScript(`var exports = {};`);
console.log('pid', process.pid);
console.log('sandbox', !!process.sandboxed);
console.log('contextIsolation', process.contextIsolated);
console.log('electron.version', process.versions.electron);
console.log('electron.build', process.versions['microsoft-build']);
//# sourceMappingURL=preload.js.map
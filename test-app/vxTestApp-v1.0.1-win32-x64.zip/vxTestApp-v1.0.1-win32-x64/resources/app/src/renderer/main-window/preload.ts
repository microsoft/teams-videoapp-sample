import { ipcRenderer, contextBridge, webFrame } from 'electron';
import { exposeSlimCore } from '../calling';
import { electronIpc, invokeSync, executePreload, createFrameSinkReader } from '../utils';

// types
import { MainWindowOptions } from '../ipc';
import { RemoteHostConnection } from '../../remote-host/remote-client';

const options = invokeSync('get-options') as MainWindowOptions;

if (process.sandboxed || process.contextIsolated) {
    options.usePluginHost = true;
}

if (options.enableWatchdog) {
    process.startWatchdog(5000, { pingInterval: 1000 });
}

function initPluginHost(): RemoteHostConnection
{
    const pluginHostId = invokeSync('init-plugin-host') as number;

    return {
        id: pluginHostId,
        contextId: process.contextId,
        send(channel: string, args: any[]) {
            return ipcRenderer.sendToRenderer(pluginHostId, channel, args);
        },
        sendSync(channel: string, args: any[], watchdogApi: string) {
            return ipcRenderer.sendToRendererSync(pluginHostId, channel, args, watchdogApi);
        },
        connect() {
            return ipcRenderer.connectToRenderer(pluginHostId);
        },
        on(channel: string, listener: (event: Electron.IpcRendererEvent, ...args: any[]) => void) {
            ipcRenderer.on(channel, (event, ...args) => {
                if (event.senderId === pluginHostId) {
                    listener(event, ...args);
                }
            });
        },
    };
}

function exposeGlobal(name: string, value: any)
{
    if (process.contextIsolated) {
        contextBridge.exposeInMainWorld(name, value);
    } else {
        global[name] = value;
    }
}

function exposeModules()
{
    exposeGlobal('options', options);
    exposeGlobal('electronIpc', electronIpc);
    exposeGlobal('crash', process.crash);
    exposeGlobal('hang', process.hang);
    exposeGlobal('createFrameSinkReader', createFrameSinkReader);

    if (process.contextIsolated) {
        contextBridge.exposeInMainWorld('initPluginHost', initPluginHost);
        executePreload(invokeSync('get-preload-main-world'));
    } else {
        process.once('loaded', () => { window['Buffer'] = Buffer; });
        exposeSlimCore({ ...options, initPluginHost });
    }
}

if (location.origin === 'file://' || location.href === 'about:blank') {
    exposeModules();
}

// index.js: Object.defineProperty(exports, "__esModule", { value: true });
webFrame.executeJavaScript(`var exports = {};`);

console.log('pid', process.pid);
console.log('sandbox', !!process.sandboxed);
console.log('contextIsolation', process.contextIsolated);
console.log('electron.version', process.versions.electron);
console.log('electron.build', process.versions['microsoft-build']);

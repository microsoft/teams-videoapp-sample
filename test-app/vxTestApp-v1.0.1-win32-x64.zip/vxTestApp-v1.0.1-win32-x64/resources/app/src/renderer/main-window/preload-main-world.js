"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const calling_1 = require("../calling");
window['Buffer'] = Buffer;
calling_1.exposeSlimCore(Object.assign({}, options, { initPluginHost }));
try {
    delete window['initPluginHost'];
}
catch (error) {
    // ignore
}
//# sourceMappingURL=preload-main-world.js.map
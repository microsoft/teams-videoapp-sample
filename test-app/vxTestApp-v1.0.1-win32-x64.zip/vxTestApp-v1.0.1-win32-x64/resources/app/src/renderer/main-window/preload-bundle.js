(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
/// <reference path="./slimcore.d.ts" />
/// <reference path="./video-renderer.d.ts" />
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const API_VERSION = 2;
const ONE_SECOND_IN_MS = 1000;
const SET_VIDEO_PREFERENCE_DEBOUNCE_TIMEOUT = ONE_SECOND_IN_MS;
const SET_PREFERENCE_ATTENUATION_WINDOW_SEC = 2;
const MAXIMUM_SET_PREFERENCE_RATE = 30;
// -----------------------------------------------------------------------------
class NoopLogger {
    createChild() { return this; }
    log() { }
    debug() { }
    info() { }
    warn() { }
    error() { }
}
class LoggerProxy {
    constructor(_context, _logger, _frameSink) {
        this._context = _context;
        this._logger = _logger;
        this._frameSink = _frameSink;
    }
    log(message) {
        this._logger.log(message);
        this._log(0 /* Default */, message);
    }
    debug(message) {
        this._logger.debug(message);
        this._log(1 /* Debug */, message);
    }
    info(message) {
        this._logger.info(message);
        this._log(2 /* Info */, message);
    }
    warn(message) {
        this._logger.warn(message);
        this._log(3 /* Warning */, message);
    }
    error(message) {
        this._logger.error(message);
        this._log(4 /* Error */, message);
    }
    _log(level, message) {
        try {
            if (this._frameSink.log) {
                this._frameSink.log(level, `${this._context}: ${message}`);
            }
        }
        catch (error) {
            // ignore
        }
    }
}
// -----------------------------------------------------------------------------
let uniqueId = 0;
function getUniqueId() {
    return ++uniqueId;
}
// -----------------------------------------------------------------------------
class ChromiumVideoRenderer extends events_1.EventEmitter {
    constructor(args, _frameSink) {
        super();
        this._frameSink = _frameSink;
        this._videoElement = null;
        this._videoWidth = 0;
        this._videoHeight = 0;
        this._rendererWidth = 0;
        this._rendererHeight = 0;
        this._pendingTimeout = null;
        this._cleanupHandlers = [];
        this._isDisposed = false;
        this._setVideoPreferenceTs = 0;
        this._setVideoPreferenceCounter = 0;
        if (typeof HTMLSkypeVideoElement !== 'function') {
            const message = 'HTMLSkypeVideoElement is not available';
            throw new VideoRendererError(message, 2 /* Unavailable */);
        }
        if (HTMLSkypeVideoElement.API_VERSION !== API_VERSION) {
            const message = `HTMLSkypeVideoElement - actual version: ${HTMLSkypeVideoElement.API_VERSION}, expected version: ${API_VERSION}`;
            throw new VideoRendererError(message, 2 /* Unavailable */);
        }
        const context = `ChromiumVideoRenderer #${getUniqueId()}`;
        const childLogger = (args.logger || new NoopLogger()).createChild(context);
        this._logger = new LoggerProxy(context, childLogger, _frameSink);
        this._logger.debug(`constructor - args: ${JSON.stringify({
            transparent: args.transparent,
            scalingMode: getScalingMode(args.scalingMode),
            useBufferSharing: args.useBufferSharing,
        })}`);
        this._initialize(args);
    }
    dispose() {
        if (this._logger) {
            this._logger.debug(`dispose`);
        }
        if (this._frameSink) {
            this._frameSink.dispose();
        }
        if (this._cleanupHandlers) {
            this._cleanupHandlers.forEach((handler) => handler());
        }
        if (this._videoElement) {
            this._videoElement.remove();
            const videoElement = this._videoElement;
            setTimeout(() => { videoElement.src = ''; }, 0);
        }
        if (this._pendingTimeout) {
            clearTimeout(this._pendingTimeout);
        }
        delete this._logger;
        delete this._frameSink;
        delete this._videoElement;
        delete this._videoWidth;
        delete this._videoHeight;
        delete this._rendererWidth;
        delete this._rendererHeight;
        delete this._pendingTimeout;
        delete this._cleanupHandlers;
        this._isDisposed = true;
    }
    isDisposed() {
        return this._isDisposed;
    }
    getFrameSink() {
        return this._frameSink;
    }
    getVideoSize() {
        return {
            width: this._videoWidth,
            height: this._videoHeight,
        };
    }
    setScalingMode(mode) {
        this._logger.debug(`setScalingMode: ${mode}`);
        this._videoElement.scalingMode = getScalingMode(mode);
        return Promise.resolve();
    }
    _initialize(args) {
        this._videoElement = this._createVideoElement(args);
        this._addElementToContainer(this._videoElement, args.container);
        this._handleEvent('error', (event) => this._logError(event));
        this._handleEvent('resize', () => this._checkVideoSize());
        this._handleEvent('msLogEvent', (event) => this._logEvent(event));
        this._handleEvent('msRendererSizeChanged', () => this._checkRendererSize());
        this._handleEvent('msBackgroundRenderingChanged', () => this._checkBackgroundRendering());
        this._handleEvent('msTextureSharingSupportedChanged', () => this._setTextureSharingSupported());
        this._setTextureSharingSupported();
        const bufferName = this._frameSink.getBufferName();
        this._logger.debug(`loadSync: ${bufferName}`);
        this._videoElement.loadSync(bufferName);
    }
    _createVideoElement(args) {
        const document = args.container.ownerDocument;
        const video = document.createElement('skypevideo');
        video.style.backgroundColor = args.transparent ? '' : 'black';
        video.scalingMode = getScalingMode(args.scalingMode);
        video.bufferSharingEnabled = !!args.useBufferSharing;
        return video;
    }
    _addElementToContainer(element, container) {
        element.style.width = '100%';
        element.style.height = '100%';
        if (container.hasChildNodes()) {
            this._logger.warn('Appending to a non-empty container');
        }
        container.appendChild(element);
    }
    _handleEvent(type, listener) {
        // tslint:disable-next-line:no-any
        return this._addEventListener(this._videoElement, type, listener);
    }
    _addEventListener(element, type, listener) {
        element.addEventListener(type, listener);
        this._cleanupHandlers.push(() => element.removeEventListener(type, listener));
    }
    _logError(event) {
        if (event instanceof ErrorEvent) {
            this._logger.error(`error: ${event.message}`);
        }
        else {
            this._logger.error(`error: ${formatMediaError(this._videoElement.error)}`);
        }
    }
    _logEvent(event) {
        switch (event.level) {
            case 0 /* Default */:
                this._logger.log(event.message);
                break;
            case 1 /* Debug */:
                this._logger.debug(event.message);
                break;
            case 2 /* Info */:
                this._logger.info(event.message);
                break;
            case 3 /* Warning */:
                this._logger.warn(event.message);
                break;
            case 4 /* Error */:
                this._logger.error(event.message);
                break;
            default:
            // assert(false);
        }
    }
    _checkVideoSize() {
        const videoWidth = this._videoElement.videoWidth;
        const videoHeight = this._videoElement.videoHeight;
        if (this._videoWidth !== videoWidth || this._videoHeight !== videoHeight) {
            this._videoWidth = videoWidth;
            this._videoHeight = videoHeight;
            this._logger.debug(`video-size-changed: ${videoWidth} x ${videoHeight}`);
            this.emit('video-size-changed', this.getVideoSize());
        }
    }
    _checkRendererSize() {
        let pixelWidth = this._videoElement.clientWidth * devicePixelRatio;
        let pixelHeight = this._videoElement.clientHeight * devicePixelRatio;
        const ratio = this._videoElement.rendererWidth / this._videoElement.rendererHeight;
        if (this._videoElement.scalingMode === 'fit') {
            if (ratio > (pixelWidth / pixelHeight)) {
                pixelHeight = pixelWidth / ratio;
            }
            else {
                pixelWidth = pixelHeight * ratio;
            }
        }
        else if (this._videoElement.scalingMode === 'crop') {
            if (ratio < (pixelWidth / pixelHeight)) {
                pixelHeight = pixelWidth / ratio;
            }
            else {
                pixelWidth = pixelHeight * ratio;
            }
        }
        const rendererWidth = Math.floor(pixelWidth) || 0;
        const rendererHeight = Math.floor(pixelHeight) || 0;
        if (this._rendererWidth !== rendererWidth || this._rendererHeight !== rendererHeight) {
            this._rendererWidth = rendererWidth;
            this._rendererHeight = rendererHeight;
            this._setVideoPreference(rendererWidth, rendererHeight);
        }
    }
    _setVideoPreference(width, height) {
        if (this._pendingTimeout) {
            clearTimeout(this._pendingTimeout);
        }
        const ts = Date.now();
        const delta = ts - this._setVideoPreferenceTs;
        if (delta > ONE_SECOND_IN_MS) {
            this._setVideoPreferenceTs = ts;
        }
        // Estimate _setVideoPreference invocation rate and scale debounce timeout by it.
        const secondsElapsed = Math.min(Math.max((delta - ONE_SECOND_IN_MS) / ONE_SECOND_IN_MS, 0), SET_PREFERENCE_ATTENUATION_WINDOW_SEC);
        const historyWeight = 1 - secondsElapsed / SET_PREFERENCE_ATTENUATION_WINDOW_SEC;
        this._setVideoPreferenceCounter = 1 + this._setVideoPreferenceCounter * historyWeight;
        const scale = Math.min(this._setVideoPreferenceCounter - 1, MAXIMUM_SET_PREFERENCE_RATE) / MAXIMUM_SET_PREFERENCE_RATE;
        const debounceTimeout = SET_VIDEO_PREFERENCE_DEBOUNCE_TIMEOUT * scale;
        const handler = () => {
            this._pendingTimeout = null;
            this._logger.debug(`setVideoPreference: ${width} x ${height} @dpi ${devicePixelRatio}`);
            this._frameSink.setVideoPreference(width, height);
        };
        this._logger.debug(`issue setVideoPreference: ${width} x ${height} @dpi ${devicePixelRatio} timeout ${debounceTimeout}`);
        if (debounceTimeout < 1) {
            handler();
        }
        else {
            this._pendingTimeout = setTimeout(handler, debounceTimeout);
        }
    }
    _checkBackgroundRendering() {
        this._logger.debug(`backgroundRendering: ${this._videoElement.backgroundRendering}`);
    }
    _setTextureSharingSupported() {
        const textureSharingSupported = this._videoElement.textureSharingSupported;
        this._logger.debug(`textureSharingSupported: ${textureSharingSupported}`);
        if (this._frameSink.setTextureSharingSupported) {
            this._frameSink.setTextureSharingSupported(!!textureSharingSupported);
        }
    }
}
exports.ChromiumVideoRenderer = ChromiumVideoRenderer;
// -----------------------------------------------------------------------------
function getScalingMode(mode) {
    switch (mode) {
        case 0 /* Stretch */:
            return 'stretch';
        case 1 /* Crop */:
            return 'crop';
        case 2 /* Fit */:
            return 'fit';
        default:
            return undefined;
    }
}
function formatMediaError(error) {
    switch (error && error.code) {
        case MediaError.MEDIA_ERR_ABORTED:
            return 'MEDIA_ERR_ABORTED';
        case MediaError.MEDIA_ERR_NETWORK:
            return 'MEDIA_ERR_NETWORK';
        case MediaError.MEDIA_ERR_DECODE:
            return 'MEDIA_ERR_DECODE';
        case MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED:
            return 'MEDIA_ERR_SRC_NOT_SUPPORTED';
        default:
            return undefined;
    }
}
// -----------------------------------------------------------------------------
class VideoRendererError extends Error {
    constructor(message, reason = 0 /* Unknown */) {
        super(message);
        this.reason = reason;
    }
}
// -----------------------------------------------------------------------------
function createChromiumVideoRenderer(frameSink, args) {
    return new ChromiumVideoRenderer(args, frameSink);
}
exports.createChromiumVideoRenderer = createChromiumVideoRenderer;
function isChromiumVideoRendererAvailable() {
    return typeof HTMLSkypeVideoElement === 'function' && HTMLSkypeVideoElement.API_VERSION === API_VERSION;
}
exports.isChromiumVideoRendererAvailable = isChromiumVideoRendererAvailable;

},{"events":undefined}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CallbacksRegistry {
    constructor() {
        this.nextId = 0;
        this.callbacks = new Map();
        this.callbackIds = new WeakMap();
    }
    add(callback) {
        // The callback is already added.
        let id = this.callbackIds.get(callback);
        if (id != null)
            return id;
        id = this.nextId += 1;
        this.callbacks.set(id, callback);
        this.callbackIds.set(callback, id);
        return id;
    }
    get(id) {
        return this.callbacks.get(id) || (() => { });
    }
    apply(id, ...args) {
        return this.get(id).apply(global, ...args);
    }
    remove(id) {
        const callback = this.callbacks.get(id);
        if (callback) {
            this.callbackIds.delete(callback);
            this.callbacks.delete(id);
        }
    }
}
exports.CallbacksRegistry = CallbacksRegistry;

},{}],3:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.remoteClientCallbackInvoke = 'ELECTRON_REMOTE_CLIENT_CALLBACK';
exports.remoteClientCallbackRelease = 'ELECTRON_REMOTE_CLIENT_RELEASE_CALLBACK';
exports.remoteServerConnect = 'ELECTRON_REMOTE_SERVER_CONNECT';
exports.remoteServerRequire = 'ELECTRON_REMOTE_SERVER_REQUIRE';
exports.remoteServerConstructor = 'ELECTRON_REMOTE_SERVER_CONSTRUCTOR';
exports.remoteServerFunctionCall = 'ELECTRON_REMOTE_SERVER_FUNCTION_CALL';
exports.remoteServerFunctionCallAsync = 'ELECTRON_REMOTE_SERVER_FUNCTION_CALL_ASYNC';
exports.remoteServerMemberConstructor = 'ELECTRON_REMOTE_SERVER_MEMBER_CONSTRUCTOR';
exports.remoteServerMemberCall = 'ELECTRON_REMOTE_SERVER_MEMBER_CALL';
exports.remoteServerMemberCallAsync = 'ELECTRON_REMOTE_SERVER_MEMBER_CALL_ASYNC';
exports.remoteServerMemberGet = 'ELECTRON_REMOTE_SERVER_MEMBER_GET';
exports.remoteServerMemberSet = 'ELECTRON_REMOTE_SERVER_MEMBER_SET';
exports.remoteServerDereference = 'ELECTRON_REMOTE_SERVER_DEREFERENCE';
exports.remoteServerContextRelease = 'ELECTRON_REMOTE_SERVER_CONTEXT_RELEASE';

},{}],4:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getElectronBinding = process.electronBinding
    ? (name) => process.electronBinding(name)
    : (name) => process._linkedBinding('electron_common_' + name);
function isPromise(val) {
    return (val &&
        val.then &&
        val.then instanceof Function &&
        val.constructor &&
        val.constructor.reject &&
        val.constructor.reject instanceof Function &&
        val.constructor.resolve &&
        val.constructor.resolve instanceof Function);
}
exports.isPromise = isPromise;
const serializableTypes = [
    Boolean,
    Number,
    String,
    Date,
    Error,
    RegExp,
    ArrayBuffer,
];
// https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Structured_clone_algorithm#Supported_types
function isSerializableObject(value) {
    return value === null || ArrayBuffer.isView(value) || serializableTypes.some((type) => value instanceof type);
}
exports.isSerializableObject = isSerializableObject;
function precise(x) {
    return x.toPrecision(3);
}
exports.precise = precise;
const timeOrigin = process.hrtime && process.hrtime();
function now() {
    if (process.hrtime) {
        return milliseconds(process.hrtime(timeOrigin));
    }
    else {
        return performance.now();
    }
}
exports.now = now;
function milliseconds(time) {
    return time[0] * 1000 + time[1] / 1e6;
}

},{}],5:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const callbacks_registry_1 = require("./lib/callbacks-registry");
const ipcMessages = require("./lib/ipc-messages");
const utils = require("./lib/utils");
class RemoteClient extends events_1.EventEmitter {
    constructor(host, options) {
        super();
        this.host = host;
        this.hooks = {};
        this.callbacksRegistry = new callbacks_registry_1.CallbacksRegistry();
        this.remoteObjectCache = new Map();
        this.electronIds = new WeakMap();
        this.enableTracing = false;
        this.enableOptimizationConstant = true;
        this.enableOptimizationPromise = true;
        this.enableOptimizationVoid = true;
        this.enableOptimizationSimpleArgs = true;
        this._usingDirectChannel = false;
        this.enableTracing = !!options.enableTracing;
        this.finalizationRegistry = new FinalizationRegistry((id) => {
            const ref = this.remoteObjectCache.get(id);
            if (ref !== undefined && ref.deref() === undefined) {
                this.remoteObjectCache.delete(id);
                this.send(ipcMessages.remoteServerDereference, id);
            }
        });
        if (options.enableDirectChannel) {
            try {
                this.host.on('ms-connect-event', (event, connected) => {
                    if (this.enableTracing) {
                        console.log(`ms-connect-event: ${connected}`);
                    }
                    this._usingDirectChannel = connected;
                    this.emit('using-direct-channel-changed', this.usingDirectChannel);
                    if (connected) {
                        this.send(ipcMessages.remoteServerConnect);
                    }
                });
                this.host.connect();
            }
            catch (error) {
                if (this.enableTracing) {
                    console.log(`connectToRenderer failed: ${error}`);
                }
            }
        }
        // Host calls a callback in renderer.
        this.handleMessage(ipcMessages.remoteClientCallbackInvoke, (id, args) => {
            this.callbacksRegistry.apply(id, this.metaToValue(args));
        });
        // A callback in host is released.
        this.handleMessage(ipcMessages.remoteClientCallbackRelease, (id) => {
            this.callbacksRegistry.remove(id);
        });
        process.on('exit', () => {
            this.send(ipcMessages.remoteServerContextRelease);
        });
    }
    get usingDirectChannel() {
        return this._usingDirectChannel;
    }
    require(module) {
        const api = `remote-client: require() / ${module}`;
        const [meta, metrics] = this.sendSync(ipcMessages.remoteServerRequire, [module], api);
        if (this.hooks && this.hooks.require) {
            this.hooks.require(module, metrics);
        }
        return this.metaToValue(meta);
    }
    getCachedRemoteObject(id) {
        const ref = this.remoteObjectCache.get(id);
        if (ref !== undefined) {
            const deref = ref.deref();
            if (deref !== undefined)
                return deref;
        }
    }
    setCachedRemoteObject(id, value) {
        const wr = new WeakRef(value);
        this.remoteObjectCache.set(id, wr);
        this.finalizationRegistry.register(value, id);
        return value;
    }
    handleMessage(channel, handler) {
        this.host.on(channel, ({ isDirectChannel }, passedContextId, ...args) => {
            if (this.hooks.incomingMessage) {
                this.hooks.incomingMessage(channel);
            }
            if (this.enableTracing) {
                console.group('handleMessage', channel);
                console.log('hostId:', this.host.id, 'isDirectChannel:', isDirectChannel, 'contextId:', passedContextId, 'args:', ...args);
            }
            if (passedContextId === this.host.contextId) {
                handler(...args);
            }
            if (this.enableTracing) {
                console.groupEnd();
            }
        });
    }
    send(command, ...args) {
        if (this.hooks.outgoingMessage) {
            this.hooks.outgoingMessage(command);
        }
        if (this.enableTracing) {
            console.group('sendTo', command);
            console.log('hostId:', this.host.id, 'contextId:', this.host.contextId, 'args:', ...args);
        }
        const timeStart = utils.now();
        this.host.send(command, [this.host.contextId, ...args]);
        const duration = utils.now() - timeStart;
        if (this.enableTracing) {
            console.log('duration:', utils.precise(duration));
            console.groupEnd();
        }
        return { duration, async: true };
    }
    sendSync(command, args, api) {
        if (this.hooks.outgoingMessageSync) {
            this.hooks.outgoingMessageSync(command);
        }
        if (this.enableTracing) {
            console.group('sendToSync', command);
            console.log('hostId:', this.host.id, 'contextId:', this.host.contextId, 'args:', ...args);
        }
        const timeStart = utils.now();
        const [result, durationInHost] = this.host.sendSync(command, [this.host.contextId, ...args], api);
        const duration = utils.now() - timeStart;
        if (this.enableTracing) {
            console.log('duration:', utils.precise(duration), 'durationInHost:', utils.precise(durationInHost), 'result:', result);
            console.groupEnd();
        }
        return [result, { duration, durationInHost }];
    }
    // Convert the arguments object into an array of meta data.
    wrapArgs(args, simple = false, visited = new Set()) {
        if (simple) {
            return args.map((value) => ({
                type: 'value',
                value: value,
            }));
        }
        const valueToMeta = (value) => {
            // Check for circular reference.
            if (visited.has(value)) {
                return {
                    type: 'value',
                    value: null,
                };
            }
            if (Array.isArray(value)) {
                visited.add(value);
                const meta = {
                    type: 'array',
                    value: this.wrapArgs(value, simple, visited),
                };
                visited.delete(value);
                return meta;
            }
            else if (value instanceof Buffer) {
                return {
                    type: 'buffer',
                    value,
                };
            }
            else if (utils.isSerializableObject(value)) {
                return {
                    type: 'value',
                    value,
                };
            }
            else if (typeof value === 'object') {
                if (utils.isPromise(value)) {
                    return {
                        type: 'promise',
                        then: valueToMeta((onFulfilled, onRejected) => {
                            value.then(onFulfilled, onRejected);
                        }),
                    };
                }
                else if (this.electronIds.has(value)) {
                    return {
                        type: 'remote-object',
                        id: this.electronIds.get(value),
                    };
                }
                const meta = {
                    type: 'object',
                    name: value.constructor ? value.constructor.name : '',
                    members: [],
                };
                visited.add(value);
                // tslint:disable-next-line
                for (const prop in value) {
                    meta.members.push({
                        name: prop,
                        value: valueToMeta(value[prop]),
                    });
                }
                visited.delete(value);
                return meta;
            }
            else if (typeof value === 'function') {
                return {
                    type: 'function',
                    id: this.callbacksRegistry.add(value),
                    length: value.length,
                };
            }
            else {
                return {
                    type: 'value',
                    value,
                };
            }
        };
        return args.map(valueToMeta);
    }
    // Populate object's members from descriptors.
    // The |ref| will be kept referenced by |members|.
    // This matches |getObjectMemebers| in rpc-server.
    setObjectMembers(ref, object, metaId, members) {
        if (!Array.isArray(members))
            return;
        for (const member of members) {
            if (Object.prototype.hasOwnProperty.call(object, member.name))
                continue;
            const descriptor = { enumerable: member.enumerable };
            if (member.type === 'method') {
                const remoteMemberFunction = this.makeRemoteMemberFunction(ref, metaId, member);
                let descriptorFunction = this.proxyFunctionProperties(remoteMemberFunction, ref, metaId, member.name);
                descriptor.get = () => {
                    descriptorFunction.ref = ref; // The member should reference its object.
                    return descriptorFunction;
                };
                // Enable monkey-patch the method
                descriptor.set = (value) => {
                    descriptorFunction = value;
                    return value;
                };
                descriptor.configurable = true;
            }
            else if (member.type === 'get') {
                descriptor.get = this.makePropertyGetter(ref, metaId, member);
                if (member.writable) {
                    descriptor.set = this.makePropertySetter(ref, metaId, member);
                }
            }
            else if (member.type === 'value') {
                descriptor.value = member.value;
                descriptor.writable = member.writable;
            }
            Object.defineProperty(object, member.name, descriptor);
        }
    }
    // Populate object's prototype from descriptor.
    // This matches |getObjectPrototype| in rpc-server.
    setObjectPrototype(ref, object, metaId, descriptor) {
        if (descriptor === null)
            return;
        const proto = {};
        this.setObjectMembers(ref, proto, metaId, descriptor.members);
        this.setObjectPrototype(ref, proto, metaId, descriptor.proto);
        Object.setPrototypeOf(object, proto);
    }
    // Wrap function in Proxy for accessing remote properties
    proxyFunctionProperties(remoteMemberFunction, target, metaId, name) {
        let loaded = false;
        // Lazily load function properties
        const loadRemoteProperties = () => {
            if (loaded)
                return;
            loaded = true;
            const api = `remote-client: get ${getClassName(target)}.${name}`;
            const [meta, metrics] = this.sendSync(ipcMessages.remoteServerMemberGet, [metaId, name], api);
            if (this.hooks.memberGet) {
                this.hooks.memberGet(target, name, metrics);
            }
            this.setObjectMembers(remoteMemberFunction, remoteMemberFunction, meta.id, meta.members);
        };
        return new Proxy(remoteMemberFunction, {
            set: (target, property, value) => {
                if (property !== 'ref')
                    loadRemoteProperties();
                target[property] = value;
                return true;
            },
            get: (target, property) => {
                if (!Object.prototype.hasOwnProperty.call(target, property))
                    loadRemoteProperties();
                const value = target[property];
                if (property === 'toString' && typeof value === 'function') {
                    return value.bind(target);
                }
                return value;
            },
            ownKeys: (target) => {
                loadRemoteProperties();
                return Object.getOwnPropertyNames(target);
            },
            getOwnPropertyDescriptor: (target, property) => {
                const descriptor = Object.getOwnPropertyDescriptor(target, property);
                if (descriptor)
                    return descriptor;
                loadRemoteProperties();
                return Object.getOwnPropertyDescriptor(target, property);
            },
        });
    }
    makePropertyGetter(target, metaId, member) {
        return () => {
            const api = `remote-client: get ${getClassName(target)}.${member.name}`;
            const [result, metrics] = this.sendSync(ipcMessages.remoteServerMemberGet, [metaId, member.name], api);
            if (this.hooks.memberGet) {
                this.hooks.memberGet(target, member.name, metrics);
            }
            return this.metaToValue(result);
        };
    }
    makePropertySetter(target, metaId, member) {
        return (value) => {
            const args = this.wrapArgs([value]);
            const api = `remote-client: set ${getClassName(target)}.${member.name}`;
            const [result, metrics] = this.sendSync(ipcMessages.remoteServerMemberSet, [metaId, member.name, args], api);
            if (this.hooks.memberSet) {
                this.hooks.memberSet(target, member.name, metrics);
            }
            if (result != null)
                this.metaToValue(result);
            return value;
        };
    }
    makeRemoteMemberFunction(target, metaId, member) {
        // tslint:disable-next-line
        const self = this;
        const remoteMemberFunction = function (...args) {
            // tslint:disable-next-line:no-invalid-this
            const isConstructCall = this && this.constructor === remoteMemberFunction;
            const simpleArgs = self.enableOptimizationSimpleArgs && member.simpleArgs;
            if (!isConstructCall) {
                if (self.enableOptimizationVoid && member.returnType === 'void') {
                    const metrics = self.send(ipcMessages.remoteServerMemberCallAsync, metaId, member.name, self.wrapArgs(args, simpleArgs));
                    if (self.hooks.memberCall) {
                        self.hooks.memberCall(target, member.name, metrics);
                    }
                    return;
                }
                else if (self.enableOptimizationPromise && member.returnType === 'promise') {
                    return new Promise((resolve, reject) => {
                        args.push((error, result) => {
                            if (error) {
                                reject(error);
                            }
                            else {
                                resolve(result);
                            }
                        });
                        const metrics = self.send(ipcMessages.remoteServerMemberCallAsync, metaId, member.name, self.wrapArgs(args, simpleArgs));
                        if (self.hooks.memberCall) {
                            self.hooks.memberCall(target, member.name, metrics);
                        }
                    });
                }
            }
            const command = isConstructCall
                ? ipcMessages.remoteServerMemberConstructor
                : ipcMessages.remoteServerMemberCall;
            const api = `remote-client: ${isConstructCall ? 'new' : 'call'} ${getClassName(target)}.${member.name}()`;
            const [result, metrics] = self.sendSync(command, [metaId, member.name, self.wrapArgs(args, simpleArgs)], api);
            if (isConstructCall) {
                if (self.hooks.memberConstructor) {
                    self.hooks.memberConstructor(target, member.name, metrics);
                }
            }
            else {
                if (self.hooks.memberCall) {
                    self.hooks.memberCall(target, member.name, metrics);
                }
            }
            return self.metaToValue(result);
        };
        if (this.enableOptimizationConstant && member.returnType === 'constant') {
            return this.cacheReturnValue(remoteMemberFunction);
        }
        return remoteMemberFunction;
    }
    makeRemoteFunction(meta) {
        // tslint:disable-next-line
        const self = this;
        const remoteFunction = function (...args) {
            // tslint:disable-next-line:no-invalid-this
            const isConstructCall = this && this.constructor === remoteFunction;
            const simpleArgs = self.enableOptimizationSimpleArgs && meta.simpleArgs;
            if (!isConstructCall) {
                if (self.enableOptimizationVoid && meta.returnType === 'void') {
                    const metrics = self.send(ipcMessages.remoteServerFunctionCallAsync, meta.id, self.wrapArgs(args, simpleArgs));
                    if (self.hooks.functionCall) {
                        self.hooks.functionCall(meta.name, metrics);
                    }
                    return;
                }
                else if (self.enableOptimizationPromise && meta.returnType === 'promise') {
                    return new Promise((resolve, reject) => {
                        args.push((error, result) => {
                            if (error) {
                                reject(error);
                            }
                            else {
                                resolve(result);
                            }
                        });
                        const metrics = self.send(ipcMessages.remoteServerFunctionCallAsync, meta.id, self.wrapArgs(args, simpleArgs));
                        if (self.hooks.functionCall) {
                            self.hooks.functionCall(meta.name, metrics);
                        }
                    });
                }
            }
            const command = isConstructCall
                ? ipcMessages.remoteServerConstructor
                : ipcMessages.remoteServerFunctionCall;
            const api = `remote-client: ${isConstructCall ? 'new' : 'call'} ${meta.name}()`;
            const [result, metrics] = self.sendSync(command, [meta.id, self.wrapArgs(args, simpleArgs)], api);
            if (isConstructCall) {
                if (self.hooks.functionConstructor) {
                    self.hooks.functionConstructor(meta.name, metrics);
                }
            }
            else {
                if (self.hooks.functionCall) {
                    self.hooks.functionCall(meta.name, metrics);
                }
            }
            return self.metaToValue(result);
        };
        if (this.enableOptimizationConstant && meta.returnType === 'constant') {
            return this.cacheReturnValue(remoteFunction);
        }
        return remoteFunction;
    }
    cacheReturnValue(func) {
        let value;
        let cached = false;
        // tslint:disable-next-line:no-invalid-this
        return function (...args) {
            if (!cached) {
                // tslint:disable-next-line:no-invalid-this
                value = func.apply(this, args);
                cached = true;
            }
            return value;
        };
    }
    // Convert meta data from host into real value.
    metaToValue(meta) {
        if (meta.type === 'value') {
            return meta.value;
        }
        else if (meta.type === 'array') {
            return meta.members.map((member) => this.metaToValue(member));
        }
        else if (meta.type === 'buffer') {
            return Buffer.from(meta.value.buffer, meta.value.byteOffset, meta.value.byteLength);
        }
        else if (meta.type === 'promise') {
            return Promise.resolve({ then: this.metaToValue(meta.then) });
        }
        else if (meta.type === 'exception') {
            throw this.metaToValue(meta.value);
        }
        let ret;
        const cached = this.getCachedRemoteObject(meta.id);
        if (cached !== undefined) {
            return cached;
        }
        // A shadow class to represent the remote function object.
        if (meta.type === 'function') {
            ret = this.makeRemoteFunction(meta);
        }
        else {
            ret = {};
        }
        this.setObjectMembers(ret, ret, meta.id, meta.members);
        this.setObjectPrototype(ret, ret, meta.id, meta.proto);
        Object.defineProperty(ret.constructor, 'name', { value: meta.constructorName });
        // Track delegate obj's lifetime & tell host to clean up when object is GCed.
        this.electronIds.set(ret, meta.id);
        this.setCachedRemoteObject(meta.id, ret);
        return ret;
    }
}
exports.RemoteClient = RemoteClient;
function getClassName(obj) {
    return obj.constructor ? obj.constructor.name : '<object>';
}

},{"./lib/callbacks-registry":2,"./lib/ipc-messages":3,"./lib/utils":4,"events":undefined}],6:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const canvas_video_renderer_1 = require("./canvas-video-renderer");
const latency_tracer_1 = require("./latency-tracer");
const remote_client_1 = require("../remote-host/remote-client");
function initPluginHostClient(options) {
    const timeStart = performance.now();
    const host = options.initPluginHost();
    const duration = performance.now() - timeStart;
    const client = new remote_client_1.RemoteClient(host, {
        enableDirectChannel: options.pluginHostDirectChannel,
        enableTracing: options.pluginHostTracing,
    });
    client.on('using-direct-channel-changed', (value) => {
        console.log('using-direct-channel-changed', value);
    });
    if (options.pluginHostLatencyTracing) {
        const latencyTracer = new latency_tracer_1.LatencyTracer();
        latencyTracer.functionCall('initPluginHost', { duration });
        global['latencyTracer'] = latencyTracer;
        client.hooks = latencyTracer;
        client.require('ping');
    }
    return client;
}
let pluginHostClient;
function requireEx(name, options) {
    if (!options.usePluginHost) {
        return module.require(name);
    }
    pluginHostClient = pluginHostClient || initPluginHostClient(options);
    return pluginHostClient.require(name);
}
function setConstructorName(object, name) {
    object.constructor = () => { };
    Object.defineProperty(object.constructor, 'name', { value: name });
}
function loadSlimCore(options) {
    const slimcore = requireEx('slimcore', options);
    setConstructorName(slimcore, 'SlimCoreElectron');
    return slimcore;
}
function defineGetter(target, name, init) {
    let value;
    Object.defineProperty(target, name, {
        get: () => value || (value = init()),
        enumerable: false,
        configurable: false,
    });
}
function initSlimCore(options) {
    // https://domoreexp.visualstudio.com/Teamspace/_wiki/wikis/Teamspace.wiki/7258/Skype-Consumer-Client-IDs-(aka-Platform-IDs)
    const TEST_APP_PLATFORM_ID = 99005;
    if (!options.decoupledTrouterClient) {
        const slimcore = loadSlimCore(options);
        defineGetter(window, 'slimcore', () => {
            const platformId = options.useTestAppSpecificECSPlatformID ? TEST_APP_PLATFORM_ID : ((process.platform === 'darwin') ? 28 : 27);
            const logFileName = 'debug-' + new Date().getTime() + '.log';
            console.log(`Using platform id ${platformId}`);
            const slimCoreOptions = {
                version: `${platformId}/1.0.0.0/test/`,
                logFileName: logFileName,
                dataPath: options.slimcoreDataPath,
                mediaLogsPath: options.slimcoreMediaLogsPath,
                stdoutLogging: options.slimcoreStdoutLogging,
                isEncrypted: false,
            };
            const rtn = slimcore.createSlimCoreInstance(slimCoreOptions);
            rtn.setupSetStr('*Lib/ECS/Servers/1', 'https://config.teams.microsoft.com/config/v1/Teams/');
            return rtn;
        });
        return slimcore;
    }
    else {
        const platform = requireEx('slimcore/lib/platform', options);
        platform.init({
            logFilePath: `${options.slimcoreDataPath}/debug.log`,
            // The code above does isEncrypted: false, but it is not actually
            // taken into account inside SlimCore, so encrypt to behave the same
            logFileEncrypted: true,
            logToConsole: options.slimcoreStdoutLogging,
        });
        const trouterClient = requireEx('slimcore/lib/trouter-client', options);
        defineGetter(window, 'trouterclient', () => trouterClient);
        const slimcore = loadSlimCore(options);
        defineGetter(window, 'slimcore', () => {
            const platformId = options.useTestAppSpecificECSPlatformID ? TEST_APP_PLATFORM_ID : ((process.platform === 'darwin') ? 28 : 27);
            console.log(`Using platform id ${platformId}`);
            const slimCoreOptions = {
                version: `${platformId}/1.0.0.0/test/`,
                dataPath: options.slimcoreDataPath,
                skipRootToolsInit: true,
                externalTrouterClient: trouterClient.getNativeFunctions(),
            };
            const rtn = slimcore.createSlimCoreInstance(slimCoreOptions);
            rtn.setupSetStr('*Lib/ECS/Servers/1', 'https://config.teams.microsoft.com/config/v1/Teams/');
            return rtn;
        });
        return slimcore;
    }
}
function exposeSlimCore(options) {
    // tslint:disable-next-line:no-require-imports
    const videoRenderer = require('slimcore/lib/video-renderer');
    window['VideoRenderer'] = videoRenderer;
    window['CanvasVideoRenderer'] = canvas_video_renderer_1.CanvasVideoRenderer;
    defineGetter(window, 'SlimCore', () => initSlimCore(options));
}
exports.exposeSlimCore = exposeSlimCore;

},{"../remote-host/remote-client":5,"./canvas-video-renderer":7,"./latency-tracer":8,"slimcore/lib/video-renderer":1}],7:[function(require,module,exports){
/// <reference path="../../../lib/slimcore.d.ts" />
/// <reference path="../../../lib/video-renderer.d.ts" />
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const SET_VIDEO_PREFERENCE_DEBOUNCE_TIMEOUT = 1000;
// -----------------------------------------------------------------------------
const VERTEX_SHADER = `
    attribute vec4 position;
    attribute vec2 texCoord;

    varying vec2 v_texCoord;

    void main()
    {
        gl_Position = position;
        v_texCoord = texCoord;
    }
`;
const FRAGMENT_SHADER_COMMON = `
    precision mediump float;
    varying vec2 v_texCoord;

    vec4 yuv2rgb(float y, float u, float v)
    {
        y = (y - 0.0625) * 1.164;
        u = u - 0.5;
        v = v - 0.5;

        float r = y             + 2.018 * v;
        float g = y - 0.391 * u - 0.813 * v;
        float b = y + 1.596 * u            ;

        return vec4(r, g, b, 1.0);
    }
`;
const formats = {
    'BGRA': {
        'mapping': (gl, frame) => {
            return [{
                    'data': new Uint8Array(frame.data),
                    'width': frame.info.width,
                    'height': frame.info.height,
                    'stride': frame.info.stride,
                    'format': gl.RGBA,
                }];
        },
        'shader': `
            uniform sampler2D tex0;

            void main()
            {
                gl_FragColor = texture2D(tex0, v_texCoord).bgra;
            }
        `,
    },
    'I420': {
        'mapping': (gl, frame) => {
            const width = frame.info.width;
            const height = frame.info.height;
            const stride = frame.info.stride;
            const offset0 = 0;
            const size0 = stride * height;
            const offset1 = offset0 + size0;
            const size1 = size0 / 4;
            const offset2 = offset1 + size1;
            const size2 = size0 / 4;
            return [{
                    'data': new Uint8Array(frame.data, offset0, size0),
                    'width': width,
                    'height': height,
                    'stride': stride,
                    'format': gl.LUMINANCE,
                }, {
                    'data': new Uint8Array(frame.data, offset1, size1),
                    'width': width / 2,
                    'height': height / 2,
                    'stride': stride / 2,
                    'format': gl.LUMINANCE,
                }, {
                    'data': new Uint8Array(frame.data, offset2, size2),
                    'width': width / 2,
                    'height': height / 2,
                    'stride': stride / 2,
                    'format': gl.LUMINANCE,
                }];
        },
        'shader': `
            uniform sampler2D tex0;
            uniform sampler2D tex1;
            uniform sampler2D tex2;

            void main()
            {
                float y = texture2D(tex0, v_texCoord)[0];
                float u = texture2D(tex1, v_texCoord)[0];
                float v = texture2D(tex2, v_texCoord)[0];

                gl_FragColor = yuv2rgb(y, u, v);
            }
        `,
    },
    'NV12': {
        'mapping': (gl, frame) => {
            const width = frame.info.width;
            const height = frame.info.height;
            const stride = frame.info.stride;
            const offset0 = 0;
            const size0 = stride * height;
            const offset1 = offset0 + size0;
            const size1 = size0 / 2;
            return [{
                    'data': new Uint8Array(frame.data, offset0, size0),
                    'width': width,
                    'height': height,
                    'stride': stride,
                    'format': gl.LUMINANCE,
                }, {
                    'data': new Uint8Array(frame.data, offset1, size1),
                    'width': width / 2,
                    'height': height / 2,
                    'stride': stride,
                    'format': gl.LUMINANCE_ALPHA,
                }];
        },
        'shader': `
            uniform sampler2D tex0;
            uniform sampler2D tex1;

            void main()
            {
                float y = texture2D(tex0, v_texCoord)[0];
                float u = texture2D(tex1, v_texCoord)[0];
                float v = texture2D(tex1, v_texCoord)[%alpha%];

                gl_FragColor = yuv2rgb(y, u, v);
            }
        `,
    },
    'IMC4': {
        'mapping': (gl, frame) => {
            const width = frame.info.width;
            const height = frame.info.height;
            const stride = frame.info.stride;
            const offset0 = 0;
            const size0 = stride * height;
            const offset1 = offset0 + size0;
            const size1 = size0 / 2;
            return [{
                    'data': new Uint8Array(frame.data, offset0, size0),
                    'width': width,
                    'height': height,
                    'stride': stride,
                    'format': gl.LUMINANCE,
                }, {
                    'data': new Uint8Array(frame.data, offset1, size1),
                    'width': width,
                    'height': height / 2,
                    'stride': stride,
                    'format': gl.LUMINANCE,
                }];
        },
        'shader': `
            uniform sampler2D tex0;
            uniform sampler2D tex1;

            void main()
            {
                float y = texture2D(tex0, v_texCoord)[0];
                float u = texture2D(tex1, vec2(v_texCoord.x * 0.5,       v_texCoord.y))[0];
                float v = texture2D(tex1, vec2(v_texCoord.x * 0.5 + 0.5, v_texCoord.y))[0];

                gl_FragColor = yuv2rgb(y, u, v);
            }
        `,
    },
};
// -----------------------------------------------------------------------------
class GlResource {
    constructor(gl, handle) {
        this._isDisposed = false;
        this._context = gl;
        this._handle = handle;
    }
    get gl() {
        return this._context;
    }
    get handle() {
        return this._handle;
    }
    dispose() {
        delete this._context;
        delete this._handle;
        this._isDisposed = true;
    }
    isDisposed() {
        return this._isDisposed;
    }
}
// -----------------------------------------------------------------------------
class GlTexture extends GlResource {
    constructor(gl) {
        const texture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        super(gl, texture);
        this._width = null;
        this._height = null;
        this._format = null;
    }
    static alignStride(stride) {
        // tslint:disable-next-line:no-bitwise
        return GlTexture._textureUnpackAlignmentMap[stride & 7];
    }
    bind(unit) {
        this.gl.activeTexture(this.gl.TEXTURE0 + (unit || 0));
        this.gl.bindTexture(this.gl.TEXTURE_2D, this.handle);
    }
    update(width, height, format, data) {
        this.gl.bindTexture(this.gl.TEXTURE_2D, this.handle);
        const internalFormat = this._getInternalFormat(format);
        if (this._width !== width || this._height !== height || this._format !== format) {
            this.gl.texImage2D(this.gl.TEXTURE_2D, 0, internalFormat, width, height, 0, format, this.gl.UNSIGNED_BYTE, data);
        }
        else {
            this.gl.texSubImage2D(this.gl.TEXTURE_2D, 0, 0, 0, width, height, format, this.gl.UNSIGNED_BYTE, data);
        }
        this._width = width;
        this._height = height;
        this._format = format;
    }
    dispose() {
        if (this.handle) {
            this.gl.deleteTexture(this.handle);
        }
        super.dispose();
        delete this._width;
        delete this._height;
        delete this._format;
    }
    _getInternalFormat(format) {
        switch (format) {
            case this.gl.RED:
                return this.gl.R8;
            case this.gl.RG:
                return this.gl.RG8;
            default:
                return format;
        }
    }
}
GlTexture._textureUnpackAlignmentMap = [8, 1, 2, 1, 4, 1, 2, 1];
// -----------------------------------------------------------------------------
class GlArrayBuffer extends GlResource {
    constructor(gl) {
        super(gl, gl.createBuffer());
        this._data = null;
    }
    bind() {
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.handle);
    }
    update(data) {
        if (isArrayBufferViewEqual(data, this._data)) {
            return;
        }
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.handle);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, data, this.gl.STATIC_DRAW);
        this._data = data;
    }
    dispose() {
        if (this.handle) {
            this.gl.deleteBuffer(this.handle);
        }
        super.dispose();
    }
}
// -----------------------------------------------------------------------------
class GlShader extends GlResource {
    constructor(gl, shaderType, shaderSource) {
        const shader = gl.createShader(shaderType);
        gl.shaderSource(shader, shaderSource);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS) && !gl.isContextLost()) {
            const lastError = gl.getShaderInfoLog(shader);
            gl.deleteShader(shader);
            throw new Error(`Shader compilation failed: ${lastError}`);
        }
        super(gl, shader);
    }
    dispose() {
        if (this.handle) {
            this.gl.deleteShader(this.handle);
        }
        super.dispose();
    }
}
// -----------------------------------------------------------------------------
class GlProgram extends GlResource {
    constructor(gl, vertexShader, fragmentShader) {
        const program = gl.createProgram();
        gl.attachShader(program, vertexShader.handle);
        gl.attachShader(program, fragmentShader.handle);
        gl.linkProgram(program);
        gl.detachShader(program, vertexShader.handle);
        gl.detachShader(program, fragmentShader.handle);
        vertexShader.dispose();
        fragmentShader.dispose();
        if (!gl.getProgramParameter(program, gl.LINK_STATUS) && !gl.isContextLost()) {
            const lastError = gl.getProgramInfoLog(program);
            gl.deleteProgram(program);
            throw new Error(`Program linking failed: ${lastError}`);
        }
        super(gl, program);
    }
    getAttribLocation(name) {
        return this.gl.getAttribLocation(this.handle, name);
    }
    getUniformLocation(name) {
        return this.gl.getUniformLocation(this.handle, name);
    }
    dispose() {
        if (this.handle) {
            this.gl.deleteProgram(this.handle);
        }
        super.dispose();
    }
}
// -----------------------------------------------------------------------------
function isArrayBufferViewEqual(buf1, buf2) {
    if (buf1 === buf2)
        return true;
    if (!buf1 || !buf2)
        return false;
    const array1 = new Int8Array(buf1.buffer, buf1.byteOffset, buf1.byteLength);
    const array2 = new Int8Array(buf2.buffer, buf2.byteOffset, buf2.byteLength);
    if (array1.length !== array2.length)
        return false;
    for (let i = 0; i !== array1.length; i++) {
        if (array1[i] !== array2[i])
            return false;
    }
    return true;
}
// -----------------------------------------------------------------------------
class Point {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
    static swap(p1, p2) {
        const x = p2.x;
        const y = p2.y;
        p2.x = p1.x;
        p2.y = p1.y;
        p1.x = x;
        p1.y = y;
    }
    transpose() {
        const tmp = this.x;
        this.x = this.y;
        this.y = tmp;
    }
    translate(offset) {
        this.x += offset.x;
        this.y += offset.y;
    }
}
// -----------------------------------------------------------------------------
class Rectangle {
    constructor(p1, p2) {
        this.p1 = p1;
        this.p2 = p2;
    }
    static uniform() {
        return new Rectangle(new Point(-1.0, -1.0), new Point(+1.0, +1.0));
    }
    applyScalingMode(mode, inputRatio, outputRatio) {
        for (const point of [this.p1, this.p2]) {
            if (mode === 2 /* Fit */) {
                if (inputRatio > outputRatio) {
                    point.y = point.y / inputRatio * outputRatio;
                }
                else {
                    point.x = point.x * inputRatio / outputRatio;
                }
            }
            else if (mode === 1 /* Crop */) {
                if (inputRatio < outputRatio) {
                    point.y = point.y / inputRatio * outputRatio;
                }
                else {
                    point.x = point.x * inputRatio / outputRatio;
                }
            }
        }
    }
    applyCropOffset(offset, bounds) {
        const x = Math.max(Math.min(offset.x, bounds.p1.x - this.p1.x), bounds.p2.x - this.p2.x);
        const y = Math.max(Math.min(offset.y, bounds.p1.y - this.p1.y), bounds.p2.y - this.p2.y);
        const safeOffset = new Point(x, y);
        this.p1.translate(safeOffset);
        this.p2.translate(safeOffset);
    }
    getCenterPoint() {
        const x = (this.p1.x + this.p2.x) / 2;
        const y = (this.p1.y + this.p2.y) / 2;
        return new Point(x, y);
    }
    toVertices() {
        return new Vertices([
            new Point(this.p1.x, this.p1.y),
            new Point(this.p1.x, this.p2.y),
            new Point(this.p2.x, this.p2.y),
            new Point(this.p2.x, this.p1.y),
        ]);
    }
}
// -----------------------------------------------------------------------------
class Vertices {
    constructor(vertices) {
        this._vertices = vertices;
    }
    mirror() {
        Point.swap(this._vertices[1], this._vertices[2]);
        Point.swap(this._vertices[0], this._vertices[3]);
    }
    getTriangleData() {
        const data = [];
        const indexes = [0, 1, 2, 2, 3, 0];
        for (const i of indexes) {
            data.push(this._vertices[i].x, this._vertices[i].y);
        }
        return new Float32Array(data);
    }
}
// -----------------------------------------------------------------------------
class NoopLogger {
    createChild() { return this; }
    log() { }
    debug() { }
    info() { }
    warn() { }
    error() { }
}
class LoggerProxy {
    constructor(_context, _logger, _frameSink) {
        this._context = _context;
        this._logger = _logger;
        this._frameSink = _frameSink;
    }
    log(message) {
        this._logger.log(message);
        this._log(0 /* Default */, message);
    }
    debug(message) {
        this._logger.debug(message);
        this._log(1 /* Debug */, message);
    }
    info(message) {
        this._logger.info(message);
        this._log(2 /* Info */, message);
    }
    warn(message) {
        this._logger.warn(message);
        this._log(3 /* Warning */, message);
    }
    error(message) {
        this._logger.error(message);
        this._log(4 /* Error */, message);
    }
    _log(level, message) {
        try {
            if (this._frameSink.log) {
                this._frameSink.log(level, `${this._context}: ${message}`);
            }
        }
        catch (error) {
            // ignore
        }
    }
}
// -----------------------------------------------------------------------------
let uniqueId = 0;
function getUniqueId() {
    return ++uniqueId;
}
// -----------------------------------------------------------------------------
class CanvasVideoRenderer extends events_1.EventEmitter {
    constructor(args, _frameSink) {
        super();
        this._frameSink = _frameSink;
        this._context = null;
        this._contextIsWebGL2 = false;
        this._scalingMode = 0 /* Stretch */;
        this._program = null;
        this._verticesBuffer = null;
        this._texCoordBuffer = null;
        this._textures = [];
        this._textureLocations = [];
        this._mirror = false;
        this._format = null;
        this._timer = null;
        this._cropInfo = null;
        this._alignment = null;
        this._videoWidth = 0;
        this._videoHeight = 0;
        this._pendingTimeout = null;
        this._cleanupHandlers = [];
        const context = `CanvasVideoRenderer #${getUniqueId()}`;
        const childLogger = (args.logger || new NoopLogger()).createChild(context);
        this._logger = new LoggerProxy(context, childLogger, _frameSink);
        this._scalingMode = args.scalingMode;
        this._logger.debug(`constructor - args: ${JSON.stringify({
            transparent: args.transparent,
            scalingMode: getScalingMode(args.scalingMode),
        })}`);
        this._initialize(args);
    }
    static isAvailable() {
        if (!createFrameSinkReader) {
            return false;
        }
        const attributes = {
            'powerPreference': 'low-power',
        };
        return !!document.createElement('canvas').getContext('webgl', attributes);
    }
    getFrameSink() {
        return this._frameSink;
    }
    getVideoSize() {
        return {
            'width': this._videoWidth,
            'height': this._videoHeight,
        };
    }
    setScalingMode(mode) {
        this._logger.debug(`setScalingMode: ${mode}`);
        this._scalingMode = mode;
        this._render();
        return Promise.resolve();
    }
    dispose() {
        if (this._logger) {
            this._logger.debug('dispose');
        }
        if (this._timer) {
            cancelAnimationFrame(this._timer);
        }
        if (this._program) {
            this._program.dispose();
        }
        if (this._verticesBuffer) {
            this._verticesBuffer.dispose();
        }
        if (this._texCoordBuffer) {
            this._texCoordBuffer.dispose();
        }
        if (this._textures) {
            this._textures.forEach((texture) => texture.dispose());
        }
        if (this._context && this._context.canvas) {
            this._context.canvas.remove();
        }
        if (this._frameSink) {
            this._frameSink.dispose();
        }
        if (this._frameSinkReader) {
            this._frameSinkReader.dispose();
        }
        if (this._pendingTimeout) {
            clearTimeout(this._pendingTimeout);
        }
        if (this._cleanupHandlers) {
            this._cleanupHandlers.forEach((handler) => handler());
        }
        delete this._logger;
        delete this._frameSink;
        delete this._frameSinkReader;
        delete this._context;
        delete this._scalingMode;
        delete this._program;
        delete this._verticesBuffer;
        delete this._texCoordBuffer;
        delete this._textures;
        delete this._textureLocations;
        delete this._mirror;
        delete this._format;
        delete this._timer;
        delete this._cropInfo;
        delete this._alignment;
        delete this._videoWidth;
        delete this._videoHeight;
        delete this._pendingTimeout;
        delete this._cleanupHandlers;
        delete this._currentFrame;
    }
    _createContext(canvas, args) {
        const attributes = {
            'alpha': args.transparent,
            'depth': false,
            'stencil': false,
            'antialias': false,
            'premultipliedAlpha': false,
            'preserveDrawingBuffer': false,
            'powerPreference': 'low-power',
        };
        const context = canvas.getContext('webgl2', attributes) || canvas.getContext('webgl', attributes);
        if (!context) {
            this._logger.error('WebGL context init failed');
            throw new Error('WebGL context init failed');
        }
        return context;
    }
    _createProgram(format) {
        const gl = this._context;
        if (!format)
            return null;
        const formatInfo = formats[format];
        if (!formatInfo) {
            this._logger.warn(`Invalid format: ${format}`);
            return null;
        }
        const fragmentShaderSource = FRAGMENT_SHADER_COMMON
            + formatInfo.shader.replace('%alpha%', this._contextIsWebGL2 ? '1' : '3');
        const vertexShader = new GlShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
        const fragmentShader = new GlShader(gl, gl.FRAGMENT_SHADER, fragmentShaderSource);
        return new GlProgram(gl, vertexShader, fragmentShader);
    }
    _initProgram(format) {
        const gl = this._context;
        const program = this._createProgram(format);
        if (!program) {
            this._textureLocations = [];
            return null;
        }
        const positionLocation = program.getAttribLocation('position');
        this._getVerticesBuffer().bind();
        gl.enableVertexAttribArray(positionLocation);
        gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
        const texCoordLocation = program.getAttribLocation('texCoord');
        this._getTexCoordBuffer().bind();
        gl.enableVertexAttribArray(texCoordLocation);
        gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
        this._textureLocations = [
            program.getUniformLocation('tex0'),
            program.getUniformLocation('tex1'),
            program.getUniformLocation('tex2'),
        ];
        return program;
    }
    _mapTextureFormat(format) {
        const gl = this._context;
        switch (format) {
            case gl.LUMINANCE:
                return gl.RED;
            case gl.LUMINANCE_ALPHA:
                return gl.RG;
            default:
                return format;
        }
    }
    _mapFrameToTextures(frame) {
        if (!frame)
            return [];
        const formatInfo = formats[frame.info.format];
        if (!formatInfo)
            return [];
        const result = formatInfo.mapping(this._context, frame);
        if (!this._contextIsWebGL2)
            return result;
        for (const item of result) {
            item.format = this._mapTextureFormat(item.format);
        }
        return result;
    }
    _setUnpackAlignment(alignment) {
        const gl = this._context;
        if (this._alignment !== alignment) {
            gl.pixelStorei(gl.UNPACK_ALIGNMENT, alignment);
        }
        this._alignment = alignment;
    }
    _updateTextures(frame) {
        const input = this._mapFrameToTextures(frame);
        while (this._textures.length < input.length) {
            this._textures.push(new GlTexture(this._context));
        }
        input.forEach((item, i) => {
            this._setUnpackAlignment(GlTexture.alignStride(item.stride));
            this._textures[i].update(item.width, item.height, item.format, item.data);
        });
        while (this._textures.length > input.length) {
            this._textures.pop().dispose();
        }
    }
    _updateProgram(format) {
        const gl = this._context;
        if (format === this._format)
            return;
        this._logger.debug(`format: ${format}`);
        if (this._program) {
            this._program.dispose();
        }
        const program = this._initProgram(format);
        this._program = program;
        this._format = format;
        gl.useProgram(program ? program.handle : null);
    }
    _getCropOffset(cropInfo) {
        const rect = Rectangle.uniform();
        const p1 = new Point(this._mirror ? cropInfo.rightOffset : cropInfo.leftOffset, cropInfo.bottomOffset);
        const p2 = new Point(this._mirror ? cropInfo.leftOffset : cropInfo.rightOffset, cropInfo.topOffset);
        rect.p1.x -= p1.x / this._videoWidth * 2;
        rect.p1.y -= p1.y / this._videoHeight * 2;
        rect.p2.x += p2.x / this._videoWidth * 2;
        rect.p2.y += p2.y / this._videoHeight * 2;
        rect.applyScalingMode(this._scalingMode, this._getInputRatio(), this._getOutputRatio());
        return rect.getCenterPoint();
    }
    _updateVertices() {
        const rect = Rectangle.uniform();
        rect.applyScalingMode(this._scalingMode, this._getInputRatio(), this._getOutputRatio());
        if (this._cropInfo && this._scalingMode === 1 /* Crop */) {
            const offset = this._getCropOffset(this._cropInfo);
            const bounds = Rectangle.uniform();
            rect.applyCropOffset(offset, bounds);
        }
        const vertices = rect.toVertices();
        if (this._mirror) {
            vertices.mirror();
        }
        this._getVerticesBuffer().update(vertices.getTriangleData());
    }
    _updateTextureCoords(info) {
        const left = 0.0 + (info && info.width ? info.padding.leftOffset / info.width : 0);
        const right = 1.0 - (info && info.width ? info.padding.rightOffset / info.width : 0);
        const top = 0.0 + (info && info.height ? info.padding.topOffset / info.height : 0);
        const bottom = 1.0 - (info && info.height ? info.padding.bottomOffset / info.height : 0);
        const texels = new Vertices([
            new Point(left, bottom),
            new Point(left, top),
            new Point(right, top),
            new Point(right, bottom),
        ]);
        this._getTexCoordBuffer().update(texels.getTriangleData());
    }
    _getVerticesBuffer() {
        if (!this._verticesBuffer) {
            this._verticesBuffer = new GlArrayBuffer(this._context);
        }
        return this._verticesBuffer;
    }
    _getTexCoordBuffer() {
        if (!this._texCoordBuffer) {
            this._texCoordBuffer = new GlArrayBuffer(this._context);
        }
        return this._texCoordBuffer;
    }
    _getInputRatio() {
        return this._videoWidth / this._videoHeight;
    }
    _getOutputRatio() {
        return this._context.drawingBufferWidth / this._context.drawingBufferHeight;
    }
    _render() {
        const gl = this._context;
        gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
        gl.clearColor(0, 0, 0, 0);
        gl.clear(gl.COLOR_BUFFER_BIT);
        if (!this._program || this._textures.length === 0)
            return;
        this._textures.forEach((texture, i) => {
            texture.bind(i);
            gl.uniform1i(this._textureLocations[i], i);
        });
        this._updateVertices();
        gl.drawArrays(gl.TRIANGLES, 0, 6);
    }
    _resize() {
        const gl = this._context;
        const scale = window.devicePixelRatio || 1;
        const displayWidth = Math.floor(gl.canvas.clientWidth * scale);
        const displayHeight = Math.floor(gl.canvas.clientHeight * scale);
        if (gl.canvas.width !== displayWidth || gl.canvas.height !== displayHeight) {
            gl.canvas.width = displayWidth;
            gl.canvas.height = displayHeight;
            this._setVideoPreference(gl.drawingBufferWidth, gl.drawingBufferHeight);
            return true;
        }
        return false;
    }
    _checkVideoSize(frame) {
        const videoWidth = frame ? frame.info.origWidth : 0;
        const videoHeight = frame ? frame.info.origHeight : 0;
        if (this._videoWidth !== videoWidth || this._videoHeight !== videoHeight) {
            this._videoWidth = videoWidth;
            this._videoHeight = videoHeight;
            this._logger.debug(`video-size-changed: ${videoWidth} x ${videoHeight}`);
            this.emit('video-size-changed', this.getVideoSize());
        }
    }
    _updateFrame(frame) {
        this._checkVideoSize(frame);
        this._updateProgram(frame ? frame.info.format : null);
        this._updateTextureCoords(frame ? frame.info : null);
        this._updateTextures(frame);
        this._cropInfo = frame ? frame.info.cropInfo : null;
        this._mirror = frame ? frame.info.mirror : false;
    }
    _drawFrame() {
        if (!this._frameSink)
            return;
        const frame = this._currentFrame;
        const frameUpdated = frame !== undefined;
        this._currentFrame = undefined;
        if (frameUpdated) {
            this._updateFrame(frame);
        }
        if (this._resize() || frameUpdated) {
            this._render();
        }
        this._timer = requestAnimationFrame(this._drawFrame.bind(this));
    }
    _handleContextRestored() {
        this._logger.debug('requestAnimationFrame');
        this._timer = requestAnimationFrame(this._drawFrame.bind(this));
    }
    _handleContextLost() {
        this._logger.debug('cancelAnimationFrame');
        cancelAnimationFrame(this._timer);
        this._program = null;
        this._verticesBuffer = null;
        this._texCoordBuffer = null;
        this._textures = [];
        this._textureLocations = [];
        this._format = null;
        this._timer = null;
        this._alignment = null;
    }
    _initialize(args) {
        const document = args.container.ownerDocument;
        const canvas = document.createElement('canvas');
        this._addElementToContainer(canvas, args.container);
        this._addEventListener(canvas, 'webglcontextcreationerror', (event) => {
            this._logger.error(event.statusMessage);
        });
        this._context = this._createContext(canvas, args);
        this._contextIsWebGL2 = this._context instanceof WebGL2RenderingContext;
        this._logger.info(`Using WebGL context version: ${this._contextIsWebGL2 ? '2' : '1'}`);
        this._addEventListener(this._context.canvas, 'webglcontextlost', (event) => {
            this._logger.warn('WebGLRenderingContext lost');
            event.preventDefault();
            this._handleContextLost();
        });
        this._addEventListener(this._context.canvas, 'webglcontextrestored', (event) => {
            this._logger.warn('WebGLRenderingContext restored');
            this._handleContextRestored();
        });
        const bufferName = this._frameSink.getBufferName();
        this._addEventListener(document.defaultView, 'message', (event) => {
            if (event.data.bufferName === bufferName) {
                if (event.data.frame !== undefined) {
                    this._currentFrame = event.data.frame;
                }
                if (event.data.message !== undefined) {
                    this._log(event.data.level, event.data.message);
                }
            }
        });
        this._frameSinkReader = createFrameSinkReader(bufferName);
        this._handleContextRestored();
    }
    _addElementToContainer(element, container) {
        element.style.width = '100%';
        element.style.height = '100%';
        if (container.hasChildNodes()) {
            this._logger.warn('Appending to a non-empty container');
        }
        container.appendChild(element);
    }
    _addEventListener(element, type, listener) {
        element.addEventListener(type, listener);
        this._cleanupHandlers.push(() => element.removeEventListener(type, listener));
    }
    _setVideoPreference(width, height) {
        if (this._pendingTimeout) {
            clearTimeout(this._pendingTimeout);
        }
        const handler = () => {
            this._pendingTimeout = null;
            this._logger.debug(`setVideoPreference: ${width} x ${height} @dpi ${devicePixelRatio}`);
            this._frameSink.setVideoPreference(width, height);
        };
        this._pendingTimeout = setTimeout(handler, SET_VIDEO_PREFERENCE_DEBOUNCE_TIMEOUT);
    }
    _log(level, message) {
        switch (level) {
            case 'default':
                this._logger.log(message);
                break;
            case 'debug':
                this._logger.debug(message);
                break;
            case 'info':
                this._logger.info(message);
                break;
            case 'warning':
                this._logger.warn(message);
                break;
            case 'error':
                this._logger.error(message);
                break;
            default:
                throw new Error(`Unexpected level: ${level}`);
        }
    }
}
exports.CanvasVideoRenderer = CanvasVideoRenderer;
// -----------------------------------------------------------------------------
function getScalingMode(mode) {
    switch (mode) {
        case 0 /* Stretch */:
            return 'stretch';
        case 1 /* Crop */:
            return 'crop';
        case 2 /* Fit */:
            return 'fit';
        default:
            return undefined;
    }
}

},{"events":undefined}],8:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class LatencyTracer {
    constructor() {
        this._methods = new Map();
        this._messages = [];
        this._totalMessages = LatencyTracer.makeMessageCounts();
        this._startTime = performance.now();
    }
    static roundTo(x, n) {
        return Math.round(x * Math.pow(10, n)) / Math.pow(10, n);
    }
    static makeMethodCounts() {
        return {
            count: 0,
            duration: 0,
            durationInHost: 0,
        };
    }
    static makeMessageCounts() {
        return {
            incomingMessage: 0,
            outgoingMessage: 0,
            outgoingMessageSync: 0,
        };
    }
    incomingMessage() {
        this._getMessageBucket().incomingMessage += 1;
        this._totalMessages.incomingMessage += 1;
    }
    outgoingMessage() {
        this._getMessageBucket().outgoingMessage += 1;
        this._totalMessages.outgoingMessage += 1;
    }
    outgoingMessageSync() {
        this._getMessageBucket().outgoingMessageSync += 1;
        this._totalMessages.outgoingMessageSync += 1;
    }
    require(module, metrics) {
        this._addMethodCall(`require('${module}')`, metrics);
    }
    functionConstructor(name, metrics) {
        this._addMethodCall(`new ${name || 'Function'}()`, metrics);
    }
    functionCall(name, metrics) {
        this._addMethodCall(`${name || 'Function'}()`, metrics);
    }
    memberConstructor(target, name, metrics) {
        this._addMethodCall(`new ${target.constructor.name}::${name}()`, metrics);
    }
    memberCall(target, name, metrics) {
        this._addMethodCall(`${target.constructor.name}::${name}()`, metrics);
    }
    memberGet(target, name, metrics) {
        this._addMethodCall(`get ${target.constructor.name}::${name}`, metrics);
    }
    memberSet(target, name, metrics) {
        this._addMethodCall(`set ${target.constructor.name}::${name}`, metrics);
    }
    reset() {
        this._methods.clear();
        this._messages = [];
        this._totalMessages = LatencyTracer.makeMessageCounts();
        this._startTime = performance.now();
    }
    dump() {
        console.group('IPC messages');
        console.table(this._messages);
        console.table(this._totalMessages);
        console.groupEnd();
        console.group('method calls');
        console.table(this._getMethodData());
        console.groupEnd();
    }
    _getMessageBucket() {
        const timestamp = performance.now();
        const index = Math.floor((timestamp - this._startTime) / 1000);
        return this._messages[index] = this._messages[index] || LatencyTracer.makeMessageCounts();
    }
    _addMethodCall(method, metrics) {
        if (metrics.async) {
            method += ' async';
        }
        if (!this._methods.has(method)) {
            this._methods.set(method, LatencyTracer.makeMethodCounts());
        }
        const data = this._methods.get(method);
        data.count += 1;
        data.duration += metrics.duration || 0;
        data.durationInHost += metrics.durationInHost || 0;
    }
    _getMethodData() {
        const result = {};
        for (const [method, data] of this._methods) {
            result[method] = {
                '# of calls': data.count,
                'total latency (avg)': LatencyTracer.roundTo(data.duration / data.count, 3),
                'native latency (avg)': LatencyTracer.roundTo(data.durationInHost / data.count, 3),
                'IPC overhead (avg)': LatencyTracer.roundTo((data.duration - data.durationInHost) / data.count, 3),
            };
        }
        return result;
    }
}
exports.LatencyTracer = LatencyTracer;

},{}],9:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const calling_1 = require("../calling");
const utils_1 = require("../utils");
const options = utils_1.invokeSync('get-options');
if (process.sandboxed || process.contextIsolated) {
    options.usePluginHost = true;
}
if (options.enableWatchdog) {
    process.startWatchdog(5000, { pingInterval: 1000 });
}
function initPluginHost() {
    const pluginHostId = utils_1.invokeSync('init-plugin-host');
    return {
        id: pluginHostId,
        contextId: process.contextId,
        send(channel, args) {
            return electron_1.ipcRenderer.sendToRenderer(pluginHostId, channel, args);
        },
        sendSync(channel, args, watchdogApi) {
            return electron_1.ipcRenderer.sendToRendererSync(pluginHostId, channel, args, watchdogApi);
        },
        connect() {
            return electron_1.ipcRenderer.connectToRenderer(pluginHostId);
        },
        on(channel, listener) {
            electron_1.ipcRenderer.on(channel, (event, ...args) => {
                if (event.senderId === pluginHostId) {
                    listener(event, ...args);
                }
            });
        },
    };
}
function exposeGlobal(name, value) {
    if (process.contextIsolated) {
        electron_1.contextBridge.exposeInMainWorld(name, value);
    }
    else {
        global[name] = value;
    }
}
function exposeModules() {
    exposeGlobal('options', options);
    exposeGlobal('electronIpc', utils_1.electronIpc);
    exposeGlobal('crash', process.crash);
    exposeGlobal('hang', process.hang);
    exposeGlobal('createFrameSinkReader', utils_1.createFrameSinkReader);
    if (process.contextIsolated) {
        electron_1.contextBridge.exposeInMainWorld('initPluginHost', initPluginHost);
        utils_1.executePreload(utils_1.invokeSync('get-preload-main-world'));
    }
    else {
        process.once('loaded', () => { window['Buffer'] = Buffer; });
        calling_1.exposeSlimCore(Object.assign({}, options, { initPluginHost }));
    }
}
if (location.origin === 'file://' || location.href === 'about:blank') {
    exposeModules();
}
// index.js: Object.defineProperty(exports, "__esModule", { value: true });
electron_1.webFrame.executeJavaScript(`var exports = {};`);
console.log('pid', process.pid);
console.log('sandbox', !!process.sandboxed);
console.log('contextIsolation', process.contextIsolated);
console.log('electron.version', process.versions.electron);
console.log('electron.build', process.versions['microsoft-build']);

},{"../calling":6,"../utils":10,"electron":undefined}],10:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
exports.electronIpc = {
    send: electron_1.ipcRenderer.send.bind(electron_1.ipcRenderer),
    sendSync: electron_1.ipcRenderer.sendSync.bind(electron_1.ipcRenderer),
    on: electron_1.ipcRenderer.on.bind(electron_1.ipcRenderer),
    once: electron_1.ipcRenderer.once.bind(electron_1.ipcRenderer),
};
function invokeSync(command, ...args) {
    const [error, result] = electron_1.ipcRenderer.sendSync(command, ...args);
    if (error) {
        throw error;
    }
    else {
        return result;
    }
}
exports.invokeSync = invokeSync;
function executePreload(preload) {
    electron_1.webFrame.executeJavaScript(`(() => {${preload}})();`);
}
exports.executePreload = executePreload;
function createFrameSinkReaderImpl(bufferName) {
    const reader = new electron_1.FrameSinkReader();
    reader.on('log', (level, message) => {
        postMessage({ bufferName, level, message }, '*');
    });
    const processFrame = () => {
        const frame = reader.getFrame();
        if (frame !== undefined) {
            postMessage({ bufferName, frame }, '*');
        }
    };
    if (!reader.connect(bufferName, true)) {
        throw new Error('FrameSinkReader.prototype.connect() failed');
    }
    let handle;
    const tick = () => {
        processFrame();
        handle = requestAnimationFrame(tick);
    };
    if (reader.isNewFrameEventAvailable) {
        reader.on('new-frame', processFrame);
    }
    else {
        handle = requestAnimationFrame(tick);
    }
    return {
        dispose: () => {
            cancelAnimationFrame(handle);
            reader.disconnect();
        },
    };
}
exports.createFrameSinkReader = electron_1.FrameSinkReader ? createFrameSinkReaderImpl : undefined;

},{"electron":undefined}]},{},[9]);

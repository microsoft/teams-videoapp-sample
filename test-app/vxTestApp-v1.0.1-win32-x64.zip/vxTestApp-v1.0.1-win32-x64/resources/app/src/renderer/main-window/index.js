"use strict";
/// <reference path="../../../../lib/slimcore-private.d.ts" />
/// <reference path="../../../../lib/video-renderer.d.ts" />
/// <reference path="../../../../lib/trouter-client.d.ts" />
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
electronIpc.send('page-ready');
var Enums = SlimCore.Enums;
const propKeyEnums = {
    [Enums.Property.AccountStatus]: Enums.AccountStatus,
    [Enums.Property.CallStatus]: Enums.CallStatus,
    [Enums.Property.ContentSharingFailureReason]: Enums.ContentSharingFailureReason,
    [Enums.Property.ContentSharingStatus]: Enums.ContentSharingStatus,
    [Enums.Property.DataChannelStatus]: Enums.DataChannelStatus,
    [Enums.Property.ParticipantContentRole]: Enums.ContentSharingRole,
    [Enums.Property.ParticipantFailureReason]: Enums.ParticipantFailureReason,
    [Enums.Property.ParticipantIdentity]: Enums.IdentityType,
    [Enums.Property.ParticipantStatus]: Enums.CallStatus,
    [Enums.Property.VideoStatus]: Enums.VideoStatus,
    [Enums.Property.VideoType]: Enums.VideoType,
};
function prettifyValue(propKey, value) {
    const propKeyEnum = propKeyEnums[propKey];
    if (!propKeyEnum)
        return value;
    return propKeyEnum[value] || value;
}
function prettifyObjectPropertyChangedArgs(args) {
    return {
        objectId: args.objectId,
        objectType: Enums.ObjectType[args.objectType] || args.objectType,
        propKey: Enums.Property[args.propKey] || args.propKey,
        value: prettifyValue(args.propKey, args.value),
    };
}
function prettifyQualityChangedArgs(args) {
    return {
        objectId: args.objectId,
        objectType: Enums.ObjectType[args.objectType] || args.objectType,
        type: Enums.QualityEventType[args.type] || args.type,
        value: Enums.QualityLevel[args.value] || args.value,
        mediaType: Enums.MediaType[args.mediaType] || args.mediaType,
    };
}
function prettifyAudioStreamStateChangedArgs(args) {
    return {
        callObjectId: args.callObjectId,
        direction: Enums.MediaDirection[args.direction] || args.direction,
        streamState: Enums.MediaStreamState[args.streamState] || args.streamState,
    };
}
function prettifyDataDeviceEvent(args) {
    return {
        event: Enums.DataDeviceEvent[args.event] || args.event,
    };
}
function enableTracing() {
    const slimcore = window['SlimCore'];
    const videoRenderer = window['VideoRenderer'];
    const methodsToIgnore = new Set();
    if (!options.usePluginHost) {
        methodsToIgnore.add(slimcore.ChromiumFrameSink.prototype.log);
    }
    function hookMethod(object, name) {
        const origMethod = object[name];
        if (!origMethod)
            return;
        if (name === 'emit')
            return;
        if (methodsToIgnore.has(origMethod))
            return;
        object[name] = function () {
            const method = `${object.constructor.name}::${name}`;
            console.time(method);
            console.log(method, arguments);
            // tslint:disable-next-line:no-invalid-this
            const result = origMethod.apply(this, arguments);
            const finish = (value) => {
                console.timeEnd(method);
                console.log(value);
                return value;
            };
            if (result instanceof Promise) {
                return result.then(finish);
            }
            else {
                return finish(result);
            }
        };
    }
    const emitHooked = Symbol('emitHooked');
    function hookEmit(object) {
        if (object[emitHooked])
            return;
        const emit = object.emit;
        object.emit = function (event, ...args) {
            if (event === 'object-property-changed') {
                args = [prettifyObjectPropertyChangedArgs(args[0])];
            }
            else if (event === 'quality-changed') {
                args = [prettifyQualityChangedArgs(args[0])];
            }
            else if (event === 'audio-stream-state-changed') {
                args = [prettifyAudioStreamStateChangedArgs(args[0])];
            }
            else if (event === 'event') {
                args = [prettifyDataDeviceEvent(args[0])];
            }
            // tslint:disable-next-line:no-invalid-this
            console.log(`${this.constructor.name}::emit`, event, ...args);
            // tslint:disable-next-line:no-invalid-this
            return emit.apply(this, arguments);
        };
        object[emitHooked] = true;
    }
    function hookMethods(object) {
        for (const [name, value] of Object.entries(object)) {
            if (typeof value === 'function') {
                hookMethod(object, name);
            }
        }
    }
    function hookClass(cls) {
        if (!cls)
            return;
        hookMethods(cls);
        hookMethods(cls.prototype);
        hookEmit(cls.prototype);
    }
    if (!options.usePluginHost) {
        const classes = new Set([
            slimcore.SlimCore,
            slimcore.Account,
            slimcore.Setup,
            slimcore.CallHandler,
            slimcore.VideoBinding,
            slimcore.VideoBindingRenderer,
            slimcore.VideoBindingScreenShare,
            slimcore.FrameSink,
            slimcore.ChromiumFrameSink,
            slimcore.ContentSharing,
            slimcore.DataChannel,
            slimcore.DataSource,
            slimcore.DataSink,
            slimcore.Trouter,
            slimcore.TrouterListener,
            slimcore.TrouterRequest,
            slimcore.TrouterResponse,
            slimcore.Ndi,
            slimcore.NdiFrameSink,
            slimcore.NdiParticipantStream,
        ]);
        for (const [name, value] of Object.entries(slimcore)) {
            if (typeof value === 'function') {
                if (classes.has(value)) {
                    hookClass(value);
                }
                else {
                    hookMethod(slimcore, name);
                }
            }
        }
    }
    hookClass(videoRenderer.ChromiumVideoRenderer);
    hookMethod(videoRenderer, 'createChromiumVideoRenderer');
}
enableTracing();
console.log('slimcore.version', SlimCore.getVersion());
console.log('slimcore.apiVersion', SlimCore.getApiVersion());
const PREVIEW_WIDTH = 320;
const PREVIEW_HEIGHT = 240;
const ICON_WIDTH = 32;
const ICON_HEIGHT = 32;
let callHandler = null;
let dataChannel = null;
let dataSource = null;
let dataSink = null;
const callObjects = new Map();
let videoRenderer = null;
let videoBindingScreenShare = null;
const videoObjects = new Map();
const videoBindingRenderers = new Map();
let compositor = null;
let compositorSize = { width: 640, height: 360 };
let compositorOffset = { x: 0, y: 0 };
let gMulCompositorVideoBindingRenderer = null;
let gCompositors = [];
let gFrameSinks = [];
const compositorSize2 = { width: 200, height: 200 };
const compositorsOffset = 200;
const compositorsPerRow = 4;
const compositorStart = { x: 50, y: 50 };
class ConsoleLogger {
    constructor(_namespace = []) {
        this._namespace = _namespace;
        // noop
    }
    createChild(namespace) {
        return new ConsoleLogger([...this._namespace, namespace]);
    }
    log(...args) {
        return console.log.call(console, this._prefix, ...args);
    }
    debug(...args) {
        return console.debug.call(console, this._prefix, ...args);
    }
    info(...args) {
        return console.info.call(console, this._prefix, ...args);
    }
    warn(...args) {
        return console.warn.call(console, this._prefix, ...args);
    }
    error(...args) {
        return console.error.call(console, this._prefix, ...args);
    }
    get _prefix() {
        return this._namespace.join('/');
    }
}
const logger = new ConsoleLogger();
function uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = crypto.getRandomValues(new Uint8Array(1))[0] % 16;
        const v = (c === 'x') ? r : (r & 0x3 | 0x8); // tslint:disable-line:no-bitwise
        return v.toString(16);
    });
}
let gHash = '';
function initSlimCore() {
    slimcore.start(false);
    dataSource = slimcore.createDataSource(0);
    dataSink = slimcore.createDataSink(0);
    slimcore.getBuildName();
    slimcore.getBuildVersion();
    slimcore.handle('device-list-changed', undefined, (args) => {
        if (args.video) {
            updateVideoDeviceList();
        }
        else {
            updateAudioDeviceList();
        }
    });
    slimcore.handle('object-property-changed', { propKey: Enums.Property.AccountStatus }, (args) => {
        if (args.value === Enums.AccountStatus.LoggedIn) {
            updateCallHandler(slimcore.createCallInterface());
            slimcore.getNodeId();
            slimcore.getRegistrationId();
            slimcore.getFingerprintId();
        }
        else if (args.value === Enums.AccountStatus.LoggedOut) {
            updateCallHandler(null);
            videoObjects.clear();
            updateVideoList();
        }
    });
    slimcore.handle('object-property-changed', { propKey: Enums.Property.CallStatus }, (args) => {
        getCallObject(args.objectId).status = args.value;
        updateCallList();
    });
    slimcore.handle('object-property-changed', { propKey: Enums.Property.CallerMriIdentity }, (args) => {
        getCallObject(args.objectId).name = args.value;
        updateCallList();
    });
    slimcore.handle('object-property-changed', { propKey: Enums.Property.VideoStatus }, (args) => {
        getVideoObject(args.objectId).status = args.value;
        updateVideoList();
    });
    slimcore.handle('object-property-changed', { propKey: Enums.Property.VideoType }, (args) => {
        getVideoObject(args.objectId).type = args.value;
        updateVideoList();
    });
    slimcore.handle('object-property-changed', { propKey: Enums.Property.VideoParticipantMri }, (args) => {
        getVideoObject(args.objectId).mri = args.value;
        updateVideoList();
    });
    slimcore.handle('object-property-changed', { propKey: Enums.Property.DataChannelStatus }, (args) => {
        if (args.value === Enums.DataChannelStatus.Active) {
            if (dataChannel) {
                dataChannel.setDataDevices();
                dataChannel.registerDataSource(dataSource);
                dataChannel.registerDataSink(dataSink);
            }
        }
    });
    slimcore.handle('object-property-changed', { propKey: Enums.Property.CallDataChannelObjectId }, (args) => {
        updateDataChannel(args.value ? slimcore.getDataChannel(args.value) : null);
    });
    slimcore.handle('model-download-complete', undefined, (args) => {
        if (gHash === args.hash) {
            if (args.failed === false) {
                getElementById('url-hash').innerText = 'Model downloaded. hash:' + gHash;
            }
            else {
                getElementById('url-hash').innerText = 'Model download failed. message:' + args.message;
            }
        }
        else {
            getElementById('url-hash').innerText = 'Model download event. hash:' + gHash;
        }
    });
    slimcore.handle('video-effects-event', undefined, (args) => {
        console.log('Received event video-effects-event: ', JSON.stringify(args));
    });
    slimcore.handle('shell-sharing-event', undefined, (args) => __awaiter(this, void 0, void 0, function* () {
        console.log('shell sharing event: ', JSON.stringify(args));
        const videoBindingScreenShare = yield getVideoBindingScreenShare();
        if (args.doShare === true) {
            updateShellSharingWindowId(args.windowId);
            videoBindingScreenShare.setCaptureRegionAndWindow(undefined, args.windowId);
        }
        else {
            updateShellSharingWindowId(0);
            videoBindingScreenShare.removeAllListeners();
        }
        sendMessage('sharing-indicator:setWindow', args.windowId);
    }));
    updateCallHandler(null);
}
function getMapEntry(map, key, defaultValue) {
    if (!map.has(key)) {
        map.set(key, defaultValue);
    }
    return map.get(key);
}
function getCallObject(id, defaultValue = {}) {
    return getMapEntry(callObjects, id, defaultValue);
}
function getVideoObject(id, defaultValue = {}) {
    return getMapEntry(videoObjects, id, defaultValue);
}
function initVideoTypes() {
    const select = getElementById('video-type');
    clearElement(select);
    select.appendChild(createOption('Video', `${Enums.VideoType.Video}`));
    select.appendChild(createOption('Screen Sharing', `${Enums.VideoType.ScreenShare}`));
}
function initCompositorLayouts() {
    const select = getElementById('compositor-layout');
    clearElement(select);
    select.appendChild(createOption('Vertical', `${0 /* Vertical */}`));
    select.appendChild(createOption('Picture-in-picture', `${1 /* PictureInPicture */}`));
    select.appendChild(createOption('NewsAnchor', `${2 /* NewsAnchor */}`));
}
function initRendererTypes() {
    const select = getElementById('renderer-type');
    clearElement(select);
    if (VideoRenderer.isChromiumVideoRendererAvailable()) {
        select.appendChild(createOption('Chromium', `${1 /* Chromium */}`));
    }
    if (CanvasVideoRenderer.isAvailable()) {
        select.appendChild(createOption('WebGL', `${0 /* WebGL */}`));
    }
}
function updateCallHandler(other) {
    if (callHandler) {
        callHandler.dispose();
        callHandler = null;
    }
    callHandler = other;
    for (const element of document.querySelectorAll('.need-call-interface')) {
        disableElement(element, !callHandler);
    }
}
function updateDataChannel(other) {
    if (dataChannel) {
        dataChannel.dispose();
        dataChannel = null;
    }
    dataChannel = other;
}
function updateCallList() {
    const selected = getSelectedCallObjectId();
    const select = getElementById('call-list');
    clearElement(select);
    const callObjectIds = callHandler.getActiveCalls();
    for (const callObjectId of callObjectIds) {
        const obj = callObjects.get(callObjectId);
        const status = Enums.CallStatus[obj.status];
        const items = [callObjectId, status];
        if (obj.name)
            items.push(obj.name);
        select.appendChild(createOption(items.join(' | '), `${callObjectId}`));
    }
    selectOption(select, selected.toString());
}
function updateVideoList() {
    const selected = getSelectedVideoObjectId();
    const select = getElementById('video-list');
    clearElement(select);
    for (const [videoObjectId, obj] of videoObjects) {
        const type = Enums.VideoType[obj.type];
        const status = Enums.VideoStatus[obj.status];
        const items = [videoObjectId, type, status, obj.mri];
        select.appendChild(createOption(items.filter((item) => item).join(' | '), `${videoObjectId}`));
    }
    selectOption(select, selected.toString());
}
function disableElement(element, disabled) {
    if (disabled) {
        element.setAttribute('disabled', 'true');
    }
    else {
        element.removeAttribute('disabled');
    }
}
function clearElement(element) {
    while (element.firstChild) {
        element.removeChild(element.firstChild);
    }
}
function selectOption(select, value) {
    let index = -1;
    for (let i = 0; i < select.length; i++) {
        if (select[i].value === value) {
            index = i;
        }
    }
    select.selectedIndex = index;
}
function createOption(title, value) {
    const option = document.createElement('option');
    option.innerText = title;
    option.value = value;
    return option;
}
function sendMessage(message, data) {
    console.log('ipc::send', arguments);
    electronIpc.send(message, data);
}
function sendMessageSync(message, data) {
    console.log('ipc::sendSync', arguments);
    return electronIpc.sendSync(message, data);
}
function handleMessage(message, handler) {
    // tslint:disable-next-line:only-arrow-functions
    electronIpc.on(message, function () {
        console.log('ipc::on', [message], arguments);
        handler.apply(undefined, arguments);
    });
}
function getElementById(id) {
    return document.getElementById(id);
}
function getSelectedMicrophoneId() {
    return getElementById('microphone-list').value;
}
function getSelectedSpeakerId() {
    return getElementById('speaker-list').value;
}
function getSelectedCameraId() {
    return getElementById('camera-list').value;
}
function getSelectedCameraName() {
    return getElementById('camera-list').selectedOptions[0].textContent;
}
function getSelectedDisplayId() {
    return parseInt(getElementById('display-list').value, 10);
}
function getSelectedWindowId() {
    return parseInt(getElementById('window-list').value, 10);
}
function getSelectedCallObjectId() {
    return parseInt(getElementById('call-list').value, 10);
}
function getSelectedVideoType() {
    return parseInt(getElementById('video-type').value, 10);
}
function getSelectedCompositorLayout() {
    return parseInt(getElementById('compositor-layout').value, 10);
}
function getSelectedRendererType() {
    return parseInt(getElementById('renderer-type').value, 10);
}
function getVideoObjectId(id) {
    const option = getElementById('video-list').item(id);
    return parseInt(option.value, 10);
}
function getSelectedVideoObjectId() {
    return parseInt(getElementById('video-list').value, 10);
}
function getSelectedVideoBindingRenderer() {
    return videoBindingRenderers.get(getSelectedVideoObjectId());
}
function setSelectedVideoBindingRenderer(videoBindingRenderer) {
    videoBindingRenderers.set(getSelectedVideoObjectId(), videoBindingRenderer);
}
function getSelectedDeviceEffect() {
    return parseInt(getElementById('device-effect-list').value, 10);
}
function login() {
    return __awaiter(this, void 0, void 0, function* () {
        const username = getElementById('username').value;
        const skypeToken = getElementById('skypetoken').value;
        slimcore.login(username, skypeToken);
    });
}
exports.login = login;
function logout() {
    slimcore.logout();
}
exports.logout = logout;
function flushLogs() {
    return __awaiter(this, void 0, void 0, function* () {
        slimcore.flushLogs();
    });
}
exports.flushLogs = flushLogs;
function selectAudioDevices() {
    const microphone = getSelectedMicrophoneId();
    const speaker = getSelectedSpeakerId();
    slimcore.selectAudioDevices(microphone, speaker);
}
exports.selectAudioDevices = selectAudioDevices;
function unmuteMicrophone() {
    slimcore.unmuteMicrophone();
}
exports.unmuteMicrophone = unmuteMicrophone;
function unmuteSpeaker() {
    slimcore.unmuteSpeaker();
}
exports.unmuteSpeaker = unmuteSpeaker;
function getSelectedMonitorInfo() {
    const monitorId = getSelectedDisplayId();
    const list = slimcore.getMonitorList();
    return list.find((info) => info.monitorId === monitorId);
}
function showSharingIndicator() {
    const info = getSelectedMonitorInfo();
    sendMessage('sharing-indicator:show', info.region);
}
exports.showSharingIndicator = showSharingIndicator;
function hideSharingIndicator() {
    sendMessage('sharing-indicator:hide');
}
exports.hideSharingIndicator = hideSharingIndicator;
function getVideoBindingScreenShare() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!videoBindingScreenShare) {
            videoBindingScreenShare = slimcore.createVideoBindingScreenShare();
            // NB! if we want to implement proper binding release then:
            // call videoStop and release all bindings (screen sharing and rendering)
            // note those could be called in any order and wait all to wait all to complete
            const videoObjectId = slimcore.createPreviewVideo(Enums.VideoType.ScreenShare);
            yield slimcore.videoCreateBinding(videoObjectId, videoBindingScreenShare);
        }
        return videoBindingScreenShare;
    });
}
function setCaptureRegion() {
    return __awaiter(this, void 0, void 0, function* () {
        const videoBindingScreenShare = yield getVideoBindingScreenShare();
        const info = getSelectedMonitorInfo();
        videoBindingScreenShare.setCaptureRegionAndWindow(info.region);
        sendMessage('sharing-indicator:setPosition', info.region);
    });
}
exports.setCaptureRegion = setCaptureRegion;
function setCaptureWindow() {
    return __awaiter(this, void 0, void 0, function* () {
        const videoBindingScreenShare = yield getVideoBindingScreenShare();
        const windowId = getSelectedWindowId();
        videoBindingScreenShare.setCaptureRegionAndWindow(undefined, windowId);
        sendMessage('sharing-indicator:setWindow', windowId);
    });
}
exports.setCaptureWindow = setCaptureWindow;
function convertImageData(image) {
    const array = image.data;
    const data = new Uint8ClampedArray(array.buffer, array.byteOffset, array.byteLength);
    return new ImageData(data, image.width, image.height);
}
function renderToCanvas(image) {
    const canvas = document.createElement('canvas');
    canvas.width = image.width;
    canvas.height = image.height;
    const scale = window.devicePixelRatio || 1;
    canvas.style.width = image.width / scale + 'px';
    canvas.style.height = image.height / scale + 'px';
    const context = canvas.getContext('2d');
    context.putImageData(convertImageData(image), 0, 0);
    return canvas;
}
function renderToImage(image) {
    const img = document.createElement('img');
    img.src = 'data:image/png;base64,' + image.data;
    const scale = window.devicePixelRatio || 1;
    img.style.width = image.width / scale + 'px';
    img.style.height = image.height / scale + 'px';
    return img;
}
function drawImage(image) {
    return image.isImage ? renderToImage(image) : renderToCanvas(image);
}
function getSnapshotOptions(icon = false) {
    const asImage = getElementById('preview-as-image').checked;
    const allowRetinaSizedImages = getElementById('preview-allow-retina').checked;
    const width = (icon ? ICON_WIDTH : PREVIEW_WIDTH) * window.devicePixelRatio;
    const height = (icon ? ICON_HEIGHT : PREVIEW_HEIGHT) * window.devicePixelRatio;
    return { width, height, asImage, allowRetinaSizedImages };
}
function getMonitorPreview() {
    return __awaiter(this, void 0, void 0, function* () {
        const displayId = getSelectedDisplayId();
        const options = getSnapshotOptions();
        const image = yield slimcore.getMonitorSnapshot(displayId, options);
        document.body.appendChild(drawImage(image));
    });
}
exports.getMonitorPreview = getMonitorPreview;
function getWindowPreview() {
    return __awaiter(this, void 0, void 0, function* () {
        const windowId = getSelectedWindowId();
        const options = getSnapshotOptions();
        const image = yield slimcore.getWindowSnapshot(windowId, options);
        document.body.appendChild(drawImage(image));
    });
}
exports.getWindowPreview = getWindowPreview;
function getWindowIcon() {
    return __awaiter(this, void 0, void 0, function* () {
        const windowId = getSelectedWindowId();
        const options = getSnapshotOptions(true);
        const image = yield slimcore.getWindowIcon(windowId, options);
        document.body.appendChild(drawImage(image));
    });
}
exports.getWindowIcon = getWindowIcon;
function enableShellSharing() {
    slimcore.enableShellSharing();
}
exports.enableShellSharing = enableShellSharing;
function disableShellSharing() {
    slimcore.disableShellSharing();
}
exports.disableShellSharing = disableShellSharing;
function updateShellSharingWindowId(windowId) {
    slimcore.updateShellSharingWindowId(windowId);
}
exports.updateShellSharingWindowId = updateShellSharingWindowId;
function createChromiumFrameSink(rendererType) {
    return SlimCore.createChromiumFrameSink({
        enableTextureSharing: options.enableTextureSharing,
        enableTextureUpload: options.enableTextureUpload,
        enableEventObject: rendererType === 0 /* WebGL */,
    });
}
function createVideoRendererImpl(args) {
    const type = getSelectedRendererType();
    const frameSink = createChromiumFrameSink(type);
    switch (type) {
        case 0 /* WebGL */:
            return new CanvasVideoRenderer(args, frameSink);
        case 1 /* Chromium */:
            return VideoRenderer.createChromiumVideoRenderer(frameSink, args);
        default:
            throw new Error(`Invalid renderer type: ${type}`);
    }
}
function createVideoRenderer(binding) {
    const container = document.createElement('div');
    container.classList.add('resizable');
    document.body.appendChild(container);
    videoRenderer = createVideoRendererImpl({
        container: container,
        transparent: false,
        scalingMode: 2 /* Fit */,
        logger: logger,
        useBufferSharing: true,
    });
    const videoBindingRenderer = binding || slimcore.createVideoBindingRenderer({
        enableDXVA: true,
        enableBGRA: true,
    });
    videoBindingRenderer.addFrameSink(videoRenderer.getFrameSink());
    setSelectedVideoBindingRenderer(videoBindingRenderer);
}
function initVideoRenderer() {
    const videoObjectId = getSelectedVideoObjectId();
    createVideoRenderer();
    slimcore.videoCreateBinding(videoObjectId, getSelectedVideoBindingRenderer());
}
exports.initVideoRenderer = initVideoRenderer;
function cloneVideoRenderer() {
    createVideoRenderer(getSelectedVideoBindingRenderer());
}
exports.cloneVideoRenderer = cloneVideoRenderer;
function createCompositorRenderers(count) {
    if (getSelectedVideoBindingRenderer() == null) {
        return;
    }
}
exports.createCompositorRenderers = createCompositorRenderers;
function buildCompositorWithFrame(id, zOrder, x, y, width, height, mirror, nativeHwnd, isWatermark) {
    const comp = slimcore.createCompositor({
        size: { width: width, height: height },
        enableGpu: false,
        offset: { x: isWatermark ? 0 : x, y: isWatermark ? 0 : y },
        backgroundColor: { red: 0, green: 0, blue: 0, alpha: 255 },
        nativeWindowHandle: nativeHwnd,
        zOrder: zOrder,
        containWatermark: isWatermark ? true : false,
        enableTextureSharing: true
    });
    comp.on('compositor-failed', (args) => {
        console.log(`Compositor Failed`);
    });
    console.log('Compositor type: ' + comp.getCurrentRenderType());
    gCompositors.push(comp);
    const viewProperties = {
        area: { x: 0, y: 0, width: 1, height: 1 },
        scalingMode: isWatermark ? 0 : 1,
        mirror: false,
    };
    if (isWatermark) {
        viewProperties.spriteType = 3 /* Image */;
        // viewProperties.useAlpha = true;
        // viewProperties.useCircleMask = true;
        const imageUriSpecified = getElementById('news-anchor-image').value;
        // viewProperties.uri = imageUriSpecified !== '' ? imageUriSpecified : 'C:\\Users\\junlia.REDMOND\\Downloads\\watermark.png';
        viewProperties.uri = imageUriSpecified !== '' ? imageUriSpecified : 'C:\\watermark.png';
        viewProperties.useAlphaInImage = true;
    }
    const frameSink = comp.addView(id, viewProperties);
    console.log('Added view with id=' + frameSink.getViewId());
    frameSink.on('first-frame-rendered', (args) => {
        console.log(`First Frame Rendered`);
    });
    frameSink.on('frame-type-changed', (args) => {
        console.log(`Frame type Changed- ${args.type}`);
    });
    frameSink.on('frame-size-changed', (args) => {
        console.log(`Frame Size Changed- width: ${args.width} height: ${args.height}`);
    });
    frameSink.on('full-frame-render-required', (args) => {
        console.log(`Full Frame Render Required- ${args.fullFrameRenderRequired}`);
    });
    frameSink.setVideoPreference(123, 450);
    if (!isWatermark) {
        gMulCompositorVideoBindingRenderer.addFrameSink(frameSink);
        gFrameSinks.push(frameSink);
    }
}
exports.buildCompositorWithFrame = buildCompositorWithFrame;
function createMultipleCompositorsHostRenderer(nativeHwnd) {
    if (gMulCompositorVideoBindingRenderer == null)
        return;
    for (let i = 0; i < 8; ++i) 
    // for (let i = 0; i < 1; ++i)
    {
        const posX = (i % compositorsPerRow) * compositorsOffset + compositorStart.x;
        const posY = Math.floor(i / compositorsPerRow) * compositorsOffset + compositorStart.y;
        buildCompositorWithFrame(i, i, posX, posY, compositorSize2.width, compositorSize2.height, true, nativeHwnd, false);
    }
    // Add watermark compositor
    buildCompositorWithFrame(9, 9999, 0, 0, compositorSize.width, compositorSize.height, true, nativeHwnd, true);
    // electronIpc.send('create-compositor-renderer', compositor.getBufferName(), CompositorLayout.Vertical, 1);
    electronIpc.on(`compositor-frame-sink-invoke`, (event, _, method, ...args) => {
        compositor[method](...args);
    });
    electronIpc.on('compositor-view-update', (event, _, id, x, y, width, height) => {
        console.log(`update layout`);
    });
    electronIpc.on('compositor-update', (event, x, y, width, height) => {
        console.log(`update compositor: ${width}x${height} (${x},${y})`);
        compositorSize = { width, height };
        compositorOffset = { x, y };
        compositor.configure({ size: compositorSize, offset: compositorOffset });
    });
}
exports.createMultipleCompositorsHostRenderer = createMultipleCompositorsHostRenderer;
function createCompositorHostRenderers(count, nativeHwnd) {
    if (getSelectedVideoBindingRenderer() == null)
        return;
    if (navigator.platform === 'MacIntel') {
        const machPort = sendMessageSync('native-renderer:start', nativeHwnd);
        // On Mac nativeHwnd is actually NSView ptr and not accessible on another process
        // We create machport receiver and pass the name to background process so
        // IOSurfaces can be passed as mach_ports between the processes
        nativeHwnd = Buffer.from(machPort);
    }
    compositor = slimcore.createCompositor({
        enableGpu: true,
        size: compositorSize,
        enableBackgroundTransparency: true,
        backgroundColor: { red: 0, green: 0, blue: 0, alpha: 255 },
        nativeWindowHandle: nativeHwnd,
        enableTextureSharing: true
    });
    const type = compositor.getCurrentRenderType();
    console.log('CREATE COMPOSITOR RENDER TYPE: ' + type);
    const layout = getSelectedCompositorLayout();
    if (layout === 2 /* NewsAnchor */) {
        count += 1;
    }
    electronIpc.send('create-compositor-renderer', compositor.getBufferName(), layout, count);
    electronIpc.on(`compositor-frame-sink-invoke`, (event, _, method, ...args) => {
        compositor[method](...args);
    });
    electronIpc.on('compositor-view-update', (event, _, id, x, y, width, height) => {
        console.log(`update layout`);
        const viewProperties = {
            area: { x: x / 640, y: y / 360, width: width / 640, height: height / 360 },
            scalingMode: 2 /* Fit */,
        };
        if (layout === 1 /* PictureInPicture */) {
            viewProperties.zOrder = id;
            viewProperties.useAlpha = true;
            viewProperties.useCircleMask = false;
            if (id === 1)
                viewProperties.scalingMode = 1 /* Crop */;
        }
        else if (layout === 2 /* NewsAnchor */) {
            viewProperties.zOrder = id;
            viewProperties.useAlpha = true;
            if (id === 0) {
                viewProperties.scalingMode = 0 /* Stretch */;
                viewProperties.uri = getElementById('news-anchor-image').value;
            }
        }
        else {
            viewProperties.useAlpha = false;
        }
        compositor.updateLayout(compositorSize, [{ id, properties: viewProperties }], { x: 0, y: 0, width: 1, height: 1 });
    });
    electronIpc.on('compositor-update', (event, x, y, width, height) => {
        console.log(`update compositor: ${width}x${height} (${x},${y})`);
        compositorSize = { width, height };
        compositorOffset = { x, y };
        compositor.configure({ size: compositorSize, offset: compositorOffset });
    });
    for (let i = 0; i < count; ++i) {
        console.log(`begin create-compositor-render view main index.ts ${i}`);
        const frameSink = compositor.addView(i);
        if (layout === 2 /* NewsAnchor */ && i === 0) {
            // don't add static image sink to videobindingrenderer
            continue;
        }
        const j = layout === 2 /* NewsAnchor */ ? i - 1 : i;
        videoBindingRenderers.get(getVideoObjectId(j)).addFrameSink(frameSink);
    }
}
exports.createCompositorHostRenderers = createCompositorHostRenderers;
function openCompositorWindow(native) {
    const videoObjectId = getSelectedVideoObjectId();
    if (!getSelectedVideoBindingRenderer()) {
        const videoBindingRenderer = slimcore.createVideoBindingRenderer({
            enableDXVA: true,
        });
        slimcore.videoCreateBinding(videoObjectId, videoBindingRenderer);
        setSelectedVideoBindingRenderer(videoBindingRenderer);
    }
    electronIpc.on(`compositor-window-ready`, (event, nativeHwnd) => {
        const hwndlog = nativeHwnd ? `${nativeHwnd.byteLength} bytes` : 'not set';
        console.log(`compositor-window-ready main index.ts, nativeHwnd ${hwndlog}`);
        createCompositorHostRenderers(videoBindingRenderers.size, nativeHwnd);
    });
    electronIpc.once(`compositor-closed`, () => {
        compositor.dispose();
        compositor = null;
    });
    electronIpc.sendSync(native ? 'open-native-compositor' : 'open-compositor');
}
exports.openCompositorWindow = openCompositorWindow;
function popupVideoRenderer() {
    const rendererType = getSelectedRendererType();
    let frameSink = createChromiumFrameSink(rendererType);
    getSelectedVideoBindingRenderer().addFrameSink(frameSink);
    const bufferName = frameSink.getBufferName();
    const args = { rendererType, bufferName };
    const popupId = electronIpc.sendSync('open-popup', args);
    electronIpc.on(`frame-sink-invoke-${popupId}`, (event, method, ...args) => {
        frameSink[method](...args);
    });
    electronIpc.once(`popup-closed-${popupId}`, () => {
        frameSink.dispose();
        frameSink = null;
    });
}
exports.popupVideoRenderer = popupVideoRenderer;
function popupCompositorVideoRenderer() {
    openCompositorWindow(false);
}
exports.popupCompositorVideoRenderer = popupCompositorVideoRenderer;
function popupNativeCompositorVideoRenderer() {
    openCompositorWindow(true);
}
exports.popupNativeCompositorVideoRenderer = popupNativeCompositorVideoRenderer;
function popupNativeMultipleCompositorsVideoRenderer() {
    const videoObjectId = getSelectedVideoObjectId();
    if (!gMulCompositorVideoBindingRenderer) {
        gMulCompositorVideoBindingRenderer = slimcore.createVideoBindingRenderer({
            enableDXVA: true,
            ignoreBlankFrame: false,
        });
        slimcore.videoCreateBinding(videoObjectId, gMulCompositorVideoBindingRenderer);
    }
    electronIpc.on(`compositor-window-ready`, (event, nativeHwnd) => {
        const hwndlog = nativeHwnd ? `${nativeHwnd.byteLength} bytes` : 'not set';
        console.log(`multiple compositors mode, compositor-window-ready main index.ts, nativeHwnd ${hwndlog}`);
        createMultipleCompositorsHostRenderer(nativeHwnd);
    });
    electronIpc.once(`compositor-closed`, () => {
        for (const compositor of gCompositors) {
            compositor.removeAllListeners();
            compositor.dispose();
        }
        gCompositors = [];
        for (const frameSink of gFrameSinks) {
            gMulCompositorVideoBindingRenderer.removeFrameSink(frameSink);
            frameSink.removeAllListeners();
            frameSink.dispose();
        }
        gFrameSinks = [];
    });
    electronIpc.sendSync('open-native-compositor');
}
exports.popupNativeMultipleCompositorsVideoRenderer = popupNativeMultipleCompositorsVideoRenderer;
function setVideoPreference(width, height) {
    if (getSelectedVideoBindingRenderer()) {
        getSelectedVideoBindingRenderer().setVideoPreference(width, height);
    }
}
exports.setVideoPreference = setVideoPreference;
function captureFrame() {
    return __awaiter(this, void 0, void 0, function* () {
        const frame = yield getSelectedVideoBindingRenderer().captureFrame();
        document.body.appendChild(drawImage(frame.image));
    });
}
exports.captureFrame = captureFrame;
function createPreviewVideo() {
    const type = getSelectedVideoType();
    const deviceId = (type === Enums.VideoType.Video) ? getSelectedCameraId() : undefined;
    const deviceName = (type === Enums.VideoType.Video) ? getSelectedCameraName() : undefined;
    const videoObjectId = slimcore.createPreviewVideo(type, deviceName, deviceId);
    getVideoObject(videoObjectId, { type });
    updateVideoList();
}
exports.createPreviewVideo = createPreviewVideo;
function createLocalVideo() {
    const type = getSelectedVideoType();
    const deviceId = (type === Enums.VideoType.Video) ? getSelectedCameraId() : undefined;
    const deviceName = (type === Enums.VideoType.Video) ? getSelectedCameraName() : undefined;
    const videoObjectId = slimcore.createLocalVideo(type, deviceName, deviceId);
    getVideoObject(videoObjectId, { type });
    updateVideoList();
}
exports.createLocalVideo = createLocalVideo;
const videoEffectTypes = [
    Enums.VideoEffectType.Off,
    Enums.VideoEffectType.BackgroundBlurDefault,
    Enums.VideoEffectType.BackgroundBlurLight,
    Enums.VideoEffectType.BackgroundBlurExperimental_1,
    Enums.VideoEffectType.BackgroundBlurExperimental_2,
    Enums.VideoEffectType.BackgroundReplacement,
    Enums.VideoEffectType.WhiteboardZoom,
    Enums.VideoEffectType.WhiteboardCleanup,
    Enums.VideoEffectType.WhiteboardMotionDetection,
    Enums.VideoEffectType.WhiteboardZoomAndCleanup,
    Enums.VideoEffectType.WhiteboardCleanupAndMotion,
    Enums.VideoEffectType.WhiteboardZoomAndCleanupAndMotion,
];
function updateDeviceEffectList() {
    const select = getElementById('device-effect-list');
    clearElement(select);
    const deviceId = getSelectedCameraId();
    const capability = slimcore.getDeviceEffectsCapability(deviceId);
    for (const value of videoEffectTypes) {
        // tslint:disable-next-line:no-bitwise
        if ((capability & value) === value) {
            select.appendChild(createOption(Enums.VideoEffectType[value], `${value}`));
        }
    }
}
exports.updateDeviceEffectList = updateDeviceEffectList;
function setDeviceEffects() {
    const deviceId = getSelectedCameraId();
    const type = getSelectedDeviceEffect();
    slimcore.setDeviceEffects(deviceId, type);
}
exports.setDeviceEffects = setDeviceEffects;
function setBackgroundImage() {
    const deviceId = getSelectedCameraId();
    const imagePath = getElementById('background-image').value;
    slimcore.setBackgroundImage(deviceId, imagePath);
}
exports.setBackgroundImage = setBackgroundImage;
function getImageProperty() {
    const imagePath = getElementById('original-image').value;
    const imageSize = slimcore.getImageProperty(imagePath);
    if (typeof imageSize === 'string') {
        throw new Error('getImageProperty API is not available');
    }
    const { width, height } = imageSize;
    getElementById('width').value = width.toString();
    getElementById('height').value = height.toString();
}
exports.getImageProperty = getImageProperty;
function transformImage() {
    const imagePath = getElementById('original-image').value;
    const width = parseInt(getElementById('width').value, 10);
    const height = parseInt(getElementById('height').value, 10);
    const imageResizedPath = getElementById('resized-image').value;
    slimcore.transformImage(imagePath, width, height, imageResizedPath);
}
exports.transformImage = transformImage;
function displayVideoDeviceSetting() {
    sendMessage('sharing-indicator:displayVideoDeviceSetting', getSelectedCameraId());
}
exports.displayVideoDeviceSetting = displayVideoDeviceSetting;
function dumpVideoSourceImages() {
    const videoObjectId = getSelectedVideoObjectId();
    slimcore.dumpVideoSourceImages(videoObjectId)
        .then((result) => {
        console.log(`Number of images dumped: ${result}`);
    });
}
exports.dumpVideoSourceImages = dumpVideoSourceImages;
function fillVideoEffects() {
    const v = getElementById('json-request-list').value;
    const req = {
        type: v,
        request: {},
    };
    if (v === 'EnableEffects' || v === 'DisableEffects') {
        req.request = {
            effects: [{ type: 'BackgroundModification', options: { variant: 'Blur' } }],
        };
    }
    getElementById('video-effects-request').value = JSON.stringify(req, null, 2);
}
exports.fillVideoEffects = fillVideoEffects;
function sendMessageVideoEffects() {
    const deviceId = getSelectedCameraId();
    const req = JSON.parse(getElementById('video-effects-request').value);
    const result = slimcore.sendMessageDeviceVideoEffects(deviceId, req);
    getElementById('video-effects-response').value = JSON.stringify(result, null, 2);
}
exports.sendMessageVideoEffects = sendMessageVideoEffects;
function cameraAutoControl(enable) {
    const videoObjectId = getSelectedVideoObjectId();
    slimcore.cameraAutoControl(videoObjectId, enable)
        .then((state) => {
        getElementById('cameraAutoControlState').innerText = `state=${state}`;
    })
        .catch((error) => {
        getElementById('cameraAutoControlState').innerText = `state=failed with "${error}"`;
    });
}
exports.cameraAutoControl = cameraAutoControl;
function cameraManualControlEnumerate() {
    return __awaiter(this, void 0, void 0, function* () {
        const select = getElementById('camera-controls-list');
        clearElement(select);
        const videoObjectId = getSelectedVideoObjectId();
        const controls = yield slimcore.enumerateCameraManualControls(videoObjectId);
        for (const control of controls) {
            const opt = createOption('id: ' + control.id.toString() + ' | name: ' + control.name.toString() + ' | modes: ' + control.supportedModes, ' ');
            select.appendChild(opt);
        }
    });
}
exports.cameraManualControlEnumerate = cameraManualControlEnumerate;
function cameraManualControlGetStates() {
    return __awaiter(this, void 0, void 0, function* () {
        const select = getElementById('camera-controls-states-list');
        clearElement(select);
        const videoObjectId = getSelectedVideoObjectId();
        const controls = yield slimcore.enumerateCameraManualControls(videoObjectId);
        const statesToUpdate = [];
        for (const control of controls) {
            // tslint:disable-next-line:no-bitwise
            if (control.supportedModes & 2 /* Auto */) {
                const state = { id: control.id, mode: 2 /* Auto */, value: false, context: null };
                statesToUpdate.push(state);
            }
            // tslint:disable-next-line:no-bitwise
            if (control.supportedModes & 4 /* Check */) {
                const state = { id: control.id, mode: 4 /* Check */, value: false, context: null };
                statesToUpdate.push(state);
            }
        }
        const states = yield slimcore.getCameraManualControlStates(videoObjectId, statesToUpdate);
        for (const state of states) {
            if (state == undefined) {
                select.appendChild(createOption('undefined', ' '));
            }
            else {
                select.appendChild(createOption('id: ' + state.id + ' mode: ' + state.mode + ' value: ' + state.value + ' context: ' + state.context, ' '));
            }
        }
    });
}
exports.cameraManualControlGetStates = cameraManualControlGetStates;
function cameraManualControlSetStates() {
    return __awaiter(this, void 0, void 0, function* () {
        const videoObjectId = getSelectedVideoObjectId();
        const statesToUpdate = [];
        const controls = yield slimcore.enumerateCameraManualControls(videoObjectId);
        for (const control of controls) {
            // tslint:disable-next-line:no-bitwise
            if (control.supportedModes & 2 /* Auto */) {
                const state = { id: control.id, mode: 2 /* Auto */, value: false, context: null };
                statesToUpdate.push(state);
            }
            // tslint:disable-next-line:no-bitwise
            if (control.supportedModes & 4 /* Check */) {
                const state = { id: control.id, mode: 4 /* Check */, value: false, context: null };
                statesToUpdate.push(state);
            }
        }
        const states = yield slimcore.getCameraManualControlStates(videoObjectId, statesToUpdate);
        const stateId = getElementById('state-id').value;
        const stateValue = getElementById('state-value').value;
        for (const state of states) {
            if (state.id === parseInt(stateId, 10)) {
                state.value = Boolean(parseInt(stateValue, 10));
            }
        }
        try {
            const state = yield slimcore.setCameraManualControlStates(videoObjectId, states);
            getElementById('cameraControlSetStates').innerText = `isSet=${state}`;
        }
        catch (e) {
            getElementById('cameraControlSetStates').innerText = `isSet=failed with "${e}"`;
        }
    });
}
exports.cameraManualControlSetStates = cameraManualControlSetStates;
function getSourceFormats() {
    return __awaiter(this, void 0, void 0, function* () {
        const deviceId = getSelectedCameraId();
        const select = getElementById('format-list');
        clearElement(select);
        const formats = yield slimcore.getSourceFormats(deviceId);
        for (const fmt of formats) {
            select.appendChild(createOption(fmt.width.toString() + 'x' + fmt.height.toString() + '@' + parseFloat(fmt.frameRate.toString()).toFixed(2), ''));
        }
    });
}
exports.getSourceFormats = getSourceFormats;
function getCameraMaxResolution() {
    return __awaiter(this, void 0, void 0, function* () {
        const deviceId = getSelectedCameraId();
        const fmts = yield slimcore.getSourceFormats(deviceId);
        if (fmts) {
            const fmt = fmts[0];
            getElementById('source-max-res').innerText = fmt.width.toString() + 'x' + fmt.height.toString() + '@' + parseFloat(fmt.frameRate.toString()).toFixed(2);
        }
    });
}
exports.getCameraMaxResolution = getCameraMaxResolution;
function startVideo() {
    const videoObjectId = getSelectedVideoObjectId();
    slimcore.videoStart(videoObjectId);
}
exports.startVideo = startVideo;
function stopVideo() {
    const videoObjectId = getSelectedVideoObjectId();
    slimcore.videoStop(videoObjectId);
}
exports.stopVideo = stopVideo;
function updateDeviceList(id, list) {
    const select = getElementById(id);
    clearElement(select);
    for (const info of list) {
        select.appendChild(createOption(info.label, info.id));
    }
}
function updateAudioDeviceList() {
    updateDeviceList('microphone-list', slimcore.getMicrophoneList());
    updateDeviceList('speaker-list', slimcore.getSpeakerList());
}
function updateVideoDeviceList() {
    updateDeviceList('camera-list', slimcore.getCameraList());
}
function updateDisplayList() {
    const select = getElementById('display-list');
    clearElement(select);
    for (const info of slimcore.getMonitorList()) {
        const name = info.name || JSON.stringify(info.region);
        select.appendChild(createOption(name, info.monitorId.toString()));
    }
}
function updateWindowList() {
    const select = getElementById('window-list');
    clearElement(select);
    const groups = {};
    for (const info of slimcore.getWindowList()) {
        const key = info.applicationName;
        groups[key] = groups[key] || [];
        groups[key].push(info);
    }
    for (const group of Object.keys(groups)) {
        const optgroup = document.createElement('optgroup');
        optgroup.label = group;
        for (const info of groups[group]) {
            optgroup.appendChild(createOption(info.title, info.windowId.toString()));
        }
        select.appendChild(optgroup);
    }
}
exports.updateWindowList = updateWindowList;
function updateDeviceRotation() {
    slimcore.setDeviceRotation(SlimCore.queryDeviceRotation());
}
function handleDisplaysChanged() {
    updateDisplayList();
    updateDeviceRotation();
}
function getLoseContextExtension() {
    const gl = videoRenderer['_context'];
    return gl.getExtension('WEBGL_lose_context');
}
let webGLLoseContext = null;
function loseContext() {
    webGLLoseContext = getLoseContextExtension();
    webGLLoseContext.loseContext();
}
exports.loseContext = loseContext;
function restoreContext() {
    webGLLoseContext.restoreContext();
    webGLLoseContext = null;
}
exports.restoreContext = restoreContext;
function placeCall() {
    const participant = getElementById('participant').value;
    callHandler.placeCall(uuidv4(), [participant]);
}
exports.placeCall = placeCall;
function placeGoLiveCall() {
    const threadId = getElementById('threadId').value;
    callHandler.placeCall(uuidv4(), [], {
        isHostless: true,
        threadId: threadId,
    });
}
exports.placeGoLiveCall = placeGoLiveCall;
function answerCall() {
    callHandler.answerCall(getSelectedCallObjectId(), false);
}
exports.answerCall = answerCall;
function leaveCall() {
    callHandler.leaveCall(getSelectedCallObjectId());
}
exports.leaveCall = leaveCall;
function callAttachSendVideo() {
    callHandler.callAttachSendVideo(getSelectedCallObjectId(), getSelectedVideoObjectId());
}
exports.callAttachSendVideo = callAttachSendVideo;
function callGetTechnicalInformation() {
    const json = callHandler.callGetTechnicalInformationJson(getSelectedCallObjectId());
    console.log(JSON.parse(json));
}
exports.callGetTechnicalInformation = callGetTechnicalInformation;
function callMute(mute) {
    callHandler.callMute(getSelectedCallObjectId(), mute);
}
exports.callMute = callMute;
function callMuteSpeaker(mute) {
    callHandler.callMuteSpeaker(getSelectedCallObjectId(), mute);
}
exports.callMuteSpeaker = callMuteSpeaker;
function callHold(hold) {
    callHandler.callHold(getSelectedCallObjectId(), hold);
}
exports.callHold = callHold;
const dtmfMap = {
    '0': Enums.DtmfTone.Num0,
    '1': Enums.DtmfTone.Num1,
    '2': Enums.DtmfTone.Num2,
    '3': Enums.DtmfTone.Num3,
    '4': Enums.DtmfTone.Num4,
    '5': Enums.DtmfTone.Num5,
    '6': Enums.DtmfTone.Num6,
    '7': Enums.DtmfTone.Num7,
    '8': Enums.DtmfTone.Num8,
    '9': Enums.DtmfTone.Num9,
    '*': Enums.DtmfTone.Star,
    '#': Enums.DtmfTone.Pound,
};
function sendDtmf(tone) {
    callHandler.callSendDtmf(getSelectedCallObjectId(), dtmfMap[tone]);
}
exports.sendDtmf = sendDtmf;
function startDataChannel() {
    if (dataChannel) {
        dataChannel.start();
    }
}
exports.startDataChannel = startDataChannel;
function stopDataChannel() {
    if (dataChannel) {
        dataChannel.stop();
    }
}
exports.stopDataChannel = stopDataChannel;
const intentMap = {
    '0': Enums.Intent.Regular,
    '2': Enums.Intent.CallPush,
    '3': Enums.Intent.CallUser,
    '5': Enums.Intent.CallPreheat,
};
function fireIntent() {
    const intentUser = getElementById('intent-user').value;
    const intentValue = getElementById('intent-value').value;
    if (intentValue === '5') {
        const preheatCall = {
            mediaPeerType: Enums.MediaPeerType.ConsumerMultiParty,
        };
        slimcore.fireIntent(intentMap[intentValue], intentUser, preheatCall);
    }
    else {
        slimcore.fireIntent(intentMap[intentValue]);
    }
}
exports.fireIntent = fireIntent;
function insertRegistrationTransports() {
    const serviceTypes = getElementById('serviceTypes').value;
    const contexts = getElementById('contexts').value;
    const registrationTokens = getElementById('registrationTokens').value;
    const registrationTTLs = getElementById('registrationTTLs').value;
    const activityId = getElementById('activityId').value;
    const reason = getElementById('reason').value;
    const options = {
        serviceTypes: serviceTypes.split(';').map(Number),
        contexts: contexts.split(';'),
        registrationTokens: registrationTokens.split(';'),
        registrationTTLs: registrationTTLs.split(';').map(Number),
        activityId: activityId,
        reason: reason,
    };
    slimcore.insertRegistrationTransports(options);
}
exports.insertRegistrationTransports = insertRegistrationTransports;
function sendData() {
    const msg = getElementById('data-channel-input').value;
    if (dataSource) {
        dataSource.sendData(Buffer.from(msg));
    }
}
exports.sendData = sendData;
let trouter = null;
let listener = null;
function createTrouterListener() {
    trouter = slimcore.createTrouter();
    listener = slimcore.createTrouterListener();
}
exports.createTrouterListener = createTrouterListener;
function registerTrouterListener() {
    const path = getElementById('trouterpath').value;
    trouter.registerListener(listener, path, 'MyLogging');
    listener.on('trouter-connected', (args) => {
        const ttl = trouter.getConnectionTTLInSec();
        console.log(`trouter-connected: Connection TTL=${ttl}`);
        const connId = trouter.getConnectionId();
        console.log(`trouter-connected: Connection ID=${connId}`);
        const clientId = trouter.getConnectedClientId();
        console.log(`trouter-connected: Connected client ID=${clientId}`);
    });
    listener.on('trouter-request', (args) => {
        const request = args.request;
        const response = args.response;
        const headers = request.getHeaders();
        let body = '<html><body>Got it!<p/>';
        if (headers) {
            console.log('trouter-request: got headers');
            for (const header of headers) {
                body += `<li>${header.header}=${header.value}</li>`;
            }
        }
        else {
            console.log('trouter-request: no header');
            body += 'No headers found';
        }
        body += ('<p/>' + request.getBody());
        body += '</body></html>';
        response.setBody(body);
        response.setStatus(200);
        response.send();
        request.dispose();
        response.dispose();
    });
}
exports.registerTrouterListener = registerTrouterListener;
function getTrouterConnectionTTL() {
    const ttl = trouter.getConnectionTTLInSec();
    console.log(`trouter connection TTL: ${ttl}`);
}
exports.getTrouterConnectionTTL = getTrouterConnectionTTL;
function unregisterTrouterListener() {
    trouter.unregisterListener(listener);
}
exports.unregisterTrouterListener = unregisterTrouterListener;
function destroyTrouterListener() {
    if (listener) {
        listener.dispose();
        listener = null;
    }
    if (trouter) {
        trouter.dispose();
        trouter = null;
    }
}
exports.destroyTrouterListener = destroyTrouterListener;
let dtcInstance = null;
let dtcConnCache = '';
let dtcReceiverId = null;
let dtcSendResponseFunc = null;
function decoupledTrouterClient_GetInstance() {
    const username = getElementById('dtc-username').value;
    dtcInstance = window['trouterclient'].getInstance(username);
    for (const btn of document.querySelectorAll('#dtc button')) {
        btn.disabled = false;
    }
}
exports.decoupledTrouterClient_GetInstance = decoupledTrouterClient_GetInstance;
function decoupledTrouterClient_Dispose() {
    if (dtcInstance) {
        dtcInstance.dispose();
        dtcInstance = null;
    }
}
exports.decoupledTrouterClient_Dispose = decoupledTrouterClient_Dispose;
function decoupledTrouterClient_AttachHost() {
    const host = {
        getAuthHeaders(params, resolve, reject) {
            try {
                const token = getElementById('dtc-token').value;
                resolve({ 'X-Skypetoken': token });
            }
            catch (e) {
                reject(e.toString());
            }
        },
        getConnectionCache(resolve, reject) {
            try {
                resolve(dtcConnCache);
            }
            catch (e) {
                reject(e.toString());
            }
        },
        setConnectionCache(content) {
            dtcConnCache = content;
        },
        onTrouterConnected(connectionInfo) {
            getElementById('dtc-state').innerText = JSON.stringify(connectionInfo, null, '  ');
        },
        onTrouterDisconnected() {
            getElementById('dtc-state').innerText = 'disconnected';
        },
        onTelemetryEvent(json) {
            console.log(`Trouter Client telemetry event: ${JSON.stringify(JSON.parse(json), null, '  ')}`);
        },
        onUserActivityStateAccepted(correlationVector) {
            console.log(`Trouter Client onUserActivityStateAccepted: ${correlationVector}`);
        },
        onMessageLoss(flowTags) {
            console.log(`Trouter Client onMessageLoss: ${JSON.stringify(flowTags)}`);
        },
    };
    const config = getElementById('dtc-config').value;
    const epid = getElementById('dtc-epid').value;
    dtcInstance.attachHost(host, {
        appVersion: '999/1.0.0.0/electron-test-app',
        configJson: config,
        epid: epid,
    });
}
exports.decoupledTrouterClient_AttachHost = decoupledTrouterClient_AttachHost;
function decoupledTrouterClient_DetachHost() {
    dtcInstance.detachHost();
}
exports.decoupledTrouterClient_DetachHost = decoupledTrouterClient_DetachHost;
function decoupledTrouterClient_UpdateConfig() {
    const config = getElementById('dtc-config').value;
    dtcInstance.updateRuntimeConfig(config);
}
exports.decoupledTrouterClient_UpdateConfig = decoupledTrouterClient_UpdateConfig;
function decoupledTrouterClient_SetUserActivityState() {
    const stateName = getElementById('dtc-uas').value;
    let state;
    switch (stateName) {
        case 'inactive':
            state = NativeTrouterClient.UserActivityState.Inactive;
            break;
        case 'active':
            state = NativeTrouterClient.UserActivityState.Active;
            break;
        default:
            state = NativeTrouterClient.UserActivityState.Unknown;
            break;
    }
    dtcInstance.setUserActivityState(state);
}
exports.decoupledTrouterClient_SetUserActivityState = decoupledTrouterClient_SetUserActivityState;
function decoupledTrouterClient_RegisterReceiver() {
    dtcReceiverId = uuidv4();
    dtcInstance.registerReceiver(dtcReceiverId, getElementById('dtc-receiver-path').value, (request, sendResponseFunc) => {
        getElementById('dtc-request').innerText = JSON.stringify(request, null, '  ');
        dtcSendResponseFunc = sendResponseFunc;
    });
}
exports.decoupledTrouterClient_RegisterReceiver = decoupledTrouterClient_RegisterReceiver;
function decoupledTrouterClient_UnregisterReceiver() {
    dtcInstance.unregisterReceiver(dtcReceiverId);
    dtcReceiverId = null;
}
exports.decoupledTrouterClient_UnregisterReceiver = decoupledTrouterClient_UnregisterReceiver;
function decoupledTrouterClient_SendResponse() {
    dtcSendResponseFunc({
        status: 200,
        headers: {
            'X-AdditionalHeaders': 'work fine',
            'X-EvenWith': 'multiple items',
        },
        body: 'Hi there!',
    });
    dtcSendResponseFunc = null;
}
exports.decoupledTrouterClient_SendResponse = decoupledTrouterClient_SendResponse;
function downloadModel() {
    const url = getElementById('ai-model-url').value;
    const type = Enums.DownloadType.Normal;
    try {
        gHash = slimcore.downloadModel(url, type);
        getElementById('url-hash').innerText = 'Initiated model download. hash:' + gHash;
    }
    catch (e) {
        getElementById('url-hash').innerText = `Download model failed with "${e}"`;
    }
}
exports.downloadModel = downloadModel;
let videoDeviceListener = null;
let videoDeviceListenerHandle = null;
function createVideoDeviceListener() {
    videoDeviceListener = slimcore.createVideoDeviceListener();
}
exports.createVideoDeviceListener = createVideoDeviceListener;
function initVideoDeviceListener() {
    const el = getElementById('VideoDeviceListener_devicePath');
    videoDeviceListenerHandle = videoDeviceListener.handle('video-device-state-changed', undefined, (args) => {
        const resultDisplay = getElementById('VideoDeviceListener_lastEventTime');
        resultDisplay.value = Date.now().toString() + ' ' + args.state.toString();
    });
    videoDeviceListener.initialise(el.value);
}
exports.initVideoDeviceListener = initVideoDeviceListener;
function destroyVideoDeviceListener() {
    if (videoDeviceListenerHandle != null) {
        videoDeviceListenerHandle.dispose();
        videoDeviceListenerHandle = null;
    }
    if (videoDeviceListener != null) {
        videoDeviceListener.dispose();
        videoDeviceListener = null;
    }
}
exports.destroyVideoDeviceListener = destroyVideoDeviceListener;
function getAiDevices() {
    const select = getElementById('ai-device-list');
    const devices = slimcore.getAiDevices();
    clearElement(select);
    for (const device of devices) {
        select.appendChild(createOption(device, device));
    }
}
exports.getAiDevices = getAiDevices;
const modelTypeMap = {
    'Unknown': Enums.AiDeviceModelType.Unknown,
    'PlazaASD': Enums.AiDeviceModelType.PlazaASD,
    'PlazaVC': Enums.AiDeviceModelType.PlazaVC,
    'PlazaFD': Enums.AiDeviceModelType.PlazaFD,
};
function getAiDeviceModels() {
    const deviceId = getElementById('ai-device-list').value;
    const modelType = modelTypeMap[getElementById('ai-device-model-type').value];
    const models = slimcore.getAiDeviceModels(deviceId, modelType);
    const select = getElementById('ai-device-models');
    clearElement(select);
    for (const model of models) {
        select.appendChild(createOption(model, model));
    }
}
exports.getAiDeviceModels = getAiDeviceModels;
function getAiDeviceCurrentModel() {
    const deviceId = getElementById('ai-device-list').value;
    const modelType = modelTypeMap[getElementById('ai-device-model-type').value];
    const model = slimcore.getAiDeviceCurrentModel(deviceId, modelType);
    getElementById('ai-device-current-model').value = model;
}
exports.getAiDeviceCurrentModel = getAiDeviceCurrentModel;
function setAiDeviceCurrentModel() {
    const deviceId = getElementById('ai-device-list').value;
    const modelType = modelTypeMap[getElementById('ai-device-model-type').value];
    const model = getElementById('ai-device-current-model').value;
    slimcore.setAiDeviceCurrentModel(deviceId, modelType, model);
}
exports.setAiDeviceCurrentModel = setAiDeviceCurrentModel;
const featureMap = {
    'Unknown': Enums.AiDeviceFeature.Unknown,
    'PeopleFeed': Enums.AiDeviceFeature.PeopleFeed,
    'FaceStream': Enums.AiDeviceFeature.FaceStream,
};
function getAiDeviceFeatureState() {
    const deviceId = getElementById('ai-device-list').value;
    const feature = featureMap[getElementById('ai-device-feature').value];
    const state = slimcore.getAiDeviceFeatureState(deviceId, feature);
    getElementById('ai-device-feature-state').checked = state;
}
exports.getAiDeviceFeatureState = getAiDeviceFeatureState;
function setAiDeviceFeatureState() {
    const deviceId = getElementById('ai-device-list').value;
    const feature = featureMap[getElementById('ai-device-feature').value];
    const state = getElementById('ai-device-feature-state').checked;
    slimcore.setAiDeviceFeatureState(deviceId, feature, state);
}
exports.setAiDeviceFeatureState = setAiDeviceFeatureState;
document.addEventListener('DOMContentLoaded', () => {
    initSlimCore();
    initVideoTypes();
    initCompositorLayouts();
    initRendererTypes();
    handleDisplaysChanged();
});
handleMessage('displays-changed', handleDisplaysChanged);
//# sourceMappingURL=index.js.map
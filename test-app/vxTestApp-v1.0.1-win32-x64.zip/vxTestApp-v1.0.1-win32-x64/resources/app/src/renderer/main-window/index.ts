/// <reference path="../../../../lib/slimcore-private.d.ts" />
/// <reference path="../../../../lib/video-renderer.d.ts" />
/// <reference path="../../../../lib/trouter-client.d.ts" />

// types
import * as CanvasVideoRendererModule from '../canvas-video-renderer';
import { MainWindowOptions, CompositorLayout, RendererType, OpenPopupArgs } from '../ipc';

declare const CanvasVideoRenderer: typeof CanvasVideoRendererModule.CanvasVideoRenderer;

declare const slimcore: SlimCore.Engine;
declare const electronIpc: Pick<Electron.IpcRenderer, 'send' | 'sendSync' | 'on' | 'once'>;
declare const options: MainWindowOptions;

electronIpc.send('page-ready');

import Enums = SlimCore.Enums;

const propKeyEnums = {
    [Enums.Property.AccountStatus]: Enums.AccountStatus,
    [Enums.Property.CallStatus]: Enums.CallStatus,
    [Enums.Property.ContentSharingFailureReason]: Enums.ContentSharingFailureReason,
    [Enums.Property.ContentSharingStatus]: Enums.ContentSharingStatus,
    [Enums.Property.DataChannelStatus]: Enums.DataChannelStatus,
    [Enums.Property.ParticipantContentRole]: Enums.ContentSharingRole,
    [Enums.Property.ParticipantFailureReason]: Enums.ParticipantFailureReason,
    [Enums.Property.ParticipantIdentity]: Enums.IdentityType,
    [Enums.Property.ParticipantStatus]: Enums.CallStatus,
    [Enums.Property.VideoStatus]: Enums.VideoStatus,
    [Enums.Property.VideoType]: Enums.VideoType,
};

function prettifyValue(propKey: Enums.Property, value: any)
{
    const propKeyEnum = propKeyEnums[propKey];
    if (!propKeyEnum) return value;

    return propKeyEnum[value] || value;
}

function prettifyObjectPropertyChangedArgs(args: SlimCore.Engine.Events.ObjectPropertyChangedArgs)
{
    return {
        objectId: args.objectId,
        objectType: Enums.ObjectType[args.objectType] || args.objectType,
        propKey: Enums.Property[args.propKey] || args.propKey,
        value: prettifyValue(args.propKey, args.value),
    };
}

function prettifyQualityChangedArgs(args: SlimCore.Engine.Events.QualityChangedArgs)
{
    return {
        objectId: args.objectId,
        objectType: Enums.ObjectType[args.objectType] || args.objectType,
        type: Enums.QualityEventType[args.type] || args.type,
        value: Enums.QualityLevel[args.value] || args.value,
        mediaType: Enums.MediaType[args.mediaType] || args.mediaType,
    };
}

function prettifyAudioStreamStateChangedArgs(args: SlimCore.CallHandler.Events.AudioStreamStateChangedArgs)
{
    return {
        callObjectId: args.callObjectId,
        direction: Enums.MediaDirection[args.direction] || args.direction,
        streamState: Enums.MediaStreamState[args.streamState] || args.streamState,
    };
}

function prettifyDataDeviceEvent(args: SlimCore.DataDevice.Events.EventArgs)
{
    return {
        event: Enums.DataDeviceEvent[args.event] || args.event,
    };
}

function enableTracing()
{
    const slimcore = window['SlimCore'];
    const videoRenderer = window['VideoRenderer'];

    const methodsToIgnore = new Set<Function>();

    if (!options.usePluginHost)
    {
        methodsToIgnore.add(slimcore.ChromiumFrameSink.prototype.log);
    }

    function hookMethod(object: Object, name: string)
    {
        const origMethod = object[name];
        if (!origMethod) return;

        if (name === 'emit') return;
        if (methodsToIgnore.has(origMethod)) return;

        object[name] = function (this: any)
        {
            const method = `${object.constructor.name}::${name}`;

            console.time(method);
            console.log(method, arguments);

            // tslint:disable-next-line:no-invalid-this
            const result = origMethod.apply(this, arguments);

            const finish = (value: any) => {
                console.timeEnd(method);
                console.log(value);
                return value;
            };

            if (result instanceof Promise) {
                return result.then(finish);
            } else {
                return finish(result);
            }
        };
    }

    const emitHooked = Symbol('emitHooked');

    function hookEmit(object: NodeJS.EventEmitter)
    {
        if (object[emitHooked]) return;

        const emit = object.emit;
        object.emit = function (this: any, event: string, ...args: any[])
        {
            if (event === 'object-property-changed') {
                args = [prettifyObjectPropertyChangedArgs(args[0])];
            }
            else if (event === 'quality-changed') {
                args = [prettifyQualityChangedArgs(args[0])];
            }
            else if (event === 'audio-stream-state-changed') {
                args = [prettifyAudioStreamStateChangedArgs(args[0])];
            }
            else if (event === 'event') {
                args = [prettifyDataDeviceEvent(args[0])];
            }

            // tslint:disable-next-line:no-invalid-this
            console.log(`${this.constructor.name}::emit`, event, ...args);

            // tslint:disable-next-line:no-invalid-this
            return emit.apply(this, arguments);
        };

        object[emitHooked] = true;
    }

    function hookMethods(object: Object)
    {
        for (const [name, value] of Object.entries(object)) {
            if (typeof value === 'function') {
                hookMethod(object, name);
            }
        }
    }

    function hookClass(cls: Function)
    {
        if (!cls) return;

        hookMethods(cls);
        hookMethods(cls.prototype);
        hookEmit(cls.prototype);
    }

    if (!options.usePluginHost)
    {
        const classes = new Set([
            slimcore.SlimCore,
            slimcore.Account,
            slimcore.Setup,
            slimcore.CallHandler,
            slimcore.VideoBinding,
            slimcore.VideoBindingRenderer,
            slimcore.VideoBindingScreenShare,
            slimcore.FrameSink,
            slimcore.ChromiumFrameSink,
            slimcore.ContentSharing,
            slimcore.DataChannel,
            slimcore.DataSource,
            slimcore.DataSink,
            slimcore.Trouter,
            slimcore.TrouterListener,
            slimcore.TrouterRequest,
            slimcore.TrouterResponse,
            slimcore.Ndi,
            slimcore.NdiFrameSink,
            slimcore.NdiParticipantStream,
        ]);

        for (const [name, value] of Object.entries(slimcore)) {
            if (typeof value === 'function') {
                if (classes.has(value)) {
                    hookClass(value);
                } else {
                    hookMethod(slimcore, name);
                }
            }
        }
    }

    hookClass(videoRenderer.ChromiumVideoRenderer);
    hookMethod(videoRenderer, 'createChromiumVideoRenderer');
}

enableTracing();

console.log('slimcore.version', SlimCore.getVersion());
console.log('slimcore.apiVersion', SlimCore.getApiVersion());

type CallObjectEntry = {
    status?: Enums.CallStatus,
    name?: string,
};

type VideoObjectEntry = {
    status?: Enums.VideoStatus,
    type?: Enums.VideoType,
    mri?: string;
};

const PREVIEW_WIDTH = 320;
const PREVIEW_HEIGHT = 240;

const ICON_WIDTH = 32;
const ICON_HEIGHT = 32;

let callHandler: SlimCore.CallHandler = null;
let dataChannel: SlimCore.DataChannel = null;
let dataSource: SlimCore.DataSource = null;
let dataSink: SlimCore.DataSink = null;
const callObjects = new Map<number, CallObjectEntry>();
let videoRenderer: SlimCore.VideoRenderer = null;
let videoBindingScreenShare: SlimCore.VideoBindingScreenShare = null;
const videoObjects = new Map<number, VideoObjectEntry>();
const videoBindingRenderers = new Map<number, SlimCore.VideoBindingRenderer>();
let compositor: SlimCore.Compositor = null;
let compositorSize: SlimCore.Size = {width: 640, height: 360 };
let compositorOffset: SlimCore.Point = {x: 0, y: 0};
let gMulCompositorVideoBindingRenderer: SlimCore.VideoBindingRenderer = null;
let gCompositors: SlimCore.Compositor[] = [];
let gFrameSinks: SlimCore.FrameSink[] = [];
const compositorSize2: SlimCore.Size = {width: 200, height: 200 };
const compositorsOffset = 200;
const compositorsPerRow = 4;
const compositorStart: SlimCore.Point = {x: 50, y: 50};

class ConsoleLogger implements SlimCore.VideoRenderer.Logger
{
    public constructor(private _namespace: string[] = []) {
        // noop
    }

    public createChild(namespace: string): SlimCore.VideoRenderer.Logger {
        return new ConsoleLogger([...this._namespace, namespace]);
    }

    public log(...args: any[]): void {
        return console.log.call(console, this._prefix, ...args);
    }

    public debug(...args: any[]): void {
        return console.debug.call(console, this._prefix, ...args);
    }

    public info(...args: any[]): void {
        return console.info.call(console, this._prefix, ...args);
    }

    public warn(...args: any[]): void {
        return console.warn.call(console, this._prefix, ...args);
    }

    public error(...args: any[]): void {
        return console.error.call(console, this._prefix, ...args);
    }

    private get _prefix() {
        return this._namespace.join('/');
    }
}

const logger = new ConsoleLogger();

function uuidv4()
{
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = crypto.getRandomValues(new Uint8Array(1))[0] % 16;
        const v = (c === 'x') ? r : (r & 0x3 | 0x8); // tslint:disable-line:no-bitwise
        return v.toString(16);
    });
}

let gHash = '';

function initSlimCore()
{
    slimcore.start(false);

    dataSource = slimcore.createDataSource(0);
    dataSink = slimcore.createDataSink(0);

    slimcore.getBuildName();
    slimcore.getBuildVersion();

    slimcore.handle('device-list-changed', undefined, (args) => {
        if (args.video) {
            updateVideoDeviceList();
        } else {
            updateAudioDeviceList();
        }
    });

    slimcore.handle('object-property-changed', { propKey: Enums.Property.AccountStatus }, (args) => {
        if (args.value === Enums.AccountStatus.LoggedIn) {
            updateCallHandler(slimcore.createCallInterface());

            slimcore.getNodeId();
            slimcore.getRegistrationId();
            slimcore.getFingerprintId();
        }
        else if (args.value === Enums.AccountStatus.LoggedOut) {
            updateCallHandler(null);

            videoObjects.clear();
            updateVideoList();
        }
    });

    slimcore.handle('object-property-changed', { propKey: Enums.Property.CallStatus }, (args) => {
        getCallObject(args.objectId).status = args.value as number;
        updateCallList();
    });

    slimcore.handle('object-property-changed', { propKey: Enums.Property.CallerMriIdentity }, (args) => {
        getCallObject(args.objectId).name = args.value as string;
        updateCallList();
    });

    slimcore.handle('object-property-changed', { propKey: Enums.Property.VideoStatus }, (args) => {
        getVideoObject(args.objectId).status = args.value as number;
        updateVideoList();
    });

    slimcore.handle('object-property-changed', { propKey: Enums.Property.VideoType }, (args) => {
        getVideoObject(args.objectId).type = args.value as number;
        updateVideoList();
    });

    slimcore.handle('object-property-changed', { propKey: Enums.Property.VideoParticipantMri }, (args) => {
        getVideoObject(args.objectId).mri = args.value as string;
        updateVideoList();
    });

    slimcore.handle('object-property-changed', { propKey: Enums.Property.DataChannelStatus }, (args) => {
        if (args.value === Enums.DataChannelStatus.Active) {
            if (dataChannel) {
                dataChannel.setDataDevices();
                dataChannel.registerDataSource(dataSource);
                dataChannel.registerDataSink(dataSink);
            }
        }
    });

    slimcore.handle('object-property-changed', { propKey: Enums.Property.CallDataChannelObjectId }, (args) => {
        updateDataChannel(args.value ? slimcore.getDataChannel(args.value as number) : null);
    });

    slimcore.handle('model-download-complete', undefined, (args) => {
        if (gHash === args.hash) {
            if (args.failed === false) {
                getElementById<HTMLPreElement>('url-hash').innerText = 'Model downloaded. hash:' + gHash;
            }
            else {
                getElementById<HTMLPreElement>('url-hash').innerText = 'Model download failed. message:' + args.message;
            }
        } else {
            getElementById<HTMLPreElement>('url-hash').innerText = 'Model download event. hash:' + gHash;
        }
    });

    slimcore.handle('video-effects-event', undefined, (args) => {
        console.log('Received event video-effects-event: ', JSON.stringify(args));
    });

    slimcore.handle('shell-sharing-event', undefined, async (args) => {
        console.log('shell sharing event: ', JSON.stringify(args));
        const videoBindingScreenShare = await getVideoBindingScreenShare();
        if (args.doShare === true) {
            updateShellSharingWindowId(args.windowId);
            videoBindingScreenShare.setCaptureRegionAndWindow(undefined, args.windowId);
        }
        else {
            updateShellSharingWindowId(0);
            videoBindingScreenShare.removeAllListeners();
        }
        sendMessage('sharing-indicator:setWindow', args.windowId);
    });

    updateCallHandler(null);
}

function getMapEntry<K, V>(map: Map<K, V>, key: K, defaultValue: V) {
    if (!map.has(key)) {
        map.set(key, defaultValue);
    }
    return map.get(key);
}

function getCallObject(id: number, defaultValue: CallObjectEntry = {}) {
    return getMapEntry(callObjects, id, defaultValue);
}

function getVideoObject(id: number, defaultValue: VideoObjectEntry = {}) {
    return getMapEntry(videoObjects, id, defaultValue);
}

function initVideoTypes()
{
    const select = getElementById<HTMLSelectElement>('video-type');
    clearElement(select);

    select.appendChild(createOption('Video', `${Enums.VideoType.Video}`));
    select.appendChild(createOption('Screen Sharing', `${Enums.VideoType.ScreenShare}`));
}

function initCompositorLayouts()
{
    const select = getElementById<HTMLSelectElement>('compositor-layout');
    clearElement(select);

    select.appendChild(createOption('Vertical', `${CompositorLayout.Vertical}`));
    select.appendChild(createOption('Picture-in-picture', `${CompositorLayout.PictureInPicture}`));
    select.appendChild(createOption('NewsAnchor', `${CompositorLayout.NewsAnchor}`));
}

function initRendererTypes()
{
    const select = getElementById<HTMLSelectElement>('renderer-type');
    clearElement(select);

    if (VideoRenderer.isChromiumVideoRendererAvailable()) {
        select.appendChild(createOption('Chromium', `${RendererType.Chromium}`));
    }

    if (CanvasVideoRenderer.isAvailable()) {
        select.appendChild(createOption('WebGL', `${RendererType.WebGL}`));
    }
}

function updateCallHandler(other: SlimCore.CallHandler)
{
    if (callHandler) {
        callHandler.dispose();
        callHandler = null;
    }

    callHandler = other;

    for (const element of document.querySelectorAll('.need-call-interface')) {
        disableElement(element as HTMLElement, !callHandler);
    }
}

function updateDataChannel(other: SlimCore.DataChannel)
{
    if (dataChannel) {
        dataChannel.dispose();
        dataChannel = null;
    }

    dataChannel = other;
}

function updateCallList()
{
    const selected = getSelectedCallObjectId();

    const select = getElementById<HTMLSelectElement>('call-list');
    clearElement(select);

    const callObjectIds = callHandler.getActiveCalls();

    for (const callObjectId of callObjectIds) {
        const obj = callObjects.get(callObjectId);
        const status = Enums.CallStatus[obj.status];

        const items = [callObjectId, status];
        if (obj.name) items.push(obj.name);

        select.appendChild(createOption(items.join(' | '), `${callObjectId}`));
    }

    selectOption(select, selected.toString());
}

function updateVideoList()
{
    const selected = getSelectedVideoObjectId();

    const select = getElementById<HTMLSelectElement>('video-list');
    clearElement(select);

    for (const [videoObjectId, obj] of videoObjects) {
        const type = Enums.VideoType[obj.type];
        const status = Enums.VideoStatus[obj.status];
        const items = [videoObjectId, type, status, obj.mri];
        select.appendChild(createOption(items.filter((item) => item).join(' | '), `${videoObjectId}`));
    }

    selectOption(select, selected.toString());
}

function disableElement(element: HTMLElement, disabled: boolean)
{
    if (disabled) {
        element.setAttribute('disabled', 'true');
    } else {
        element.removeAttribute('disabled');
    }
}

function clearElement(element: HTMLElement)
{
    while (element.firstChild) {
        element.removeChild(element.firstChild);
    }
}

function selectOption(select: HTMLSelectElement, value: string)
{
    let index = -1;

    for (let i = 0; i < select.length; i++) {
        if ((select[i] as HTMLOptionElement).value === value) {
            index = i;
        }
    }

    select.selectedIndex = index;
}

function createOption(title: string, value: string)
{
    const option = document.createElement('option');
    option.innerText = title;
    option.value = value;

    return option;
}

function sendMessage(message: string, data?: any)
{
    console.log('ipc::send', arguments);
    electronIpc.send(message, data);
}

function sendMessageSync(message: string, data?: any)
{
   console.log('ipc::sendSync', arguments);
   return electronIpc.sendSync(message, data);
}

function handleMessage(message: string, handler: Function)
{
    // tslint:disable-next-line:only-arrow-functions
    electronIpc.on(message, function ()
    {
        console.log('ipc::on', [message], arguments);
        handler.apply(undefined, arguments);
    });
}

function getElementById<T extends HTMLElement>(id: string)
{
    return document.getElementById(id) as T;
}

function getSelectedMicrophoneId()
{
    return getElementById<HTMLSelectElement>('microphone-list').value;
}

function getSelectedSpeakerId()
{
    return getElementById<HTMLSelectElement>('speaker-list').value;
}

function getSelectedCameraId()
{
    return getElementById<HTMLSelectElement>('camera-list').value;
}

function getSelectedCameraName()
{
    return getElementById<HTMLSelectElement>('camera-list').selectedOptions[0].textContent;
}

function getSelectedDisplayId()
{
    return parseInt(getElementById<HTMLSelectElement>('display-list').value, 10);
}

function getSelectedWindowId()
{
    return parseInt(getElementById<HTMLSelectElement>('window-list').value, 10);
}

function getSelectedCallObjectId()
{
    return parseInt(getElementById<HTMLSelectElement>('call-list').value, 10);
}

function getSelectedVideoType()
{
    return parseInt(getElementById<HTMLSelectElement>('video-type').value, 10) as Enums.VideoType;
}

function getSelectedCompositorLayout()
{
    return parseInt(getElementById<HTMLSelectElement>('compositor-layout').value, 10) as CompositorLayout;
}

function getSelectedRendererType()
{
    return parseInt(getElementById<HTMLSelectElement>('renderer-type').value, 10) as RendererType;
}

function getVideoObjectId(id: number)
{
    const option = getElementById<HTMLSelectElement>('video-list').item(id) as HTMLOptionElement;
    return parseInt(option.value, 10);
}

function getSelectedVideoObjectId()
{
    return parseInt(getElementById<HTMLSelectElement>('video-list').value, 10);
}

function getSelectedVideoBindingRenderer()
{
    return videoBindingRenderers.get(getSelectedVideoObjectId());
}

function setSelectedVideoBindingRenderer(videoBindingRenderer: SlimCore.VideoBindingRenderer)
{
    videoBindingRenderers.set(getSelectedVideoObjectId(), videoBindingRenderer);
}

function getSelectedDeviceEffect()
{
    return parseInt(getElementById<HTMLSelectElement>('device-effect-list').value, 10) as Enums.VideoEffectType;
}

export async function login()
{
    const username = getElementById<HTMLInputElement>('username').value;
    const skypeToken = getElementById<HTMLInputElement>('skypetoken').value;
    slimcore.login(username, skypeToken);
}

export function logout()
{
    slimcore.logout();
}

export async function flushLogs()
{
    slimcore.flushLogs();
}

export function selectAudioDevices()
{
    const microphone = getSelectedMicrophoneId();
    const speaker = getSelectedSpeakerId();

    slimcore.selectAudioDevices(microphone, speaker);
}

export function unmuteMicrophone()
{
    slimcore.unmuteMicrophone();
}

export function unmuteSpeaker()
{
    slimcore.unmuteSpeaker();
}

function getSelectedMonitorInfo()
{
    const monitorId = getSelectedDisplayId();

    const list = slimcore.getMonitorList();
    return list.find((info) => info.monitorId === monitorId);
}

export function showSharingIndicator()
{
    const info = getSelectedMonitorInfo();

    sendMessage('sharing-indicator:show', info.region);
}

export function hideSharingIndicator()
{
    sendMessage('sharing-indicator:hide');
}

async function getVideoBindingScreenShare()
{
    if (!videoBindingScreenShare) {
        videoBindingScreenShare = slimcore.createVideoBindingScreenShare();
        // NB! if we want to implement proper binding release then:
        // call videoStop and release all bindings (screen sharing and rendering)
        // note those could be called in any order and wait all to wait all to complete
        const videoObjectId = slimcore.createPreviewVideo(Enums.VideoType.ScreenShare);
        await slimcore.videoCreateBinding(videoObjectId, videoBindingScreenShare);
    }

    return videoBindingScreenShare;
}

export async function setCaptureRegion()
{
    const videoBindingScreenShare = await getVideoBindingScreenShare();
    const info = getSelectedMonitorInfo();

    videoBindingScreenShare.setCaptureRegionAndWindow(info.region);

    sendMessage('sharing-indicator:setPosition', info.region);
}

export async function setCaptureWindow()
{
    const videoBindingScreenShare = await getVideoBindingScreenShare();
    const windowId = getSelectedWindowId();

    videoBindingScreenShare.setCaptureRegionAndWindow(undefined, windowId);

    sendMessage('sharing-indicator:setWindow', windowId);
}

function convertImageData(image: SlimCore.ImageData)
{
    const array = image.data as Uint8Array;
    const data = new Uint8ClampedArray(array.buffer, array.byteOffset, array.byteLength);
    return new ImageData(data, image.width, image.height);
}

function renderToCanvas(image: SlimCore.ImageData)
{
    const canvas = document.createElement('canvas');
    canvas.width = image.width;
    canvas.height = image.height;

    const scale = window.devicePixelRatio || 1;
    canvas.style.width = image.width / scale + 'px';
    canvas.style.height = image.height / scale + 'px';

    const context = canvas.getContext('2d');
    context.putImageData(convertImageData(image), 0, 0);

    return canvas;
}

function renderToImage(image: SlimCore.ImageData)
{
    const img = document.createElement('img');
    img.src = 'data:image/png;base64,' + image.data as string;

    const scale = window.devicePixelRatio || 1;
    img.style.width = image.width / scale + 'px';
    img.style.height = image.height / scale + 'px';

    return img;
}

function drawImage(image: SlimCore.ImageData)
{
    return image.isImage ? renderToImage(image) : renderToCanvas(image);
}

function getSnapshotOptions(icon = false): SlimCore.SnapshotOptions
{
    const asImage = getElementById<HTMLInputElement>('preview-as-image').checked;
    const allowRetinaSizedImages = getElementById<HTMLInputElement>('preview-allow-retina').checked;

    const width = (icon ? ICON_WIDTH : PREVIEW_WIDTH) * window.devicePixelRatio;
    const height = (icon ? ICON_HEIGHT : PREVIEW_HEIGHT) * window.devicePixelRatio;

    return { width, height, asImage, allowRetinaSizedImages };
}

export async function getMonitorPreview()
{
    const displayId = getSelectedDisplayId();
    const options = getSnapshotOptions();

    const image = await slimcore.getMonitorSnapshot(displayId, options);
    document.body.appendChild(drawImage(image));
}

export async function getWindowPreview()
{
    const windowId = getSelectedWindowId();
    const options = getSnapshotOptions();

    const image = await slimcore.getWindowSnapshot(windowId, options);
    document.body.appendChild(drawImage(image));
}

export async function getWindowIcon()
{
    const windowId = getSelectedWindowId();
    const options = getSnapshotOptions(true);

    const image = await slimcore.getWindowIcon(windowId, options);
    document.body.appendChild(drawImage(image));
}

export function enableShellSharing()
{
    slimcore.enableShellSharing();
}

export function disableShellSharing()
{
    slimcore.disableShellSharing();
}

export function updateShellSharingWindowId(windowId: number)
{
    slimcore.updateShellSharingWindowId(windowId);
}

function createChromiumFrameSink(rendererType: RendererType)
{
    return SlimCore.createChromiumFrameSink({
        enableTextureSharing: options.enableTextureSharing,
        enableTextureUpload: options.enableTextureUpload,
        enableEventObject: rendererType === RendererType.WebGL,
    });
}

function createVideoRendererImpl(args: SlimCore.VideoRenderer.ConstructorArgs)
{
    const type = getSelectedRendererType();
    const frameSink = createChromiumFrameSink(type);

    switch (type) {
        case RendererType.WebGL:
            return new CanvasVideoRenderer(args, frameSink);

        case RendererType.Chromium:
            return VideoRenderer.createChromiumVideoRenderer(frameSink, args);

        default:
            throw new Error(`Invalid renderer type: ${type}`);
    }
}

function createVideoRenderer(binding?: SlimCore.VideoBindingRenderer)
{
    const container = document.createElement('div');
    container.classList.add('resizable');
    document.body.appendChild(container);

    videoRenderer = createVideoRendererImpl({
        container: container,
        transparent: false,
        scalingMode: SlimCore.VideoRenderer.ScalingMode.Fit,
        logger: logger,
        useBufferSharing: true,
    });

    const videoBindingRenderer = binding || slimcore.createVideoBindingRenderer({
        enableDXVA: true,
        enableBGRA: true,
    });

    videoBindingRenderer.addFrameSink(videoRenderer.getFrameSink());

    setSelectedVideoBindingRenderer(videoBindingRenderer);
}

export function initVideoRenderer()
{
    const videoObjectId = getSelectedVideoObjectId();

    createVideoRenderer();
    slimcore.videoCreateBinding(videoObjectId, getSelectedVideoBindingRenderer());
}

export function cloneVideoRenderer()
{
    createVideoRenderer(getSelectedVideoBindingRenderer());
}

export function createCompositorRenderers(count: number)
{
    if (getSelectedVideoBindingRenderer() == null) {
        return;
    }
}

export function buildCompositorWithFrame(id: number, zOrder: number,
                                         x: number, y: number, width: number,
                                         height: number, mirror?: boolean, nativeHwnd?: Buffer,
                                         isWatermark?: boolean): void {
    const comp = slimcore.createCompositor({
        size: {width: width, height: height},
        enableGpu: false,
        offset: {x: isWatermark ? 0 : x, y: isWatermark ? 0 : y},
        backgroundColor: {red: 0, green: 0, blue: 0, alpha: 255},
        nativeWindowHandle: nativeHwnd,
        zOrder: zOrder,
        containWatermark: isWatermark ? true : false,
        enableTextureSharing: true });
    comp.on('compositor-failed', (args) => {
        console.log(`Compositor Failed`);
    });
    console.log('Compositor type: ' + comp.getCurrentRenderType());
    gCompositors.push(comp);
    const viewProperties: SlimCore.ViewProperties = {
        area: { x: 0, y: 0, width: 1, height: 1 },
        scalingMode: isWatermark ? 0 : 1,
        mirror: false,
    };
    if (isWatermark) {
        viewProperties.spriteType = SlimCore.CompositorFrameSink.SpriteType.Image;
        // viewProperties.useAlpha = true;
        // viewProperties.useCircleMask = true;
        const imageUriSpecified = getElementById<HTMLInputElement>('news-anchor-image').value;
        // viewProperties.uri = imageUriSpecified !== '' ? imageUriSpecified : 'C:\\Users\\junlia.REDMOND\\Downloads\\watermark.png';
        viewProperties.uri = imageUriSpecified !== '' ? imageUriSpecified : 'C:\\watermark.png';
        viewProperties.useAlphaInImage = true;
    }
    const frameSink = comp.addView(id, viewProperties);
    console.log('Added view with id=' + frameSink.getViewId());
    frameSink.on('first-frame-rendered', (args) => {
        console.log(`First Frame Rendered`);
    });
    frameSink.on('frame-type-changed', (args) => {
        console.log(`Frame type Changed- ${args.type}`);
    });
    frameSink.on('frame-size-changed', (args) => {
        console.log(`Frame Size Changed- width: ${args.width} height: ${args.height}`);
    });
    frameSink.on('full-frame-render-required', (args) => {
        console.log(`Full Frame Render Required- ${args.fullFrameRenderRequired}`);
    });
    frameSink.setVideoPreference(123, 450);
    if (!isWatermark) {
        gMulCompositorVideoBindingRenderer.addFrameSink(frameSink);
        gFrameSinks.push(frameSink);
    }
}

export function createMultipleCompositorsHostRenderer(nativeHwnd?: Buffer)
{
    if (gMulCompositorVideoBindingRenderer == null) return;

    for (let i = 0; i < 8; ++i)
    // for (let i = 0; i < 1; ++i)
    {
        const posX = (i % compositorsPerRow) * compositorsOffset + compositorStart.x;
        const posY = Math.floor(i / compositorsPerRow) * compositorsOffset + compositorStart.y;
        buildCompositorWithFrame(i, i, posX, posY, compositorSize2.width, compositorSize2.height, true, nativeHwnd, false);
    }

    // Add watermark compositor
    buildCompositorWithFrame(9, 9999, 0, 0, compositorSize.width, compositorSize.height, true, nativeHwnd, true);

    // electronIpc.send('create-compositor-renderer', compositor.getBufferName(), CompositorLayout.Vertical, 1);
    electronIpc.on(`compositor-frame-sink-invoke`, (event: Electron.IpcRendererEvent, _: string, method: string, ...args: any[]) => {
        compositor[method](...args);
    });
    electronIpc.on('compositor-view-update', (event: Electron.IpcRendererEvent, _: string, id: number, x: number, y: number, width: number, height: number) => {
        console.log(`update layout`);
    });
    electronIpc.on('compositor-update', (event: Electron.IpcRendererEvent, x: number, y: number, width: number, height: number) => {
        console.log(`update compositor: ${width}x${height} (${x},${y})`);
        compositorSize = { width, height };
        compositorOffset = { x, y };
        compositor.configure({size: compositorSize, offset: compositorOffset});
    });
}

export function createCompositorHostRenderers(count: number, nativeHwnd?: Buffer)
{
    if (getSelectedVideoBindingRenderer() == null) return;

    if (navigator.platform === 'MacIntel')
    {
        const machPort = sendMessageSync('native-renderer:start', nativeHwnd);
        // On Mac nativeHwnd is actually NSView ptr and not accessible on another process
        // We create machport receiver and pass the name to background process so
        // IOSurfaces can be passed as mach_ports between the processes
        nativeHwnd = Buffer.from(machPort);
    }
    compositor = slimcore.createCompositor({
        enableGpu: true,
        size: compositorSize,
        enableBackgroundTransparency: true,
        backgroundColor: {red: 0, green: 0, blue: 0, alpha: 255},
        nativeWindowHandle: nativeHwnd,
        enableTextureSharing: true });
    const type = compositor.getCurrentRenderType();
    console.log('CREATE COMPOSITOR RENDER TYPE: ' + type);
    const layout = getSelectedCompositorLayout();
    if (layout === CompositorLayout.NewsAnchor)
    {
        count += 1;
    }

    electronIpc.send('create-compositor-renderer', compositor.getBufferName(), layout, count);
    electronIpc.on(`compositor-frame-sink-invoke`, (event: Electron.IpcRendererEvent, _: string, method: string, ...args: any[]) => {
        compositor[method](...args);
    });
    electronIpc.on('compositor-view-update', (event: Electron.IpcRendererEvent, _: string, id: number, x: number, y: number, width: number, height: number) => {
        console.log(`update layout`);

        const viewProperties: SlimCore.ViewProperties = {
            area: { x: x / 640, y: y / 360, width: width / 640, height: height / 360 },
            scalingMode: SlimCore.CompositorFrameSink.ScalingMode.Fit,
        };
        if (layout === CompositorLayout.PictureInPicture) {
            viewProperties.zOrder = id;
            viewProperties.useAlpha = true;
            viewProperties.useCircleMask = false;
            if (id === 1)
                viewProperties.scalingMode = SlimCore.CompositorFrameSink.ScalingMode.Crop;
        }
        else if (layout === CompositorLayout.NewsAnchor) {
            viewProperties.zOrder = id;
            viewProperties.useAlpha = true;
            if (id === 0) {
                viewProperties.scalingMode = SlimCore.CompositorFrameSink.ScalingMode.Stretch;
                viewProperties.uri = getElementById<HTMLInputElement>('news-anchor-image').value;
            }
        }
        else {
            viewProperties.useAlpha = false;
        }

        compositor.updateLayout(compositorSize, [{id, properties: viewProperties}], {x: 0, y: 0, width: 1, height: 1});
    });
    electronIpc.on('compositor-update', (event: Electron.IpcRendererEvent, x: number, y: number, width: number, height: number) => {
        console.log(`update compositor: ${width}x${height} (${x},${y})`);
        compositorSize = { width, height };
        compositorOffset = { x, y };
        compositor.configure({size: compositorSize, offset: compositorOffset});
    });

    for (let i = 0; i < count; ++i) {
        console.log(`begin create-compositor-render view main index.ts ${i}`);
        const frameSink = compositor.addView(i);
        if (layout === CompositorLayout.NewsAnchor && i === 0) {
            // don't add static image sink to videobindingrenderer
            continue;
        }
        const j = layout === CompositorLayout.NewsAnchor ? i - 1 : i;
        videoBindingRenderers.get(getVideoObjectId(j)).addFrameSink(frameSink);
    }
}

export function openCompositorWindow(native: boolean)
{
    const videoObjectId = getSelectedVideoObjectId();

    if (!getSelectedVideoBindingRenderer())
    {
        const videoBindingRenderer = slimcore.createVideoBindingRenderer({
            enableDXVA: true,
        });

        slimcore.videoCreateBinding(videoObjectId, videoBindingRenderer);

        setSelectedVideoBindingRenderer(videoBindingRenderer);
    }

    electronIpc.on(`compositor-window-ready`, (event: Electron.IpcRendererEvent, nativeHwnd?: Buffer) => {
        const hwndlog = nativeHwnd ? `${nativeHwnd.byteLength} bytes` : 'not set';
        console.log(`compositor-window-ready main index.ts, nativeHwnd ${hwndlog}`);
        createCompositorHostRenderers(videoBindingRenderers.size, nativeHwnd);
    });

    electronIpc.once(`compositor-closed`, () => {
        compositor.dispose();
        compositor = null;
    });
    electronIpc.sendSync(native ? 'open-native-compositor' : 'open-compositor');
}

export function popupVideoRenderer()
{
    const rendererType = getSelectedRendererType();

    let frameSink = createChromiumFrameSink(rendererType);
    getSelectedVideoBindingRenderer().addFrameSink(frameSink);

    const bufferName = frameSink.getBufferName();

    const args: OpenPopupArgs = { rendererType, bufferName };
    const popupId = electronIpc.sendSync('open-popup', args);

    electronIpc.on(`frame-sink-invoke-${popupId}`, (event: Electron.IpcRendererEvent, method: string, ...args: any[]) => {
        frameSink[method](...args);
    });

    electronIpc.once(`popup-closed-${popupId}`, () => {
        frameSink.dispose();
        frameSink = null;
    });
}

export function popupCompositorVideoRenderer()
{
    openCompositorWindow(false);
}

export function popupNativeCompositorVideoRenderer()
{
    openCompositorWindow(true);
}

export function popupNativeMultipleCompositorsVideoRenderer()
{
    const videoObjectId = getSelectedVideoObjectId();

    if (!gMulCompositorVideoBindingRenderer)
    {
        gMulCompositorVideoBindingRenderer = slimcore.createVideoBindingRenderer({
            enableDXVA: true,
            ignoreBlankFrame: false,
        });

        slimcore.videoCreateBinding(videoObjectId, gMulCompositorVideoBindingRenderer);
    }

    electronIpc.on(`compositor-window-ready`, (event: Electron.IpcRendererEvent, nativeHwnd?: Buffer) => {
        const hwndlog = nativeHwnd ? `${nativeHwnd.byteLength} bytes` : 'not set';
        console.log(`multiple compositors mode, compositor-window-ready main index.ts, nativeHwnd ${hwndlog}`);
        createMultipleCompositorsHostRenderer(nativeHwnd);
    });

    electronIpc.once(`compositor-closed`, () => {
        for (const compositor of gCompositors) {
            compositor.removeAllListeners();
            compositor.dispose();
        }
        gCompositors = [];
        for (const frameSink of gFrameSinks) {
            gMulCompositorVideoBindingRenderer.removeFrameSink(frameSink);
            frameSink.removeAllListeners();
            frameSink.dispose();
        }
        gFrameSinks = [];
    });
    electronIpc.sendSync('open-native-compositor');
}

export function setVideoPreference(width: number, height: number)
{
    if (getSelectedVideoBindingRenderer()) {
        getSelectedVideoBindingRenderer().setVideoPreference(width, height);
    }
}

export async function captureFrame()
{
    const frame = await getSelectedVideoBindingRenderer().captureFrame();
    document.body.appendChild(drawImage(frame.image));
}

export function createPreviewVideo()
{
    const type = getSelectedVideoType();
    const deviceId = (type === Enums.VideoType.Video) ? getSelectedCameraId() : undefined;
    const deviceName = (type === Enums.VideoType.Video) ? getSelectedCameraName() : undefined;

    const videoObjectId = slimcore.createPreviewVideo(type, deviceName, deviceId);

    getVideoObject(videoObjectId, { type });

    updateVideoList();
}

export function createLocalVideo()
{
    const type = getSelectedVideoType();
    const deviceId = (type === Enums.VideoType.Video) ? getSelectedCameraId() : undefined;
    const deviceName = (type === Enums.VideoType.Video) ? getSelectedCameraName() : undefined;

    const videoObjectId = slimcore.createLocalVideo(type, deviceName, deviceId);

    getVideoObject(videoObjectId, { type });

    updateVideoList();
}

const videoEffectTypes: Enums.VideoEffectType[] = [
    Enums.VideoEffectType.Off,
    Enums.VideoEffectType.BackgroundBlurDefault,
    Enums.VideoEffectType.BackgroundBlurLight,
    Enums.VideoEffectType.BackgroundBlurExperimental_1,
    Enums.VideoEffectType.BackgroundBlurExperimental_2,
    Enums.VideoEffectType.BackgroundReplacement,
    Enums.VideoEffectType.WhiteboardZoom,
    Enums.VideoEffectType.WhiteboardCleanup,
    Enums.VideoEffectType.WhiteboardMotionDetection,
    Enums.VideoEffectType.WhiteboardZoomAndCleanup,
    Enums.VideoEffectType.WhiteboardCleanupAndMotion,
    Enums.VideoEffectType.WhiteboardZoomAndCleanupAndMotion,
];

export function updateDeviceEffectList()
{
    const select = getElementById<HTMLSelectElement>('device-effect-list');
    clearElement(select);

    const deviceId = getSelectedCameraId();
    const capability = slimcore.getDeviceEffectsCapability(deviceId);

    for (const value of videoEffectTypes) {
        // tslint:disable-next-line:no-bitwise
        if ((capability & value) === value) {
            select.appendChild(createOption(Enums.VideoEffectType[value], `${value}`));
        }
    }
}

export function setDeviceEffects()
{
    const deviceId = getSelectedCameraId();
    const type = getSelectedDeviceEffect();

    slimcore.setDeviceEffects(deviceId, type);
}

export function setBackgroundImage()
{
    const deviceId = getSelectedCameraId();
    const imagePath = getElementById<HTMLInputElement>('background-image').value;

    slimcore.setBackgroundImage(deviceId, imagePath);
}

export function getImageProperty() {
    const imagePath = getElementById<HTMLInputElement>('original-image').value;
    const imageSize = slimcore.getImageProperty(imagePath);
    if (typeof imageSize === 'string') {
        throw new Error('getImageProperty API is not available');
    }
    const {width, height} = imageSize;
    getElementById<HTMLInputElement>('width').value = width.toString();
    getElementById<HTMLInputElement>('height').value = height.toString();
}

export function transformImage() {
    const imagePath = getElementById<HTMLInputElement>('original-image').value;
    const width = parseInt(getElementById<HTMLInputElement>('width').value, 10);
    const height = parseInt(getElementById<HTMLInputElement>('height').value, 10);
    const imageResizedPath = getElementById<HTMLInputElement>('resized-image').value;
    slimcore.transformImage( imagePath, width, height, imageResizedPath);
}

export function displayVideoDeviceSetting()
{
    sendMessage('sharing-indicator:displayVideoDeviceSetting', getSelectedCameraId());
}

export function dumpVideoSourceImages()
{
    const videoObjectId = getSelectedVideoObjectId();
    slimcore.dumpVideoSourceImages(videoObjectId)
        .then((result: number) => {
            console.log(`Number of images dumped: ${result}`);
        });
}

export function fillVideoEffects()
{
    const v = getElementById<HTMLSelectElement>('json-request-list').value;
    const req = {
        type: v,
        request: {},
    };
    if (v === 'EnableEffects' || v === 'DisableEffects') {
        req.request = {
            effects: [ { type: 'BackgroundModification', options: { variant: 'Blur' } } ],
        };
    }
    getElementById<HTMLInputElement>('video-effects-request').value = JSON.stringify(req, null, 2);
}

export function sendMessageVideoEffects()
{
    const deviceId = getSelectedCameraId();
    const req = JSON.parse(getElementById<HTMLInputElement>('video-effects-request').value);
    const result = slimcore.sendMessageDeviceVideoEffects(deviceId, req);
    getElementById<HTMLInputElement>('video-effects-response').value = JSON.stringify(result, null, 2);
}

export function cameraAutoControl(enable?: boolean)
{
    const videoObjectId = getSelectedVideoObjectId();
    slimcore.cameraAutoControl(videoObjectId, enable)
    .then((state) => {
        getElementById('cameraAutoControlState').innerText = `state=${state}`;
    })
    .catch((error) => {
        getElementById('cameraAutoControlState').innerText = `state=failed with "${error}"`;
    });
}

export async function cameraManualControlEnumerate()
{
    const select = getElementById<HTMLSelectElement>('camera-controls-list');
    clearElement(select);
    const videoObjectId = getSelectedVideoObjectId();
    const controls = await slimcore.enumerateCameraManualControls(videoObjectId);
    for (const control of controls)
    {
        const opt = createOption('id: ' + control.id.toString() + ' | name: ' + control.name.toString() + ' | modes: ' + control.supportedModes, ' ');
        select.appendChild(opt);
    }
}

export async function cameraManualControlGetStates()
{
    const select = getElementById<HTMLSelectElement>('camera-controls-states-list');
    clearElement(select);
    const videoObjectId = getSelectedVideoObjectId();
    const controls = await slimcore.enumerateCameraManualControls(videoObjectId);
    const statesToUpdate: SlimCore.CameraControl.State[] = [];
    for (const control of controls)
    {
        // tslint:disable-next-line:no-bitwise
        if (control.supportedModes & SlimCore.CameraControl.Mode.Auto)
        {
            const state: SlimCore.CameraControl.State = {id: control.id, mode: SlimCore.CameraControl.Mode.Auto, value: false, context: null};
            statesToUpdate.push(state);
        }

        // tslint:disable-next-line:no-bitwise
        if (control.supportedModes & SlimCore.CameraControl.Mode.Check)
        {
            const state: SlimCore.CameraControl.State = {id: control.id, mode: SlimCore.CameraControl.Mode.Check, value: false, context: null};
            statesToUpdate.push(state);
        }
    }
    const states = await slimcore.getCameraManualControlStates(videoObjectId, statesToUpdate);
    for (const state of states)
    {
        if (state == undefined) {
            select.appendChild(createOption('undefined', ' '));
        }
        else {
            select.appendChild(createOption('id: ' + state.id + ' mode: ' + state.mode + ' value: ' + state.value + ' context: ' + state.context, ' '));
        }
    }
}

export async function cameraManualControlSetStates()
{
    const videoObjectId = getSelectedVideoObjectId();
    const statesToUpdate: SlimCore.CameraControl.State[] = [];
    const controls = await slimcore.enumerateCameraManualControls(videoObjectId);
    for (const control of controls)
    {
        // tslint:disable-next-line:no-bitwise
        if (control.supportedModes & SlimCore.CameraControl.Mode.Auto)
        {
            const state: SlimCore.CameraControl.State = {id: control.id, mode: SlimCore.CameraControl.Mode.Auto, value: false, context: null};
            statesToUpdate.push(state);
        }

        // tslint:disable-next-line:no-bitwise
        if (control.supportedModes & SlimCore.CameraControl.Mode.Check)
        {
            const state: SlimCore.CameraControl.State = {id: control.id, mode: SlimCore.CameraControl.Mode.Check, value: false, context: null};
            statesToUpdate.push(state);
        }
    }
    const states = await slimcore.getCameraManualControlStates(videoObjectId, statesToUpdate);
    const stateId = getElementById<HTMLSelectElement>('state-id').value;
    const stateValue = getElementById<HTMLSelectElement>('state-value').value;
    for (const state of states)
    {
        if (state.id === parseInt(stateId, 10))
        {
            state.value = Boolean(parseInt(stateValue, 10));
        }
    }
    try {
        const state = await slimcore.setCameraManualControlStates(videoObjectId, states);
        getElementById('cameraControlSetStates').innerText = `isSet=${state}`;
    } catch (e) {
        getElementById('cameraControlSetStates').innerText = `isSet=failed with "${e}"`;
    }
}

export async function getSourceFormats()
{
    const deviceId = getSelectedCameraId();

    const select = getElementById<HTMLSelectElement>('format-list');
    clearElement(select);

    const formats = await slimcore.getSourceFormats(deviceId);

    for (const fmt of formats) {
        select.appendChild(createOption(fmt.width.toString() + 'x' + fmt.height.toString() + '@' + parseFloat(fmt.frameRate.toString()).toFixed(2), ''));
    }
}

export async function getCameraMaxResolution()
{
    const deviceId = getSelectedCameraId();
    const fmts = await slimcore.getSourceFormats(deviceId);
    if (fmts)
    {
        const fmt = fmts[0];
        getElementById('source-max-res').innerText = fmt.width.toString() + 'x' + fmt.height.toString() + '@' + parseFloat(fmt.frameRate.toString()).toFixed(2);
    }
}

export function startVideo()
{
    const videoObjectId = getSelectedVideoObjectId();

    slimcore.videoStart(videoObjectId);
}

export function stopVideo()
{
    const videoObjectId = getSelectedVideoObjectId();

    slimcore.videoStop(videoObjectId);
}

function updateDeviceList(id: string, list: SlimCore.DeviceInfo[])
{
    const select = getElementById<HTMLSelectElement>(id);
    clearElement(select);

    for (const info of list) {
        select.appendChild(createOption(info.label, info.id));
    }
}

function updateAudioDeviceList()
{
    updateDeviceList('microphone-list', slimcore.getMicrophoneList());
    updateDeviceList('speaker-list', slimcore.getSpeakerList());
}

function updateVideoDeviceList()
{
    updateDeviceList('camera-list', slimcore.getCameraList());
}

function updateDisplayList()
{
    const select = getElementById<HTMLSelectElement>('display-list');
    clearElement(select);

    for (const info of slimcore.getMonitorList()) {
        const name = info.name || JSON.stringify(info.region);
        select.appendChild(createOption(name, info.monitorId.toString()));
    }
}

export function updateWindowList()
{
    const select = getElementById<HTMLSelectElement>('window-list');
    clearElement(select);

    type WindowListGroups = {
        [key: string]: SlimCore.WindowInfo[];
    };

    const groups: WindowListGroups = {};

    for (const info of slimcore.getWindowList()) {
        const key = info.applicationName;
        groups[key] = groups[key] || [];
        groups[key].push(info);
    }

    for (const group of Object.keys(groups)) {
        const optgroup = document.createElement('optgroup');
        optgroup.label = group;

        for (const info of groups[group]) {
            optgroup.appendChild(createOption(info.title, info.windowId.toString()));
        }

        select.appendChild(optgroup);
    }
}

function updateDeviceRotation()
{
    slimcore.setDeviceRotation(SlimCore.queryDeviceRotation());
}

function handleDisplaysChanged()
{
    updateDisplayList();
    updateDeviceRotation();
}

interface WebGLLoseContext
{
    loseContext(): void;
    restoreContext(): void;
}

function getLoseContextExtension()
{
    const gl = (videoRenderer['_context'] as WebGLRenderingContext);
    return gl.getExtension('WEBGL_lose_context') as WebGLLoseContext;
}

let webGLLoseContext: WebGLLoseContext = null;

export function loseContext()
{
    webGLLoseContext = getLoseContextExtension();
    webGLLoseContext.loseContext();
}

export function restoreContext()
{
    webGLLoseContext.restoreContext();
    webGLLoseContext = null;
}

export function placeCall()
{
    const participant = getElementById<HTMLInputElement>('participant').value;

    callHandler.placeCall(uuidv4(), [participant]);
}

export function placeGoLiveCall()
{
    const threadId = getElementById<HTMLInputElement>('threadId').value;

    callHandler.placeCall(uuidv4(), [], {
        isHostless: true,
        threadId: threadId,
    });
}

export function answerCall()
{
    callHandler.answerCall(getSelectedCallObjectId(), false);
}

export function leaveCall()
{
    callHandler.leaveCall(getSelectedCallObjectId());
}

export function callAttachSendVideo()
{
    callHandler.callAttachSendVideo(getSelectedCallObjectId(), getSelectedVideoObjectId());
}

export function callGetTechnicalInformation()
{
    const json = callHandler.callGetTechnicalInformationJson(getSelectedCallObjectId());

    console.log(JSON.parse(json));
}

export function callMute(mute: boolean)
{
    callHandler.callMute(getSelectedCallObjectId(), mute);
}

export function callMuteSpeaker(mute: boolean)
{
    callHandler.callMuteSpeaker(getSelectedCallObjectId(), mute);
}

export function callHold(hold: boolean)
{
    callHandler.callHold(getSelectedCallObjectId(), hold);
}

const dtmfMap = {
    '0': Enums.DtmfTone.Num0,
    '1': Enums.DtmfTone.Num1,
    '2': Enums.DtmfTone.Num2,
    '3': Enums.DtmfTone.Num3,
    '4': Enums.DtmfTone.Num4,
    '5': Enums.DtmfTone.Num5,
    '6': Enums.DtmfTone.Num6,
    '7': Enums.DtmfTone.Num7,
    '8': Enums.DtmfTone.Num8,
    '9': Enums.DtmfTone.Num9,
    '*': Enums.DtmfTone.Star,
    '#': Enums.DtmfTone.Pound,
};

export function sendDtmf(tone: string)
{
    callHandler.callSendDtmf(getSelectedCallObjectId(), dtmfMap[tone]);
}

export function startDataChannel()
{
    if (dataChannel) {
        dataChannel.start();
    }
}

export function stopDataChannel()
{
    if (dataChannel) {
        dataChannel.stop();
    }
}

const intentMap = {
    '0' : Enums.Intent.Regular,
    '2' : Enums.Intent.CallPush,
    '3' : Enums.Intent.CallUser,
    '5' : Enums.Intent.CallPreheat,
};

export function fireIntent()
{
    const intentUser = getElementById<HTMLInputElement>('intent-user').value;
    const intentValue = getElementById<HTMLSelectElement>('intent-value').value;

    if (intentValue === '5')
    {
        const preheatCall: SlimCore.CallProperties = {
            mediaPeerType: Enums.MediaPeerType.ConsumerMultiParty,
        };

        slimcore.fireIntent(intentMap[intentValue], intentUser, preheatCall);

    }
    else
    {
        slimcore.fireIntent(intentMap[intentValue]);
    }
}

export function insertRegistrationTransports()
{
    const serviceTypes = getElementById<HTMLInputElement>('serviceTypes').value;
    const contexts = getElementById<HTMLInputElement>('contexts').value;
    const registrationTokens = getElementById<HTMLInputElement>('registrationTokens').value;
    const registrationTTLs = getElementById<HTMLInputElement>('registrationTTLs').value;
    const activityId = getElementById<HTMLInputElement>('activityId').value;
    const reason = getElementById<HTMLInputElement>('reason').value;

    const options: SlimCore.InsertRegistrationTransportOptions = {
        serviceTypes: serviceTypes.split(';').map(Number),
        contexts: contexts.split(';'),
        registrationTokens: registrationTokens.split(';'),
        registrationTTLs: registrationTTLs.split(';').map(Number),
        activityId: activityId,
        reason: reason,
    };

    slimcore.insertRegistrationTransports(options);
}

export function sendData()
{
    const msg = getElementById<HTMLInputElement>('data-channel-input').value;

    if (dataSource) {
        dataSource.sendData(Buffer.from(msg));
    }
}

let trouter: SlimCore.Trouter = null;
let listener: SlimCore.TrouterListener = null;

export function createTrouterListener()
{
    trouter = slimcore.createTrouter();
    listener = slimcore.createTrouterListener();
}

export function registerTrouterListener()
{
    const path = getElementById<HTMLSelectElement>('trouterpath').value;
    trouter.registerListener(listener, path, 'MyLogging');

    listener.on('trouter-connected', (args) => {
        const ttl = trouter.getConnectionTTLInSec();
        console.log(`trouter-connected: Connection TTL=${ttl}`);
        const connId = trouter.getConnectionId();
        console.log(`trouter-connected: Connection ID=${connId}`);
        const clientId = trouter.getConnectedClientId();
        console.log(`trouter-connected: Connected client ID=${clientId}`);
    });

    listener.on('trouter-request', (args) => {
        const request = args.request;
        const response = args.response;

        const headers = request.getHeaders();
        let body = '<html><body>Got it!<p/>';

        if (headers)
        {
            console.log('trouter-request: got headers');
            for (const header of headers) {
                body += `<li>${header.header}=${header.value}</li>`;
            }
        }
        else
        {
            console.log('trouter-request: no header');
            body += 'No headers found';
        }

        body += ('<p/>' + request.getBody());
        body += '</body></html>';

        response.setBody(body);
        response.setStatus(200);
        response.send();

        request.dispose();
        response.dispose();
    });
}

export function getTrouterConnectionTTL()
{
    const ttl = trouter.getConnectionTTLInSec();
    console.log(`trouter connection TTL: ${ttl}`);
}

export function unregisterTrouterListener()
{
    trouter.unregisterListener(listener);
}

export function destroyTrouterListener()
{
    if (listener) {
        listener.dispose();
        listener = null;
    }

    if (trouter) {
        trouter.dispose();
        trouter = null;
    }
}

let dtcInstance: NativeTrouterClient.TrouterClient = null;
let dtcConnCache = '';
let dtcReceiverId: string = null;
let dtcSendResponseFunc: NativeTrouterClient.SendResponseFunc = null;

export function decoupledTrouterClient_GetInstance()
{
    const username = getElementById<HTMLInputElement>('dtc-username').value;
    dtcInstance = window['trouterclient'].getInstance(username);
    for (const btn of document.querySelectorAll('#dtc button')) {
        (btn as HTMLButtonElement).disabled = false;
    }
}

export function decoupledTrouterClient_Dispose()
{
    if (dtcInstance) {
        dtcInstance.dispose();
        dtcInstance = null;
    }
}

export function decoupledTrouterClient_AttachHost()
{
    const host = {
        getAuthHeaders(params: {}, resolve: (headers: NativeTrouterClient.Headers) => void, reject: (reason: string) => void) {
            try {
                const token = getElementById<HTMLInputElement>('dtc-token').value;
                resolve({'X-Skypetoken': token});
            } catch (e) {
                reject(e.toString());
            }
        },

        getConnectionCache(resolve: (content: string) => void, reject: (reason: string) => void) {
            try {
                resolve(dtcConnCache);
            } catch (e) {
                reject(e.toString());
            }
        },
        setConnectionCache(content: string) {
            dtcConnCache = content;
        },

        onTrouterConnected(connectionInfo: NativeTrouterClient.ConnectionInfo) {
            getElementById<HTMLPreElement>('dtc-state').innerText = JSON.stringify(connectionInfo, null, '  ');

        },
        onTrouterDisconnected() {
            getElementById<HTMLPreElement>('dtc-state').innerText = 'disconnected';
        },

        onTelemetryEvent(json: string) {
            console.log(`Trouter Client telemetry event: ${JSON.stringify(JSON.parse(json), null, '  ')}`);
        },

        onUserActivityStateAccepted(correlationVector: string) {
            console.log(`Trouter Client onUserActivityStateAccepted: ${correlationVector}`);
        },

        onMessageLoss(flowTags: string[]) {
            console.log(`Trouter Client onMessageLoss: ${JSON.stringify(flowTags)}`);
        },
    };

    const config = getElementById<HTMLTextAreaElement>('dtc-config').value;
    const epid = getElementById<HTMLInputElement>('dtc-epid').value;

    dtcInstance.attachHost(host, {
        appVersion: '999/1.0.0.0/electron-test-app',
        configJson: config,
        epid: epid,
    });
}

export function decoupledTrouterClient_DetachHost()
{
    dtcInstance.detachHost();
}

export function decoupledTrouterClient_UpdateConfig()
{
    const config = getElementById<HTMLTextAreaElement>('dtc-config').value;
    dtcInstance.updateRuntimeConfig(config);
}

export function decoupledTrouterClient_SetUserActivityState()
{
    const stateName = getElementById<HTMLSelectElement>('dtc-uas').value;
    let state: NativeTrouterClient.UserActivityState;
    switch (stateName) {
        case 'inactive':
            state = NativeTrouterClient.UserActivityState.Inactive;
            break;
        case 'active':
            state = NativeTrouterClient.UserActivityState.Active;
            break;
        default:
            state = NativeTrouterClient.UserActivityState.Unknown;
            break;
    }
    dtcInstance.setUserActivityState(state);
}

export function decoupledTrouterClient_RegisterReceiver()
{
    dtcReceiverId = uuidv4();
    dtcInstance.registerReceiver(
        dtcReceiverId,
        getElementById<HTMLInputElement>('dtc-receiver-path').value,
        (request: NativeTrouterClient.Request, sendResponseFunc: NativeTrouterClient.SendResponseFunc) => {
            getElementById<HTMLDivElement>('dtc-request').innerText = JSON.stringify(request, null, '  ');
            dtcSendResponseFunc = sendResponseFunc;
        });
}

export function decoupledTrouterClient_UnregisterReceiver()
{
    dtcInstance.unregisterReceiver(dtcReceiverId);
    dtcReceiverId = null;
}

export function decoupledTrouterClient_SendResponse()
{
    dtcSendResponseFunc({
        status: 200,
        headers: {
            'X-AdditionalHeaders': 'work fine',
            'X-EvenWith': 'multiple items',
        },
        body: 'Hi there!',
    });
    dtcSendResponseFunc = null;
}

export function downloadModel()
{
    const url = getElementById<HTMLInputElement>('ai-model-url').value;
    const type = Enums.DownloadType.Normal;
    try {
        gHash = slimcore.downloadModel(url, type);
        getElementById<HTMLPreElement>('url-hash').innerText = 'Initiated model download. hash:' + gHash;
    }
    catch (e) {
        getElementById<HTMLPreElement>('url-hash').innerText = `Download model failed with "${e}"`;
    }
}

let videoDeviceListener: SlimCore.VideoDeviceListener = null;
let videoDeviceListenerHandle: SlimCore.Disposable = null;

export function createVideoDeviceListener()
{
    videoDeviceListener = slimcore.createVideoDeviceListener();
}

export function initVideoDeviceListener()
{
    const el = getElementById<HTMLInputElement>('VideoDeviceListener_devicePath');
    videoDeviceListenerHandle = videoDeviceListener.handle('video-device-state-changed', undefined, (args) => {
        const resultDisplay = getElementById<HTMLInputElement>('VideoDeviceListener_lastEventTime');
        resultDisplay.value = Date.now().toString() + ' ' + args.state.toString();
    });
    videoDeviceListener.initialise(el.value);
}

export function destroyVideoDeviceListener()
{
    if (videoDeviceListenerHandle != null)
    {
        videoDeviceListenerHandle.dispose();
        videoDeviceListenerHandle = null;
    }

    if (videoDeviceListener != null)
    {
        videoDeviceListener.dispose();
        videoDeviceListener = null;
    }
}

export function getAiDevices()
{
    const select = getElementById<HTMLSelectElement>('ai-device-list');
    const devices = slimcore.getAiDevices();
    clearElement(select);
    for (const device of devices) {
        select.appendChild(createOption(device, device));
    }
}

const modelTypeMap = {
    'Unknown' : Enums.AiDeviceModelType.Unknown,
    'PlazaASD' : Enums.AiDeviceModelType.PlazaASD,
    'PlazaVC' : Enums.AiDeviceModelType.PlazaVC,
    'PlazaFD' : Enums.AiDeviceModelType.PlazaFD,
};

export function getAiDeviceModels()
{
    const deviceId = getElementById<HTMLSelectElement>('ai-device-list').value;
    const modelType = modelTypeMap[getElementById<HTMLSelectElement>('ai-device-model-type').value];
    const models = slimcore.getAiDeviceModels(deviceId, modelType);
    const select = getElementById<HTMLSelectElement>('ai-device-models');

    clearElement(select);
    for (const model of models) {
        select.appendChild(createOption(model, model));
    }
}

export function getAiDeviceCurrentModel()
{
    const deviceId = getElementById<HTMLSelectElement>('ai-device-list').value;
    const modelType = modelTypeMap[getElementById<HTMLSelectElement>('ai-device-model-type').value];
    const model = slimcore.getAiDeviceCurrentModel(deviceId, modelType);
    getElementById<HTMLInputElement>('ai-device-current-model').value = model;
}

export function setAiDeviceCurrentModel()
{
    const deviceId = getElementById<HTMLSelectElement>('ai-device-list').value;
    const modelType = modelTypeMap[getElementById<HTMLSelectElement>('ai-device-model-type').value];
    const model = getElementById<HTMLInputElement>('ai-device-current-model').value;
    slimcore.setAiDeviceCurrentModel(deviceId, modelType, model);
}

const featureMap = {
    'Unknown' : Enums.AiDeviceFeature.Unknown,
    'PeopleFeed' : Enums.AiDeviceFeature.PeopleFeed,
    'FaceStream' : Enums.AiDeviceFeature.FaceStream,
};

export function getAiDeviceFeatureState()
{
    const deviceId = getElementById<HTMLSelectElement>('ai-device-list').value;
    const feature = featureMap[getElementById<HTMLSelectElement>('ai-device-feature').value];
    const state = slimcore.getAiDeviceFeatureState(deviceId, feature);
    getElementById<HTMLInputElement>('ai-device-feature-state').checked = state;
}

export function setAiDeviceFeatureState()
{
    const deviceId = getElementById<HTMLSelectElement>('ai-device-list').value;
    const feature = featureMap[getElementById<HTMLSelectElement>('ai-device-feature').value];
    const state = getElementById<HTMLInputElement>('ai-device-feature-state').checked;
    slimcore.setAiDeviceFeatureState(deviceId, feature, state);
}

document.addEventListener('DOMContentLoaded', () =>
{
    initSlimCore();
    initVideoTypes();
    initCompositorLayouts();
    initRendererTypes();

    handleDisplaysChanged();
});

handleMessage('displays-changed', handleDisplaysChanged);

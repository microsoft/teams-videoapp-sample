"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const remoteHost = require("../../remote-host/remote-server");
const utils_1 = require("../utils");
const options = utils_1.invokeSync('get-options');
if (options.enableWatchdog) {
    process.startWatchdog(5000, { pingInterval: 1000 });
}
function getSlimCore(name) {
    const slimcore = module.require(name);
    slimcore.crash = () => process.crash();
    slimcore.hang = () => process.hang();
    return slimcore;
}
function requireEx(clientId, name) {
    if (clientId !== options.mainWindowId) {
        throw new Error(`Invalid clientId: ${clientId}`);
    }
    console.log(`requireEx: ${name}`);
    switch (name) {
        case 'ping':
            return null;
        case 'slimcore':
        case 'slimcore/lib/platform':
        case 'slimcore/lib/trouter-client':
            return getSlimCore(name);
        default:
            throw new Error(`Invalid module: ${name}`);
    }
}
remoteHost.init(requireEx, {
    gcInterval: 1000 * 15,
    enableTracing: options.enableTracing,
});
global['crash'] = process.crash;
global['hang'] = process.hang;
electron_1.ipcRenderer.send('plugin-host-ready');
console.log('pid', process.pid);
//# sourceMappingURL=preload.js.map
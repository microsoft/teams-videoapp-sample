import { ipcRenderer } from 'electron';
import * as remoteHost from '../../remote-host/remote-server';
import { PluginHostOptions } from '../ipc';
import { invokeSync } from '../utils';

const options = invokeSync('get-options') as PluginHostOptions;

if (options.enableWatchdog) {
    process.startWatchdog(5000, { pingInterval: 1000 });
}

function getSlimCore(name: string)
{
    const slimcore = module.require(name);

    slimcore.crash = () => process.crash();
    slimcore.hang = () => process.hang();

    return slimcore;
}

function requireEx(clientId: number, name: string)
{
    if (clientId !== options.mainWindowId) {
        throw new Error(`Invalid clientId: ${clientId}`);
    }

    console.log(`requireEx: ${name}`);

    switch (name) {
        case 'ping':
            return null;
        case 'slimcore':
        case 'slimcore/lib/platform':
        case 'slimcore/lib/trouter-client':
            return getSlimCore(name);
        default:
            throw new Error(`Invalid module: ${name}`);
    }
}

remoteHost.init(requireEx, {
    gcInterval: 1000 * 15,
    enableTracing: options.enableTracing,
});

global['crash'] = process.crash;
global['hang'] = process.hang;

ipcRenderer.send('plugin-host-ready');

console.log('pid', process.pid);

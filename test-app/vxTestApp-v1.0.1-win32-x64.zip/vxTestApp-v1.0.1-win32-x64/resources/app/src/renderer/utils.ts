import { ipcRenderer, webFrame, FrameSinkReader } from 'electron';

export const electronIpc: Pick<Electron.IpcRenderer, 'send' | 'sendSync' | 'on' | 'once'> = {
    send: ipcRenderer.send.bind(ipcRenderer),
    sendSync: ipcRenderer.sendSync.bind(ipcRenderer),
    on: ipcRenderer.on.bind(ipcRenderer),
    once: ipcRenderer.once.bind(ipcRenderer),
};

export function invokeSync<T>(command: string, ...args: any[]): T
{
    const [error, result] = ipcRenderer.sendSync(command, ...args);

    if (error) {
        throw error;
    } else {
        return result;
    }
}

export function executePreload(preload: string)
{
    webFrame.executeJavaScript(`(() => {${preload}})();`);
}

function createFrameSinkReaderImpl(bufferName: string)
{
    const reader = new FrameSinkReader();

    reader.on('log', (level, message) => {
        postMessage({ bufferName, level, message }, '*');
    });

    const processFrame = () => {
        const frame = reader.getFrame();
        if (frame !== undefined) {
            postMessage({ bufferName, frame }, '*');
        }
    };

    if (!reader.connect(bufferName, true)) {
        throw new Error('FrameSinkReader.prototype.connect() failed');
    }

    let handle: number;

    const tick = () => {
        processFrame();
        handle = requestAnimationFrame(tick);
    };

    if (reader.isNewFrameEventAvailable) {
        reader.on('new-frame', processFrame);
    } else {
        handle = requestAnimationFrame(tick);
    }

    return {
        dispose: () => {
            cancelAnimationFrame(handle);
            reader.disconnect();
        },
    };
}

export const createFrameSinkReader = FrameSinkReader ? createFrameSinkReaderImpl : undefined;

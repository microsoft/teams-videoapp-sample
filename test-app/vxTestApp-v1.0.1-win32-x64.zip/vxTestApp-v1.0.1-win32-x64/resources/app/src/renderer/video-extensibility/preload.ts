import { ipcRenderer, webFrame, contextBridge } from 'electron';
import { invokeSync, createFrameSinkReader } from '../utils';
import { exposeSlimCore } from '../calling';
import { MainWindowOptions } from '../ipc';
import { RemoteHostConnection } from '../../remote-host/remote-client';
import * as Highcharts from 'highcharts';
import addMore from 'highcharts/highcharts-more';
addMore(Highcharts);

const options = invokeSync('get-options') as MainWindowOptions;
const electronVersion = {
    version: process.versions.electron,
    build: process.versions['microsoft-build'],
};

function initPluginHost(): RemoteHostConnection {
    const pluginHostId = invokeSync('init-plugin-host') as number;

    return {
        id: pluginHostId,
        contextId: process.contextId,
        send(channel: string, args: any[]) {
            return ipcRenderer.sendToRenderer(pluginHostId, channel, args);
        },
        sendSync(channel: string, args: any[], watchdogApi: string) {
            return ipcRenderer.sendToRendererSync(pluginHostId, channel, args, watchdogApi);
        },
        connect() {
            return ipcRenderer.connectToRenderer(pluginHostId);
        },
        on(channel: string, listener: (event: Electron.IpcRendererEvent, ...args: any[]) => void) {
            ipcRenderer.on(channel, (event, ...args) => {
                if (event.senderId === pluginHostId) {
                    listener(event, ...args);
                }
            });
        },
    };
}

function exposeGlobal(name: string, value: any) {
    if (process.contextIsolated) {
        contextBridge.exposeInMainWorld(name, value);
    } else {
        global[name] = value;
    }
}

function createChart(renderTo: string, options: Highcharts.Options): Highcharts.Chart {
    return new Highcharts.Chart(renderTo, options, null);
}

function exposeModules() {
    exposeGlobal('electronVersion', electronVersion);
    exposeGlobal('options', options);
    exposeGlobal('electronIpc', ipcRenderer);
    exposeGlobal('createFrameSinkReader', createFrameSinkReader);
    exposeGlobal('hcChart', {
        createChart,
        setOptions: Highcharts.setOptions,
        getOptions: Highcharts.getOptions,
    });
    process.once('loaded', () => { window['Buffer'] = Buffer; });
    exposeSlimCore({ ...options, initPluginHost });
}

if (location.origin === 'file://') {
    exposeModules();
}

// index.js: Object.defineProperty(exports, "__esModule", { value: true });
webFrame.executeJavaScript(`var exports = {};`);

console.log('pid', process.pid);
console.log('sandbox', !!process.sandboxed);
console.log('contextIsolation', process.contextIsolated);
console.log('electron.version', process.versions.electron);
console.log('electron.build', process.versions['microsoft-build']);

ipcRenderer.on('video.sendMessagePortToMainWindow', (event: Electron.IpcRendererEvent) => {
    window.postMessage('video.sendMessagePortToMainWorld', window.origin, [event.ports[0]]);
});

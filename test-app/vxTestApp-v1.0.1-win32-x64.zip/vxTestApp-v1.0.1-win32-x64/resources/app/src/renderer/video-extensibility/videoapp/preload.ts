import { ipcRenderer } from 'electron';
import { VideoAppHandler } from './video-app-handler';

class WebviewShim {
    private videoAppHandler: VideoAppHandler;
    private domContentLoadedHandler: () => void;
    private iframe: any;
    private iframeContentOrigin: string;
    private windowOrigin: string;
    private skipDomainValidation: boolean;

    /**
     * Initializes a new instance of the WebviewShim. This also registers event listeners.
     */
    public constructor() {
        if (this.isInIframe()) return;
        console.log('pid', process.pid);

        this.videoAppHandler = new VideoAppHandler(this.sendToIframe.bind(this));

        ipcRenderer.on('main-renderer-to-webview-postmessage', (event: Electron.IpcRendererEvent, args: any) => {
            // Need to hook the message send to IFrame for video extensibility, those message from main render.
            // currently only video extensiblity need to hook this for video status changed notification, to determine that 3rd party
            // video app should apply new effect or not.
            if (this.videoAppHandler.eventFilter(args)) {
                return;
            }
            if (args.data) {
                args = args.data;
            }
            this.sendToIframe(args);
        });

        ipcRenderer.on('main-renderer-to-webview-post-form', (event: Electron.IpcRendererEvent, args: any) => {
            this.onPostFormEvent(event, args);
        });

        this.domContentLoadedHandler = () => {
            this.onDOMContentLoaded();
        };

        document.addEventListener('DOMContentLoaded', this.domContentLoadedHandler);
    }

    private isInIframe() {
        try {
            return window.self !== window.top;
        }
        catch (e) {
            return true;
        }
    }

    private onDOMContentLoaded() {
        this.iframe = document.getElementById('extension-tab-frame');
        this.iframeContentOrigin = '';
        this.windowOrigin = window.location.origin;
        // for back compatibility
        if (!this.iframe) {
            const iframeElements = document.getElementsByClassName('extension-tab-frame');
            this.iframe = iframeElements && iframeElements[0];
        }
        if (!this.validateUrl(this.windowOrigin)) {
            this.sendToWebview({ func: 'error', args: { errorName: 'invalidOriginUrl' } }, this.windowOrigin);
            return;
        }
        if (!this.iframe) {
            this.sendToWebview({ func: 'error', args: { errorName: 'noIframeElement' } }, this.windowOrigin);
            return;
        }
        // the hash string is in the form of a query string (#a=b&c=d)
        const hashString = window.location.hash.substring(1);
        const pairs = hashString.split('&');
        const params = {};
        pairs.forEach((pair) => {
            const tokens = pair.split('=');
            if (tokens.length >= 2) {
                params[tokens[0]] = decodeURIComponent(tokens[1]);
            }
        });
        const urlString = params['iframeurl'];
        this.skipDomainValidation = params['skipDomainValidation'];
        if (urlString !== 'about:blank') {
            if (!this.validateUrl(urlString)) {
                this.sendToWebview({ func: 'error', args: { errorName: 'invalidUrl' } }, this.windowOrigin);
                return;
            }
        }
        if (!this.setFrameOriginFromUrl(urlString)) {
            return;
        }
        this.iframe.setAttribute('src', urlString);
        this.iframe.onload = () => {
            this.sendToWebview({ func: 'iframeLoaded' }, this.iframeContentOrigin);
        };
        const messageHandler = (event: Electron.IpcMainEvent) => {
            this.onMessageEvent(event);
        };
        window.addEventListener('message', messageHandler);
        window.onunload = () => {
            window.removeEventListener('message', messageHandler);
            document.removeEventListener('DOMContentLoaded', this.domContentLoadedHandler);
        };
    }

    private sendToIframe(message: any) {
        if (message && message.func === 'unloadFrame' && this.iframe) {
            this.iframe.setAttribute('src', 'about:blank');
            return;
        }
        if (this.iframe && this.iframe.contentWindow && !this.iframe.contentWindow.closed) {
            if (this.skipDomainValidation && message.origin && message.origin !== this.iframeContentOrigin) {
                this.iframeContentOrigin = message.origin;
            }
            if (message.origin) {
                delete message.origin;
            }
            this.iframe.contentWindow.postMessage(message.stringMessage || message, this.iframeContentOrigin);
        }
        else {
            this.sendToWebview({ func: 'error', args: { errorName: 'sendMessageToIframe' } }, this.windowOrigin);
        }
    }

    private sendToWebview(message: any, origin: string) {
        ipcRenderer.sendToHost('webview-to-main-renderer-postmessage', origin, message);
    }

    private onMessageEvent(event: any) {
        const sourceWindow = event.source;
        const eventOrigin = event.origin;
        // send the message to the parent, videoApp message handler
        if (this.videoAppHandler.eventFilter(event)) {
            return;
        }
        if (this.iframeContentOrigin === eventOrigin && sourceWindow === this.iframe.contentWindow) {
            this.sendToWebview(event.data, eventOrigin);
        }
        else if (eventOrigin === this.windowOrigin && sourceWindow === window) {
            this.sendToWebview(event.data, eventOrigin);
        }
        else if (this.skipDomainValidation && this.iframeContentOrigin !== eventOrigin) {
            this.sendToWebview(event.data, eventOrigin);
        }
        else {
            this.sendToWebview({ func: 'error', args: { errorName: 'invalidEventSource', errorInfo: eventOrigin } }, this.windowOrigin);
        }
    }

    private validateUrl(url: string) {
        const urlParser = document.createElement('a');
        urlParser.href = url;
        const protocol = urlParser.protocol;
        return !!process || protocol === 'https:';
    }

    private setFrameOriginFromUrl(url: string) {
        // if the iframe src is about:blank, use the window origin (iframe-container origin)
        if (url === 'about:blank') {
            this.iframeContentOrigin = this.windowOrigin;
            return true;
        }
        try {
            const urlParser = document.createElement('a');
            urlParser.href = url;
            this.iframeContentOrigin = 'https://' + urlParser.hostname;
            return true;
        }
        catch (e) {
            this.sendToWebview({ func: 'error', args: { errorName: 'getOrigin', errorInfo: JSON.stringify(e && e.message) } }, this.windowOrigin);
            return false;
        }
    }

    private onPostFormEvent(event: any, args: any) {
        if (args && args['url']) {
            const url = args['url'];
            if (!this.iframe) {
                this.sendToWebview({ func: 'error', args: { errorName: 'noIframeElement' } }, this.windowOrigin);
                return;
            }
            if (!this.validateUrl(url)) {
                this.sendToWebview({ func: 'error', args: { errorName: 'invalidOriginUrl' } }, this.windowOrigin);
                return;
            }
            if (!this.setFrameOriginFromUrl(url)) {
                return;
            }
            this.postFormToIframe(args['url'], args['params'] || {});
        }
    }

    private postFormToIframe(url: string, params: any) {
        if (!this.iframe) {
            this.sendToWebview({ func: 'error', args: { errorName: 'noIframeElement' } }, this.windowOrigin);
            return;
        }
        const body = document.body;
        if (!body) {
            this.sendToWebview({ func: 'error', args: { errorName: 'noBodyElement' } }, this.windowOrigin);
            return;
        }
        const webviewForm = document.createElement('form');
        webviewForm.setAttribute('target', this.iframe.name);
        webviewForm.setAttribute('method', 'POST');
        webviewForm.setAttribute('hidden', '');
        webviewForm.setAttribute('action', url);
        webviewForm.setAttribute('accept-charset', 'UTF-8');
        if (params) {
            Object.keys(params).forEach((key) => {
                const input = document.createElement('input');
                input.type = 'text';
                input.name = key;
                input.value = JSON.stringify(params[key]);
                webviewForm.appendChild(input);
            });
        }
        body.appendChild(webviewForm);
        webviewForm.submit();
        body.removeChild(webviewForm);
    }
}

// instantiate a preload instance
(() => new WebviewShim())();

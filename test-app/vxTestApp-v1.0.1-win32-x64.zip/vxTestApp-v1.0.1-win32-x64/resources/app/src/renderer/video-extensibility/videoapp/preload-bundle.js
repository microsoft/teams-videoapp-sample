(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const video_app_handler_1 = require("./video-app-handler");
class WebviewShim {
    /**
     * Initializes a new instance of the WebviewShim. This also registers event listeners.
     */
    constructor() {
        if (this.isInIframe())
            return;
        console.log('pid', process.pid);
        this.videoAppHandler = new video_app_handler_1.VideoAppHandler(this.sendToIframe.bind(this));
        electron_1.ipcRenderer.on('main-renderer-to-webview-postmessage', (event, args) => {
            // Need to hook the message send to IFrame for video extensibility, those message from main render.
            // currently only video extensiblity need to hook this for video status changed notification, to determine that 3rd party
            // video app should apply new effect or not.
            if (this.videoAppHandler.eventFilter(args)) {
                return;
            }
            if (args.data) {
                args = args.data;
            }
            this.sendToIframe(args);
        });
        electron_1.ipcRenderer.on('main-renderer-to-webview-post-form', (event, args) => {
            this.onPostFormEvent(event, args);
        });
        this.domContentLoadedHandler = () => {
            this.onDOMContentLoaded();
        };
        document.addEventListener('DOMContentLoaded', this.domContentLoadedHandler);
    }
    isInIframe() {
        try {
            return window.self !== window.top;
        }
        catch (e) {
            return true;
        }
    }
    onDOMContentLoaded() {
        this.iframe = document.getElementById('extension-tab-frame');
        this.iframeContentOrigin = '';
        this.windowOrigin = window.location.origin;
        // for back compatibility
        if (!this.iframe) {
            const iframeElements = document.getElementsByClassName('extension-tab-frame');
            this.iframe = iframeElements && iframeElements[0];
        }
        if (!this.validateUrl(this.windowOrigin)) {
            this.sendToWebview({ func: 'error', args: { errorName: 'invalidOriginUrl' } }, this.windowOrigin);
            return;
        }
        if (!this.iframe) {
            this.sendToWebview({ func: 'error', args: { errorName: 'noIframeElement' } }, this.windowOrigin);
            return;
        }
        // the hash string is in the form of a query string (#a=b&c=d)
        const hashString = window.location.hash.substring(1);
        const pairs = hashString.split('&');
        const params = {};
        pairs.forEach((pair) => {
            const tokens = pair.split('=');
            if (tokens.length >= 2) {
                params[tokens[0]] = decodeURIComponent(tokens[1]);
            }
        });
        const urlString = params['iframeurl'];
        this.skipDomainValidation = params['skipDomainValidation'];
        if (urlString !== 'about:blank') {
            if (!this.validateUrl(urlString)) {
                this.sendToWebview({ func: 'error', args: { errorName: 'invalidUrl' } }, this.windowOrigin);
                return;
            }
        }
        if (!this.setFrameOriginFromUrl(urlString)) {
            return;
        }
        this.iframe.setAttribute('src', urlString);
        this.iframe.onload = () => {
            this.sendToWebview({ func: 'iframeLoaded' }, this.iframeContentOrigin);
        };
        const messageHandler = (event) => {
            this.onMessageEvent(event);
        };
        window.addEventListener('message', messageHandler);
        window.onunload = () => {
            window.removeEventListener('message', messageHandler);
            document.removeEventListener('DOMContentLoaded', this.domContentLoadedHandler);
        };
    }
    sendToIframe(message) {
        if (message && message.func === 'unloadFrame' && this.iframe) {
            this.iframe.setAttribute('src', 'about:blank');
            return;
        }
        if (this.iframe && this.iframe.contentWindow && !this.iframe.contentWindow.closed) {
            if (this.skipDomainValidation && message.origin && message.origin !== this.iframeContentOrigin) {
                this.iframeContentOrigin = message.origin;
            }
            if (message.origin) {
                delete message.origin;
            }
            this.iframe.contentWindow.postMessage(message.stringMessage || message, this.iframeContentOrigin);
        }
        else {
            this.sendToWebview({ func: 'error', args: { errorName: 'sendMessageToIframe' } }, this.windowOrigin);
        }
    }
    sendToWebview(message, origin) {
        electron_1.ipcRenderer.sendToHost('webview-to-main-renderer-postmessage', origin, message);
    }
    onMessageEvent(event) {
        const sourceWindow = event.source;
        const eventOrigin = event.origin;
        // send the message to the parent, videoApp message handler
        if (this.videoAppHandler.eventFilter(event)) {
            return;
        }
        if (this.iframeContentOrigin === eventOrigin && sourceWindow === this.iframe.contentWindow) {
            this.sendToWebview(event.data, eventOrigin);
        }
        else if (eventOrigin === this.windowOrigin && sourceWindow === window) {
            this.sendToWebview(event.data, eventOrigin);
        }
        else if (this.skipDomainValidation && this.iframeContentOrigin !== eventOrigin) {
            this.sendToWebview(event.data, eventOrigin);
        }
        else {
            this.sendToWebview({ func: 'error', args: { errorName: 'invalidEventSource', errorInfo: eventOrigin } }, this.windowOrigin);
        }
    }
    validateUrl(url) {
        const urlParser = document.createElement('a');
        urlParser.href = url;
        const protocol = urlParser.protocol;
        return !!process || protocol === 'https:';
    }
    setFrameOriginFromUrl(url) {
        // if the iframe src is about:blank, use the window origin (iframe-container origin)
        if (url === 'about:blank') {
            this.iframeContentOrigin = this.windowOrigin;
            return true;
        }
        try {
            const urlParser = document.createElement('a');
            urlParser.href = url;
            this.iframeContentOrigin = 'https://' + urlParser.hostname;
            return true;
        }
        catch (e) {
            this.sendToWebview({ func: 'error', args: { errorName: 'getOrigin', errorInfo: JSON.stringify(e && e.message) } }, this.windowOrigin);
            return false;
        }
    }
    onPostFormEvent(event, args) {
        if (args && args['url']) {
            const url = args['url'];
            if (!this.iframe) {
                this.sendToWebview({ func: 'error', args: { errorName: 'noIframeElement' } }, this.windowOrigin);
                return;
            }
            if (!this.validateUrl(url)) {
                this.sendToWebview({ func: 'error', args: { errorName: 'invalidOriginUrl' } }, this.windowOrigin);
                return;
            }
            if (!this.setFrameOriginFromUrl(url)) {
                return;
            }
            this.postFormToIframe(args['url'], args['params'] || {});
        }
    }
    postFormToIframe(url, params) {
        if (!this.iframe) {
            this.sendToWebview({ func: 'error', args: { errorName: 'noIframeElement' } }, this.windowOrigin);
            return;
        }
        const body = document.body;
        if (!body) {
            this.sendToWebview({ func: 'error', args: { errorName: 'noBodyElement' } }, this.windowOrigin);
            return;
        }
        const webviewForm = document.createElement('form');
        webviewForm.setAttribute('target', this.iframe.name);
        webviewForm.setAttribute('method', 'POST');
        webviewForm.setAttribute('hidden', '');
        webviewForm.setAttribute('action', url);
        webviewForm.setAttribute('accept-charset', 'UTF-8');
        if (params) {
            Object.keys(params).forEach((key) => {
                const input = document.createElement('input');
                input.type = 'text';
                input.name = key;
                input.value = JSON.stringify(params[key]);
                webviewForm.appendChild(input);
            });
        }
        body.appendChild(webviewForm);
        webviewForm.submit();
        body.removeChild(webviewForm);
    }
}
// instantiate a preload instance
(() => new WebviewShim())();

},{"./video-app-handler":2,"electron":undefined}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
var VideoFormatEnum;
(function (VideoFormatEnum) {
    VideoFormatEnum["nv12"] = "NV12";
    VideoFormatEnum["rgb"] = "RGB";
})(VideoFormatEnum || (VideoFormatEnum = {}));
var EvaluationType;
(function (EvaluationType) {
    EvaluationType["speedReal"] = "speed_real";
    EvaluationType["speedFull"] = "speed_full";
    EvaluationType["memoryReal"] = "memory_real";
    EvaluationType["memoryFull"] = "memory_full";
})(EvaluationType || (EvaluationType = {}));
var VideoEvents;
(function (VideoEvents) {
    VideoEvents["sendMessagePortToMainWindow"] = "video.sendMessagePortToMainWindow";
    VideoEvents["enableVideoExtensibility"] = "video.enableVideoExtensibility";
    VideoEvents["videoEffectParameterChanged"] = "video.effectParameterChange";
    VideoEvents["videoEffectChanged"] = "video.videoEffectChanged";
    VideoEvents["newVideoFrame"] = "video.newVideoFrame";
    VideoEvents["previewStatusChanged"] = "video.previewStatusChanged";
    // add resolution change and img format change
    VideoEvents["videoResolutionParameterChanged"] = "video.resolutionParameterChange";
    VideoEvents["videoFormatParameterChanged"] = "video.formatParameterChange";
    VideoEvents["clearEffect"] = "video.clearEffect";
})(VideoEvents || (VideoEvents = {}));
var VideoAppEvents;
(function (VideoAppEvents) {
    VideoAppEvents["videoFrameProcessed"] = "video.videoFrameProcessed";
    VideoAppEvents["registerForVideoFrame"] = "video.registerForVideoFrame";
    VideoAppEvents["notifyError"] = "video.notifyError";
})(VideoAppEvents || (VideoAppEvents = {}));
var EventsFromHostWebView;
(function (EventsFromHostWebView) {
    EventsFromHostWebView["inPreview"] = "video.inPreview";
    EventsFromHostWebView["applyClicked"] = "video.applyClicked";
    EventsFromHostWebView["videoOn"] = "video.videoOn";
})(EventsFromHostWebView || (EventsFromHostWebView = {}));
var EventsFromSlimcore;
(function (EventsFromSlimcore) {
    EventsFromSlimcore["ipcChangedEvent"] = "video.videoExtensibilityIpcChangedEvent";
    EventsFromSlimcore["performanceErrorEvent"] = "video.videoExtensibilityPerfErrorEvent";
    EventsFromSlimcore["performanceAlertEvent"] = "video.videoExtensibilityPerfAlertEvent";
    EventsFromSlimcore["messageChannelEstablished"] = "video.messageChannelEstablished";
    EventsFromSlimcore["videoEffectDisabled"] = "video.videoEffectDisabled";
})(EventsFromSlimcore || (EventsFromSlimcore = {}));
var EffectChangeType;
(function (EffectChangeType) {
    EffectChangeType["effectChanged"] = "EffectChanged";
    EffectChangeType["effectDisabled"] = "EffectDisabled";
})(EffectChangeType || (EffectChangeType = {}));
var EvaluationEvents;
(function (EvaluationEvents) {
    EvaluationEvents["evaluationStart"] = "video.evaluationStart";
    EvaluationEvents["evaluationEnd"] = "video.evaluationEnd";
})(EvaluationEvents || (EvaluationEvents = {}));
function round(num) {
    return Math.round(num * 100) / 100;
}
class VideoAppHandler {
    constructor(sendToVideoApp) {
        this.inPreviewStage = true;
        this.enabled = true;
        this.videoAppLoaded = false;
        this.videoEffectModified = false;
        this.messageChannelEstablished = false;
        // Flag to indicate the video extensiblity enable/disable status modified in-meeting
        this.videoAppToBeEnabled = false;
        // eval param
        this.smoother = 1 * 1000; // 1 second
        this.isEvaluating = false;
        this.oneTime = 0;
        this.speedRaw = [];
        this.memoryTotalRaw = [];
        this.memoryActiveRaw = [];
        this.sendToVideoApp = sendToVideoApp;
    }
    eventFilter(event) {
        if (!event || !event.data || !event.data.func ||
            typeof event.data.func !== 'string' ||
            !event.data.func.startsWith('video.')) {
            if (event.data.func === 'initialize') {
                const response = event.data;
                this.sendToVideoApp({
                    id: response.id,
                    func: 'initialize',
                    args: ['sidePanel'],
                });
            }
            return false;
        }
        const type = event.data.func;
        if (type !== VideoAppEvents.videoFrameProcessed) {
            console.log(`eventFilter - func: ${event.data.func}, args:`, event.data.args);
        }
        let messageProcessed = true;
        switch (type) {
            case VideoAppEvents.registerForVideoFrame:
                this.videoAppConfig = event.data.args[0];
                if (typeof this.videoAppConfig.format === 'number') {
                    this.videoAppConfig.format = VideoFormatEnum[this.videoAppConfig.format];
                }
                this.initilizeVideoApp();
                // TMP will hook this message, so need return to false
                messageProcessed = false;
                break;
            case VideoAppEvents.videoFrameProcessed:
                this.notifyFrameProcessed();
                break;
            case EventsFromHostWebView.inPreview:
                this.inPreviewStage = true;
                this.videoEffectModified = false;
                this.notifyVideoAppEffectChanged();
                this.sendToVideoApp({
                    func: VideoEvents.previewStatusChanged,
                    args: [true],
                });
                break;
            case EventsFromHostWebView.videoOn:
                this.inPreviewStage = false;
                this.sendToVideoApp({
                    func: VideoEvents.previewStatusChanged,
                    args: [false],
                });
                break;
            case EventsFromHostWebView.applyClicked:
                this.onApplyClicked();
                break;
            case VideoEvents.videoEffectChanged:
                this.onEffectChanged(event);
                break;
            case VideoEvents.videoResolutionParameterChanged:
                this.targetFactor = event.data.args[0];
                break;
            case VideoEvents.videoFormatParameterChanged:
                this.targetFormat = event.data.args[0];
                break;
            case VideoEvents.clearEffect:
                const clearEffectEvent = {
                    data: {
                        args: [EffectChangeType.effectDisabled],
                    },
                };
                this.onEffectChanged(clearEffectEvent);
                break;
            // evaluation events handlers
            case EvaluationEvents.evaluationStart:
                this.evalType = event.data.args[0];
                this.totalTime = performance.now();
                // wait a moment so that `this.oneTime` will not be 0
                setTimeout(() => this.isEvaluating = true, 100);
                break;
            case EvaluationEvents.evaluationEnd:
                this.isEvaluating = false;
                this.evalType = null;
                break;
            default:
                messageProcessed = false;
        }
        return messageProcessed;
    }
    onApplyClicked() {
        if (this.inPreviewStage) {
            return;
        }
        if (this.videoAppLoaded && this.videoEffectModified) {
            if (this.videoAppToBeEnabled) {
                this.enableVideoExtensibility();
            }
            else {
                this.disableVideoExtensibility();
            }
        }
        this.notifyVideoAppEffectChanged();
        this.videoEffectModified = false;
    }
    onEffectChanged(event) {
        let changeType = event.data.args[0];
        if (typeof changeType === 'number') {
            changeType = EffectChangeType[changeType];
        }
        this.selectedEffectId = event.data.args.length === 2 ? event.data.args[1] : undefined;
        // If in preview stage, apply the change immediately
        if (this.inPreviewStage) {
            this.effectChangedInPreview(changeType);
        }
        else {
            this.effectChangedInMeeting(changeType, event);
        }
    }
    effectChangedInPreview(changeType) {
        if (changeType === EffectChangeType.effectDisabled) {
            this.disableVideoExtensibility();
        }
        else if (changeType === EffectChangeType.effectChanged) {
            this.enableVideoExtensibility();
        }
        this.notifyVideoAppEffectChanged();
    }
    // When in-meeting, the change will be cached and apply when Apply clicked.
    effectChangedInMeeting(changeType, event) {
        if (changeType === EffectChangeType.effectDisabled) {
            const forceToDisable = event.data.args.length === 2 ? event.data.args[1] : undefined;
            if (forceToDisable === 'force') {
                this.disableVideoExtensibility();
            }
            else {
                this.videoEffectModified = true;
                this.videoAppToBeEnabled = false;
            }
        }
        else if (changeType === EffectChangeType.effectChanged && this.videoAppLoaded) {
            if (!this.enabled) {
                this.videoEffectModified = true;
                this.videoAppToBeEnabled = true;
            }
            else if (this.videoEffectModified) {
                this.videoEffectModified = false;
            }
        }
    }
    notifyVideoAppEffectChanged() {
        this.sendToVideoApp({
            func: VideoEvents.videoEffectParameterChanged,
            args: [this.selectedEffectId],
        });
    }
    NV122RGBA(img, width, height, stride) {
        const newWidth = width;
        const newHeight = height;
        // convert to RGB
        const dummyRes = new Uint8ClampedArray(newHeight * newWidth * 4);
        const videoFrame = dummyRes.map((value, idx) => {
            // if A
            if ((idx % (newWidth * 4)) % 4 === 3) {
                return 255;
            }
            // if RGB
            else {
                const I = Math.floor(idx / (newWidth * 4));
                const J = Math.floor((idx % (newWidth * 4)) / 4);
                // const idxR = J - J%4;
                const idxY = I * stride + J;
                const Y = img[idxY];
                const originI = height + Math.floor(I / 2);
                const originJ = J - (J % 2);
                const originIdxU = originI * stride + originJ;
                const U = img[originIdxU];
                const V = img[originIdxU + 1];
                // if R:
                if ((idx % (newWidth * 4)) % 4 === 0) {
                    return Y - 16 + 1.402 * (V - 128);
                }
                // if G
                else if ((idx % (newWidth * 4)) % 4 === 1) {
                    return (Y -
                        16 -
                        ((0.299 * 1.402) / 0.587) * (V - 128) -
                        ((0.114 * 1.772) / 0.587) * (U - 128));
                }
                // if B
                else {
                    return Y - 16 + 1.772 * (U - 128);
                }
            }
        });
        return {
            videoFrame,
            width: newWidth,
            height: newHeight,
        };
    }
    RGBA2NV12(img, width, height, stride) {
        const newWidth = Math.floor(width / 2) * 2;
        const newHeight = Math.floor(height / 2) * 2;
        let newPadding = 0;
        if (newWidth % 8 !== 0) {
            newPadding = 8 - (newWidth % 8);
        }
        const newStride = newWidth + newPadding;
        const nv12 = new Uint8ClampedArray(((newWidth * newStride) / 2) * 3);
        const videoFrame = nv12.map((value, idx, array) => {
            // if padding, fill in zero
            if (idx % newStride >= newWidth) {
                return 0;
            }
            // if in Y, calculte Y from RGB
            else if (Math.floor(idx / newStride) < newHeight) {
                const originJ = idx % newStride;
                const originI = Math.floor(idx / newStride);
                const originidx = originI * stride + originJ;
                const R = img[originidx * 4];
                const G = img[originidx * 4 + 1];
                const B = img[originidx * 4 + 2];
                const A = img[originidx * 4 + 3];
                return (0.299 * (((225 - A) / 225) * R + (A / 225) * R) +
                    0.587 * (((225 - A) / 225) * G + (A / 225) * G) +
                    0.114 * (((225 - A) / 225) * B + (A / 225) * B) +
                    16);
            }
            // if in UV
            else {
                const newI = Math.floor(idx / newStride);
                const newJ = idx % newStride;
                const originI = (newI - newHeight) * 2;
                const originJ = newJ - (newJ % 2);
                const originIdxR = originI * stride + originJ;
                const R = img[originIdxR * 4];
                const G = img[originIdxR * 4 + 1];
                const B = img[originIdxR * 4 + 2];
                const A = img[originIdxR * 4 + 3];
                const yp = 0.299 * (((225 - A) / 225) * R + (A / 225) * R) +
                    0.587 * (((225 - A) / 225) * G + (A / 225) * G) +
                    0.114 * (((225 - A) / 225) * B + (A / 225) * B);
                // if it is U
                if (newJ % 2 === 0) {
                    return (B - yp) / 1.772 + 128;
                }
                // if it is V
                else {
                    return (R - yp) / 1.402 + 128;
                }
            }
        });
        return {
            videoFrame,
            width: newWidth,
            height: newHeight,
            stride: newStride,
        };
    }
    resizeNV12(img, width, height, stride, factor) {
        // identity case
        if (factor === 1) {
            const resized = new Uint8ClampedArray(img.byteLength);
            resized.set(img);
            return { videoFrame: resized, width, height, stride };
        }
        // initialize variables
        const newHeight = Math.floor((height * factor) / 2) * 2;
        const newWidth = Math.floor((width * factor) / 2) * 2;
        let padding;
        if (newWidth % 8 === 0) {
            padding = 0;
        }
        else {
            padding = 8 - (newWidth % 8);
        }
        const newStide = newWidth + padding;
        const resized = new Uint8ClampedArray((newHeight / 2) * 3 * newStide);
        let originI;
        let originJ;
        // make it larger, loop the result array
        if (factor > 1) {
            // add Y values
            for (let i = 0; i < newHeight; i += 1) {
                for (let j = 0; j < newStide; j += 1) {
                    const idx = i * newStide + j;
                    // padding
                    if (j >= newWidth) {
                        resized[idx] = 0;
                    }
                    else {
                        // add y
                        originI = Math.floor(i / factor);
                        originJ = Math.floor(j / factor);
                        resized[idx] = img[originI * stride + originJ];
                    }
                }
            }
            // add UV values
            for (let i = newHeight; i < (newHeight / 2) * 3; i += 1) {
                for (let j = 0; j < newStide; j += 1) {
                    const idx = i * newStide + j;
                    if (j >= newWidth) {
                        resized[idx] = 0;
                    }
                    else {
                        originI = Math.floor(i / factor);
                        originJ = Math.floor(j / (2 * factor)) * 2 + (j % 2);
                        resized[idx] = img[originI * stride + originJ];
                    }
                }
            }
        }
        // make it smaller
        else {
            // add Y values
            for (let i = 0; i < newHeight; i += 1) {
                for (let j = 0; j < newStide; j += 1) {
                    const idx = i * newStide + j;
                    // padding
                    if (j >= newWidth) {
                        resized[idx] = 0;
                    }
                    // y values
                    else {
                        originI = i / factor;
                        originJ = j / factor;
                        resized[idx] = img[originI * stride + originJ];
                    }
                }
            }
            // add U and V values
            for (let i = newHeight; i < (newHeight / 2) * 3; i += 1) {
                for (let j = 0; j < newStide; j += 1) {
                    const idx = i * newStide + j;
                    // padding
                    if (j >= newWidth) {
                        resized[idx] = 0;
                    }
                    else {
                        // uv values
                        originI = Math.floor(i / factor);
                        originJ = (j - (j % 2)) / factor + (j % 2);
                        resized[idx] = img[originI * stride + originJ];
                    }
                }
            }
        }
        return {
            videoFrame: resized,
            width: newWidth,
            height: newHeight,
            stride: newStide,
        };
    }
    convert(videoFrame) {
        if (this.targetFormat === 'NV12') {
            const resized = this.resizeNV12(this.originVideoFrame, this.originWidth, this.originHeight, this.originStride, this.targetFactor);
            if (this.changedVideoFrame.byteLength !== resized.videoFrame.byteLength) {
                this.changedVideoFrame = new Uint8ClampedArray(new SharedArrayBuffer(resized.videoFrame.byteLength));
            }
            this.changedVideoFrame.set(resized.videoFrame);
            this.newWidth = resized.width;
            this.newHeight = resized.height;
            this.newStride = resized.stride;
            videoFrame['width'] = this.newWidth;
            videoFrame['height'] = this.newHeight;
            videoFrame['lumaStride'] = this.newStride;
            videoFrame['chromaStride'] = this.newStride;
        }
        else if (this.targetFormat === 'RGBA') {
            // first resize, then convert the changed video frame to RGB
            const resized = this.resizeNV12(this.originVideoFrame, this.originWidth, this.originHeight, this.originStride, this.targetFactor);
            const rgbaImg = this.NV122RGBA(resized.videoFrame, resized.width, resized.height, resized.stride);
            if (this.changedVideoFrame.byteLength !== rgbaImg[0].byteLength) {
                this.changedVideoFrame = new Uint8ClampedArray(new SharedArrayBuffer(rgbaImg[0].byteLength));
            }
            this.changedVideoFrame.set(rgbaImg.videoFrame);
            this.newWidth = rgbaImg.width;
            this.newHeight = rgbaImg.height;
            videoFrame['width'] = this.newWidth;
            videoFrame['height'] = this.newWidth;
            videoFrame['stride'] = this.newStride;
        }
        else {
            this.changedVideoFrame.set(this.originVideoFrame);
        }
    }
    revertBack() {
        // change data
        if (this.targetFormat === 'NV12') {
            // no need to resize
            const resized = this.resizeNV12(this.changedVideoFrame, this.newWidth, this.newHeight, this.newStride, 1 / this.targetFactor);
            if (this.originVideoFrame.byteLength !== resized.videoFrame.byteLength) {
                this.originVideoFrame = new Uint8ClampedArray(new SharedArrayBuffer(resized.videoFrame.byteLength));
            }
            this.originVideoFrame.set(resized.videoFrame);
        }
        else if (this.targetFormat === 'RGBA') {
            // rgba to nv12
            const nv12Img = this.RGBA2NV12(this.changedVideoFrame, this.newWidth, this.newHeight, this.newStride);
            // nv12 resize
            const resized = this.resizeNV12(nv12Img[0], nv12Img[1], nv12Img[2], nv12Img[3], 1 / this.targetFactor);
            if (this.originVideoFrame.byteLength !== resized.videoFrame.byteLength) {
                this.originVideoFrame = new Uint8ClampedArray(new SharedArrayBuffer(resized.videoFrame.byteLength));
            }
            this.originVideoFrame.set(resized.videoFrame);
        }
        else {
            this.originVideoFrame.set(this.changedVideoFrame);
        }
    }
    notifyFrameProcessed() {
        if (this.arrayBufferInProcessing !== undefined) {
            if (this.isEvaluating) {
                // record time used
                if (this.evalType === EvaluationType.speedFull || this.evalType === EvaluationType.speedReal) {
                    // record speed data, send if we have enough
                    this.speedRaw.push(round(performance.now() - this.oneTime));
                    if (performance.now() - this.totalTime > this.smoother) {
                        this.totalTime = performance.now();
                        electron_1.ipcRenderer.sendToHost('send-performance', this.speedRaw);
                        this.speedRaw = [];
                    }
                }
                else if (this.evalType === EvaluationType.memoryFull || this.evalType === EvaluationType.memoryReal) {
                    // @ts-ignore:next-line
                    const memory = performance.memory;
                    if (!memory)
                        throw new Error('`performance.memory` is not supported.');
                    // record memory data, send if we have enough
                    this.memoryActiveRaw.push(round(memory.usedJSHeapSize));
                    this.memoryTotalRaw.push(round(memory.totalJSHeapSize));
                    if (performance.now() - this.totalTime > this.smoother) {
                        this.totalTime = performance.now();
                        electron_1.ipcRenderer.sendToHost('send-performance', this.memoryActiveRaw, this.memoryTotalRaw);
                        this.memoryActiveRaw = [];
                        this.memoryTotalRaw = [];
                    }
                }
            }
            this.revertBack();
            this.videoExtensibility.setVideoFrameProcessed();
            this.arrayBufferInProcessing = undefined;
        }
    }
    enableVideoExtensibility() {
        if (!this.messageChannelEstablished) {
            this.enabled = true;
            return;
        }
        if (this.enabled || this.arrayBufferInProcessing) {
            return;
        }
        this.videoAppMessagePort.postMessage({ type: VideoEvents.enableVideoExtensibility, enable: true, config: this.videoAppConfig });
        this.enabled = true;
    }
    disableVideoExtensibility() {
        if (!this.enabled || !this.messageChannelEstablished) {
            this.enabled = false;
            return;
        }
        this.videoAppMessagePort.postMessage({ type: VideoEvents.enableVideoExtensibility, enable: false, config: this.videoAppConfig });
        this.enabled = false;
    }
    initilizeVideoApp() {
        const messageChanel = new MessageChannel();
        this.videoAppMessagePort = messageChanel.port1;
        this.videoAppMessagePort.onmessage = this.slimcoreMessageHandler.bind(this);
        electron_1.ipcRenderer.postMessage(VideoEvents.sendMessagePortToMainWindow, null, [messageChanel.port2]);
        this.videoAppLoaded = true;
    }
    sendFrameBufferToWebview(frameBuffer) {
        this.arrayBufferInProcessing = frameBuffer;
        const frameMetaRaw = new Uint32Array(frameBuffer);
        const version = frameMetaRaw[0];
        const videoFrame = {};
        // FrameBuffer memory layout details in version 1.
        // Index   Name                         Size          Description
        // 0:      version                      4 bytes
        // 1:      frameProcessedFlag           4 bytes       Internally used in C++.
        // 2:      format                       4 bytes
        // 3:      video frame width            4 bytes
        // 4:      vide frame height            4 bytes
        // 5       offsetToRawFrame             4 bytes       Video frame buffer offset
        // 6:      video FrameByteLength        4 bytes
        // if(format == 'NV12')
        // 7:      lumaStride                   4 bytes
        // 8:      chromaStride                 4 bytes
        // else if(format == 'RGB')
        // 7:      stride                       4 bytes
        // ...     video frame buffer
        const format = { 1: 'NV12', 2: 'RGB' }[frameMetaRaw[2]];
        if (format === undefined) {
            throw new Error(`Shared memory layout error: format#${frameMetaRaw[2]} is not supported`);
        }
        videoFrame['width'] = frameMetaRaw[3];
        videoFrame['height'] = frameMetaRaw[4];
        const offsetToRawFrame = frameMetaRaw[5];
        const rawFrameByteLength = frameMetaRaw[6];
        if (format === 'NV12') {
            videoFrame['lumaStride'] = frameMetaRaw[7];
            videoFrame['chromaStride'] = frameMetaRaw[8];
            this.originStride = videoFrame['lumaStride'];
        }
        else if (format === 'RGB') {
            videoFrame['stride'] = frameMetaRaw[7];
            this.originStride = videoFrame['stride'];
        }
        videoFrame['data'] = new Uint8ClampedArray(frameBuffer, offsetToRawFrame, rawFrameByteLength);
        if (version > 1) {
            console.warn(`FrameBuffer memory layout in version ${version} may not be fully supported`);
        }
        this.originWidth = videoFrame['width'];
        this.originHeight = videoFrame['height'];
        this.originVideoFrame = videoFrame['data'];
        if (!this.changedVideoFrame ||
            this.changedVideoFrame.byteLength !== this.originVideoFrame.byteLength) {
            this.changedVideoFrame = new Uint8ClampedArray(new SharedArrayBuffer(this.originVideoFrame.byteLength));
        }
        this.convert(videoFrame);
        videoFrame['data'] = this.changedVideoFrame;
        // start timing
        if (this.evalType === EvaluationType.speedReal || this.evalType === EvaluationType.speedFull) {
            this.oneTime = performance.now();
        }
        this.sendToVideoApp({
            func: VideoEvents.newVideoFrame,
            args: [videoFrame],
        });
        return true;
    }
    slimcoreMessageHandler(messageEvent) {
        const msgType = messageEvent.data.type;
        console.log(msgType);
        // begin save factor and format
        const hashString = window.location.hash.substring(1);
        const pairs = hashString.split('&');
        pairs.forEach((pair) => {
            const tokens = pair.split('=');
            if (tokens.length >= 2) {
                if (tokens[0] === 'resolution') {
                    this.targetFactor = Number(tokens[1]);
                }
                if (tokens[0] === 'format') {
                    this.targetFormat = tokens[1];
                }
            }
        });
        if (msgType === EventsFromSlimcore.ipcChangedEvent) {
            const vxOptions = {
                frameProcessedEventName: messageEvent.data.frameProcessedEventName,
                frameReadyEventName: messageEvent.data.frameReadyEventName,
                sharedMemoryName: messageEvent.data.sharedMemoryName,
            };
            if (this.videoExtensibility !== undefined) {
                this.videoExtensibility.stop();
            }
            // pass the share memory name, frameReadyEvent and frameProcessedEvent name to Electron
            this.videoExtensibility = new electron_1.VideoExtensibility(vxOptions);
            this.videoExtensibility.registerForVideoFrame(this.sendFrameBufferToWebview.bind(this));
            if (!this.videoExtensibility.start()) {
                console.log('videoExtensibility start failed');
            }
            else {
                console.log('videoExtensibility start successfully');
            }
        }
        else if (this.videoAppMessagePort !== null &&
            msgType === EventsFromSlimcore.messageChannelEstablished) {
            this.messageChannelEstablished = true;
            // When message change is established, send the message to enable the video effect
            this.videoAppMessagePort.postMessage({
                type: VideoEvents.enableVideoExtensibility,
                enable: true,
                config: this.videoAppConfig,
            });
        }
    }
}
exports.VideoAppHandler = VideoAppHandler;

},{"electron":undefined}]},{},[1]);

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const utils_1 = require("../utils");
const calling_1 = require("../calling");
const Highcharts = require("highcharts");
const highcharts_more_1 = require("highcharts/highcharts-more");
highcharts_more_1.default(Highcharts);
const options = utils_1.invokeSync('get-options');
const electronVersion = {
    version: process.versions.electron,
    build: process.versions['microsoft-build'],
};
function initPluginHost() {
    const pluginHostId = utils_1.invokeSync('init-plugin-host');
    return {
        id: pluginHostId,
        contextId: process.contextId,
        send(channel, args) {
            return electron_1.ipcRenderer.sendToRenderer(pluginHostId, channel, args);
        },
        sendSync(channel, args, watchdogApi) {
            return electron_1.ipcRenderer.sendToRendererSync(pluginHostId, channel, args, watchdogApi);
        },
        connect() {
            return electron_1.ipcRenderer.connectToRenderer(pluginHostId);
        },
        on(channel, listener) {
            electron_1.ipcRenderer.on(channel, (event, ...args) => {
                if (event.senderId === pluginHostId) {
                    listener(event, ...args);
                }
            });
        },
    };
}
function exposeGlobal(name, value) {
    if (process.contextIsolated) {
        electron_1.contextBridge.exposeInMainWorld(name, value);
    }
    else {
        global[name] = value;
    }
}
function createChart(renderTo, options) {
    return new Highcharts.Chart(renderTo, options, null);
}
function exposeModules() {
    exposeGlobal('electronVersion', electronVersion);
    exposeGlobal('options', options);
    exposeGlobal('electronIpc', electron_1.ipcRenderer);
    exposeGlobal('createFrameSinkReader', utils_1.createFrameSinkReader);
    exposeGlobal('hcChart', {
        createChart,
        setOptions: Highcharts.setOptions,
        getOptions: Highcharts.getOptions,
    });
    process.once('loaded', () => { window['Buffer'] = Buffer; });
    calling_1.exposeSlimCore(Object.assign({}, options, { initPluginHost }));
}
if (location.origin === 'file://') {
    exposeModules();
}
// index.js: Object.defineProperty(exports, "__esModule", { value: true });
electron_1.webFrame.executeJavaScript(`var exports = {};`);
console.log('pid', process.pid);
console.log('sandbox', !!process.sandboxed);
console.log('contextIsolation', process.contextIsolated);
console.log('electron.version', process.versions.electron);
console.log('electron.build', process.versions['microsoft-build']);
electron_1.ipcRenderer.on('video.sendMessagePortToMainWindow', (event) => {
    window.postMessage('video.sendMessagePortToMainWorld', window.origin, [event.ports[0]]);
});
//# sourceMappingURL=preload.js.map
import { ipcRenderer, MessageEvent, VideoExtensibility } from 'electron';

type RGBImage = {
    videoFrame: Uint8ClampedArray;
    width: number;
    height: number;
};
type NV12Image = {
    videoFrame: Uint8ClampedArray;
    width: number;
    height: number;
    stride: number;
};

enum VideoFormatEnum {
  nv12 = 'NV12',
  rgb = 'RGB',
}

enum EvaluationType {
    speedReal = 'speed_real',
    speedFull = 'speed_full',
    memoryReal = 'memory_real',
    memoryFull = 'memory_full',
}

enum VideoEvents {
    sendMessagePortToMainWindow = 'video.sendMessagePortToMainWindow',
    enableVideoExtensibility = 'video.enableVideoExtensibility',
    videoEffectParameterChanged = 'video.effectParameterChange',
    videoEffectChanged = 'video.videoEffectChanged',
    newVideoFrame = 'video.newVideoFrame',
    previewStatusChanged = 'video.previewStatusChanged',
    // add resolution change and img format change
    videoResolutionParameterChanged = 'video.resolutionParameterChange',
    videoFormatParameterChanged = 'video.formatParameterChange',
    clearEffect = 'video.clearEffect',
}

enum VideoAppEvents {
    videoFrameProcessed = 'video.videoFrameProcessed',
    registerForVideoFrame = 'video.registerForVideoFrame',
    notifyError = 'video.notifyError',
}

enum EventsFromHostWebView {
    inPreview = 'video.inPreview',
    applyClicked = 'video.applyClicked',
    videoOn = 'video.videoOn',
}

enum EventsFromSlimcore {
    ipcChangedEvent = 'video.videoExtensibilityIpcChangedEvent',
    performanceErrorEvent = 'video.videoExtensibilityPerfErrorEvent',
    performanceAlertEvent = 'video.videoExtensibilityPerfAlertEvent',
    messageChannelEstablished = 'video.messageChannelEstablished',
    videoEffectDisabled = 'video.videoEffectDisabled',
}

enum EffectChangeType {
    effectChanged = 'EffectChanged',
    effectDisabled = 'EffectDisabled',
}

enum EvaluationEvents {
    evaluationStart = 'video.evaluationStart',
    evaluationEnd = 'video.evaluationEnd',
}

function round(num: number) {
    return Math.round(num * 100) / 100;
}

export class VideoAppHandler {
    private videoExtensibility: VideoExtensibility;
    private videoAppConfig: any;
    private selectedEffectId: string;
    private arrayBufferInProcessing: SharedArrayBuffer;
    private videoAppMessagePort: MessagePort;

    private inPreviewStage = true;
    private enabled = true;
    private sendToVideoApp: (message: any) => void;

    private videoAppLoaded = false;
    private videoEffectModified = false;
    private messageChannelEstablished = false;
    // Flag to indicate the video extensiblity enable/disable status modified in-meeting
    private videoAppToBeEnabled = false;

    private originVideoFrame: Uint8ClampedArray;
    private changedVideoFrame: Uint8ClampedArray;
    // factor defines the resize factor for resolution and format defines the image format
    private targetFactor: number;
    private targetFormat: string;
    // record parameter
    private originWidth: number;
    private originHeight: number;
    private originStride: number;

    private newWidth: number;
    private newHeight: number;
    private newStride: number;
    // eval param
    private smoother = 1 * 1000; // 1 second
    private totalTime: number;
    private isEvaluating = false;
    private oneTime = 0;
    private evalType: EvaluationType;

    private speedRaw: any[] = [];
    private memoryTotalRaw: any[] = [];
    private memoryActiveRaw: any[] = [];

    public constructor(sendToVideoApp: (message: any) => void) {
        this.sendToVideoApp = sendToVideoApp;
    }

    public eventFilter(event: MessageEvent) {
        if (
            !event || !event.data || !event.data.func ||
            typeof event.data.func !== 'string' ||
            !event.data.func.startsWith('video.')
        ) {
            if (event.data.func === 'initialize') {
                const response = event.data;
                this.sendToVideoApp({
                    id: response.id,
                    func: 'initialize',
                    args: ['sidePanel'],
                });
            }
            return false;
        }

        const type = event.data.func;
        if (type !== VideoAppEvents.videoFrameProcessed) {
            console.log(`eventFilter - func: ${event.data.func}, args:`, event.data.args);
        }
        let messageProcessed = true;
        switch (type) {
            case VideoAppEvents.registerForVideoFrame:
                this.videoAppConfig = event.data.args[0];
                if ( typeof this.videoAppConfig.format === 'number') {
                  this.videoAppConfig.format = VideoFormatEnum[this.videoAppConfig.format];
                }
                this.initilizeVideoApp();
                // TMP will hook this message, so need return to false
                messageProcessed = false;
                break;
            case VideoAppEvents.videoFrameProcessed:
                this.notifyFrameProcessed();
                break;
            case EventsFromHostWebView.inPreview:
                this.inPreviewStage = true;
                this.videoEffectModified = false;
                this.notifyVideoAppEffectChanged();
                this.sendToVideoApp({
                    func: VideoEvents.previewStatusChanged,
                    args: [true],
                });
                break;
            case EventsFromHostWebView.videoOn:
                this.inPreviewStage = false;
                this.sendToVideoApp({
                    func: VideoEvents.previewStatusChanged,
                    args: [false],
                });
                break;
            case EventsFromHostWebView.applyClicked:
                this.onApplyClicked();
                break;
            case VideoEvents.videoEffectChanged:
                this.onEffectChanged(event);
                break;
            case VideoEvents.videoResolutionParameterChanged:
                this.targetFactor = event.data.args[0];
                break;
            case VideoEvents.videoFormatParameterChanged:
                this.targetFormat = event.data.args[0];
                break;
            case VideoEvents.clearEffect:
                const clearEffectEvent = {
                    data: {
                        args: [EffectChangeType.effectDisabled],
                    },
                } as MessageEvent;
                this.onEffectChanged(clearEffectEvent);
                break;
            // evaluation events handlers
            case EvaluationEvents.evaluationStart:
                this.evalType = event.data.args[0];
                this.totalTime = performance.now();
                // wait a moment so that `this.oneTime` will not be 0
                setTimeout(() => this.isEvaluating = true, 100);
                break;
            case EvaluationEvents.evaluationEnd:
                this.isEvaluating = false;
                this.evalType = null;
                break;
            default:
                messageProcessed = false;
        }
        return messageProcessed;
    }

    private onApplyClicked(): void {
        if (this.inPreviewStage) {
            return;
        }

        if (this.videoAppLoaded && this.videoEffectModified) {
            if (this.videoAppToBeEnabled) {
                this.enableVideoExtensibility();
            } else {
                this.disableVideoExtensibility();
            }
        }
        this.notifyVideoAppEffectChanged();
        this.videoEffectModified = false;
    }

    private onEffectChanged(event: MessageEvent): void {
        let changeType = event.data.args[0];
        if ( typeof changeType === 'number') {
          changeType = EffectChangeType[changeType];
        }
        this.selectedEffectId = event.data.args.length === 2 ? event.data.args[1] : undefined;
        // If in preview stage, apply the change immediately
        if (this.inPreviewStage) {
          this.effectChangedInPreview(changeType);
        } else {
          this.effectChangedInMeeting(changeType, event);
        }
    }

    private effectChangedInPreview(changeType: string): void {
        if (changeType === EffectChangeType.effectDisabled) {
          this.disableVideoExtensibility();
        } else if (changeType === EffectChangeType.effectChanged) {
          this.enableVideoExtensibility();
        }
        this.notifyVideoAppEffectChanged();
      }

    // When in-meeting, the change will be cached and apply when Apply clicked.
    private effectChangedInMeeting(changeType: string, event: any): void {
        if (changeType === EffectChangeType.effectDisabled) {
            const forceToDisable = event.data.args.length === 2 ? event.data.args[1] : undefined;
            if (forceToDisable === 'force') {
                this.disableVideoExtensibility();
            } else {
                this.videoEffectModified = true;
                this.videoAppToBeEnabled = false;
            }
        } else if (changeType === EffectChangeType.effectChanged && this.videoAppLoaded) {
            if (!this.enabled) {
                this.videoEffectModified = true;
                this.videoAppToBeEnabled = true;
            } else if (this.videoEffectModified) {
                this.videoEffectModified = false;
            }
        }
    }

    private notifyVideoAppEffectChanged(): void {
        this.sendToVideoApp({
            func: VideoEvents.videoEffectParameterChanged,
            args: [this.selectedEffectId],
        });
      }

    private NV122RGBA(
        img: any,
        width: number,
        height: number,
        stride: number,
    ): RGBImage {
        const newWidth = width;
        const newHeight = height;

        // convert to RGB
        const dummyRes = new Uint8ClampedArray(newHeight * newWidth * 4);
        const videoFrame = dummyRes.map((value, idx) => {
            // if A
            if ((idx % (newWidth * 4)) % 4 === 3) {
                return 255;
            }
            // if RGB
            else {
                const I = Math.floor(idx / (newWidth * 4));
                const J = Math.floor((idx % (newWidth * 4)) / 4);
                // const idxR = J - J%4;
                const idxY = I * stride + J;
                const Y = img[idxY];
                const originI = height + Math.floor(I / 2);
                const originJ = J - (J % 2);
                const originIdxU = originI * stride + originJ;
                const U = img[originIdxU];
                const V = img[originIdxU + 1];

                // if R:
                if ((idx % (newWidth * 4)) % 4 === 0) {
                    return Y - 16 + 1.402 * (V - 128);
                }
                // if G
                else if ((idx % (newWidth * 4)) % 4 === 1) {
                    return (
                        Y -
                        16 -
                        ((0.299 * 1.402) / 0.587) * (V - 128) -
                        ((0.114 * 1.772) / 0.587) * (U - 128)
                    );
                }
                // if B
                else {
                    return Y - 16 + 1.772 * (U - 128);
                }
            }
        });
        return {
            videoFrame,
            width: newWidth,
            height: newHeight,
        };
    }

    private RGBA2NV12(
        img: any,
        width: number,
        height: number,
        stride: number,
    ): NV12Image {
        const newWidth = Math.floor(width / 2) * 2;
        const newHeight = Math.floor(height / 2) * 2;
        let newPadding = 0;
        if (newWidth % 8 !== 0) {
            newPadding = 8 - (newWidth % 8);
        }

        const newStride = newWidth + newPadding;

        const nv12 = new Uint8ClampedArray(((newWidth * newStride) / 2) * 3);

        const videoFrame = nv12.map((value, idx, array) => {
            // if padding, fill in zero
            if (idx % newStride >= newWidth) {
                return 0;
            }
            // if in Y, calculte Y from RGB
            else if (Math.floor(idx / newStride) < newHeight) {
                const originJ = idx % newStride;
                const originI = Math.floor(idx / newStride);
                const originidx = originI * stride + originJ;
                const R = img[originidx * 4];
                const G = img[originidx * 4 + 1];
                const B = img[originidx * 4 + 2];
                const A = img[originidx * 4 + 3];
                return (
                    0.299 * (((225 - A) / 225) * R + (A / 225) * R) +
                    0.587 * (((225 - A) / 225) * G + (A / 225) * G) +
                    0.114 * (((225 - A) / 225) * B + (A / 225) * B) +
                    16
                );
            }
            // if in UV
            else {
                const newI = Math.floor(idx / newStride);
                const newJ = idx % newStride;
                const originI = (newI - newHeight) * 2;
                const originJ = newJ - (newJ % 2);
                const originIdxR = originI * stride + originJ;
                const R = img[originIdxR * 4];
                const G = img[originIdxR * 4 + 1];
                const B = img[originIdxR * 4 + 2];
                const A = img[originIdxR * 4 + 3];
                const yp =
                    0.299 * (((225 - A) / 225) * R + (A / 225) * R) +
                    0.587 * (((225 - A) / 225) * G + (A / 225) * G) +
                    0.114 * (((225 - A) / 225) * B + (A / 225) * B);

                // if it is U
                if (newJ % 2 === 0) {
                    return (B - yp) / 1.772 + 128;
                }
                // if it is V
                else {
                    return (R - yp) / 1.402 + 128;
                }
            }
        });
        return {
            videoFrame,
            width: newWidth,
            height: newHeight,
            stride: newStride,
        };
    }

    private resizeNV12(
        img: any,
        width: number,
        height: number,
        stride: number,
        factor: number,
    ): NV12Image {
        // identity case
        if (factor === 1) {
            const resized = new Uint8ClampedArray(img.byteLength);
            resized.set(img);
            return { videoFrame: resized, width, height, stride };
        }
        // initialize variables
        const newHeight = Math.floor((height * factor) / 2) * 2;
        const newWidth = Math.floor((width * factor) / 2) * 2;
        let padding;
        if (newWidth % 8 === 0) {
            padding = 0;
        } else {
            padding = 8 - (newWidth % 8);
        }

        const newStide = newWidth + padding;
        const resized = new Uint8ClampedArray((newHeight / 2) * 3 * newStide);
        let originI;
        let originJ;

        // make it larger, loop the result array
        if (factor > 1) {
            // add Y values
            for (let i = 0; i < newHeight; i += 1) {
                for (let j = 0; j < newStide; j += 1) {
                    const idx = i * newStide + j;
                    // padding
                    if (j >= newWidth) {
                        resized[idx] = 0;
                    } else {
                        // add y
                        originI = Math.floor(i / factor);
                        originJ = Math.floor(j / factor);
                        resized[idx] = img[originI * stride + originJ];
                    }
                }
            }

            // add UV values
            for (let i = newHeight; i < (newHeight / 2) * 3; i += 1) {
                for (let j = 0; j < newStide; j += 1) {
                    const idx = i * newStide + j;
                    if (j >= newWidth) {
                        resized[idx] = 0;
                    } else {
                        originI = Math.floor(i / factor);
                        originJ = Math.floor(j / (2 * factor)) * 2 + (j % 2);
                        resized[idx] = img[originI * stride + originJ];
                    }
                }
            }
        }
        // make it smaller
        else {
            // add Y values
            for (let i = 0; i < newHeight; i += 1) {
                for (let j = 0; j < newStide; j += 1) {
                    const idx = i * newStide + j;
                    // padding
                    if (j >= newWidth) {
                        resized[idx] = 0;
                    }
                    // y values
                    else {
                        originI = i / factor;
                        originJ = j / factor;
                        resized[idx] = img[originI * stride + originJ];
                    }
                }
            }
            // add U and V values
            for (let i = newHeight; i < (newHeight / 2) * 3; i += 1) {
                for (let j = 0; j < newStide; j += 1) {
                    const idx = i * newStide + j;
                    // padding
                    if (j >= newWidth) {
                        resized[idx] = 0;
                    } else {
                        // uv values
                        originI = Math.floor(i / factor);
                        originJ = (j - (j % 2)) / factor + (j % 2);
                        resized[idx] = img[originI * stride + originJ];
                    }
                }
            }
        }
        return {
            videoFrame: resized,
            width: newWidth,
            height: newHeight,
            stride: newStide,
        };
    }

    private convert(videoFrame: Uint8ClampedArray) {
        if (this.targetFormat === 'NV12') {
            const resized = this.resizeNV12(
                this.originVideoFrame,
                this.originWidth,
                this.originHeight,
                this.originStride,
                this.targetFactor,
            );
            if (this.changedVideoFrame.byteLength !== resized.videoFrame.byteLength) {
                this.changedVideoFrame = new Uint8ClampedArray(new SharedArrayBuffer(resized.videoFrame.byteLength));
            }
            this.changedVideoFrame.set(resized.videoFrame);

            this.newWidth = resized.width;
            this.newHeight = resized.height;
            this.newStride = resized.stride;

            videoFrame['width'] = this.newWidth;
            videoFrame['height'] = this.newHeight;
            videoFrame['lumaStride'] = this.newStride;
            videoFrame['chromaStride'] = this.newStride;
        } else if (this.targetFormat === 'RGBA') {
            // first resize, then convert the changed video frame to RGB
            const resized = this.resizeNV12(
                this.originVideoFrame,
                this.originWidth,
                this.originHeight,
                this.originStride,
                this.targetFactor,
            );
            const rgbaImg = this.NV122RGBA(
                resized.videoFrame,
                resized.width,
                resized.height,
                resized.stride,
            );
            if (this.changedVideoFrame.byteLength !== rgbaImg[0].byteLength) {
                this.changedVideoFrame = new Uint8ClampedArray(new SharedArrayBuffer(rgbaImg[0].byteLength));
            }
            this.changedVideoFrame.set(rgbaImg.videoFrame);
            this.newWidth = rgbaImg.width;
            this.newHeight = rgbaImg.height;
            videoFrame['width'] = this.newWidth;
            videoFrame['height'] = this.newWidth;
            videoFrame['stride'] = this.newStride;
        } else {
            this.changedVideoFrame.set(this.originVideoFrame);
        }
    }

    private revertBack() {
        // change data
        if (this.targetFormat === 'NV12') {
            // no need to resize
            const resized = this.resizeNV12(
                this.changedVideoFrame,
                this.newWidth,
                this.newHeight,
                this.newStride,
                1 / this.targetFactor,
            );
            if (this.originVideoFrame.byteLength !== resized.videoFrame.byteLength) {
                this.originVideoFrame = new Uint8ClampedArray(new SharedArrayBuffer(resized.videoFrame.byteLength));
            }
            this.originVideoFrame.set(resized.videoFrame);
        } else if (this.targetFormat === 'RGBA') {
            // rgba to nv12
            const nv12Img = this.RGBA2NV12(
                this.changedVideoFrame,
                this.newWidth,
                this.newHeight,
                this.newStride,
            );

            // nv12 resize
            const resized = this.resizeNV12(
                nv12Img[0],
                nv12Img[1],
                nv12Img[2],
                nv12Img[3],
                1 / this.targetFactor,
            );
            if (this.originVideoFrame.byteLength !== resized.videoFrame.byteLength) {
                this.originVideoFrame = new Uint8ClampedArray(new SharedArrayBuffer(resized.videoFrame.byteLength));
            }

            this.originVideoFrame.set(resized.videoFrame);
        } else {
            this.originVideoFrame.set(this.changedVideoFrame);
        }
    }

    private notifyFrameProcessed() {
        if (this.arrayBufferInProcessing !== undefined) {
            if (this.isEvaluating) {
                // record time used
                if (this.evalType === EvaluationType.speedFull || this.evalType === EvaluationType.speedReal) {
                    // record speed data, send if we have enough
                    this.speedRaw.push(round(performance.now() - this.oneTime));
                    if (performance.now() - this.totalTime > this.smoother) {
                        this.totalTime = performance.now();
                        ipcRenderer.sendToHost('send-performance', this.speedRaw);
                        this.speedRaw = [];
                    }
                } else if (this.evalType === EvaluationType.memoryFull || this.evalType === EvaluationType.memoryReal) {
                    // @ts-ignore:next-line
                    const memory = performance.memory;
                    if (!memory)
                        throw new Error('`performance.memory` is not supported.');
                    // record memory data, send if we have enough
                    this.memoryActiveRaw.push(round(memory.usedJSHeapSize));
                    this.memoryTotalRaw.push(round(memory.totalJSHeapSize));
                    if (performance.now() - this.totalTime > this.smoother) {
                        this.totalTime = performance.now();
                        ipcRenderer.sendToHost('send-performance', this.memoryActiveRaw, this.memoryTotalRaw);
                        this.memoryActiveRaw = [];
                        this.memoryTotalRaw = [];
                    }
                }
            }
            this.revertBack();
            this.videoExtensibility.setVideoFrameProcessed();
            this.arrayBufferInProcessing = undefined;
        }
    }

    private enableVideoExtensibility() {
        if (!this.messageChannelEstablished) {
            this.enabled = true;
            return;
        }

        if (this.enabled || this.arrayBufferInProcessing) {
            return;
        }

        this.videoAppMessagePort.postMessage({ type: VideoEvents.enableVideoExtensibility, enable: true, config: this.videoAppConfig });
        this.enabled = true;
    }

    private disableVideoExtensibility() {
        if (!this.enabled || !this.messageChannelEstablished) {
            this.enabled = false;
            return;
        }
        this.videoAppMessagePort.postMessage({ type: VideoEvents.enableVideoExtensibility, enable: false, config: this.videoAppConfig });
        this.enabled = false;
    }

    private initilizeVideoApp() {
        const messageChanel = new MessageChannel();
        this.videoAppMessagePort = messageChanel.port1;
        this.videoAppMessagePort.onmessage = this.slimcoreMessageHandler.bind(this);
        ipcRenderer.postMessage(
            VideoEvents.sendMessagePortToMainWindow,
            null,
            [messageChanel.port2],
        );
        this.videoAppLoaded = true;
    }

    private sendFrameBufferToWebview(frameBuffer: SharedArrayBuffer) {
        this.arrayBufferInProcessing = frameBuffer;
        const frameMetaRaw = new Uint32Array(frameBuffer);
        const version = frameMetaRaw[0];
        const videoFrame = {} as Uint8ClampedArray;
        // FrameBuffer memory layout details in version 1.
        // Index   Name                         Size          Description
        // 0:      version                      4 bytes
        // 1:      frameProcessedFlag           4 bytes       Internally used in C++.
        // 2:      format                       4 bytes
        // 3:      video frame width            4 bytes
        // 4:      vide frame height            4 bytes
        // 5       offsetToRawFrame             4 bytes       Video frame buffer offset
        // 6:      video FrameByteLength        4 bytes
        // if(format == 'NV12')
        // 7:      lumaStride                   4 bytes
        // 8:      chromaStride                 4 bytes
        // else if(format == 'RGB')
        // 7:      stride                       4 bytes
        // ...     video frame buffer
        const format = { 1: 'NV12', 2: 'RGB' }[frameMetaRaw[2]];
        if (format === undefined) {
            throw new Error(`Shared memory layout error: format#${frameMetaRaw[2]} is not supported`);
        }
        videoFrame['width'] = frameMetaRaw[3];
        videoFrame['height'] = frameMetaRaw[4];
        const offsetToRawFrame = frameMetaRaw[5];
        const rawFrameByteLength = frameMetaRaw[6];
        if (format === 'NV12') {
            videoFrame['lumaStride'] = frameMetaRaw[7];
            videoFrame['chromaStride'] = frameMetaRaw[8];
            this.originStride = videoFrame['lumaStride'];
        } else if (format === 'RGB') {
            videoFrame['stride'] = frameMetaRaw[7];
            this.originStride = videoFrame['stride'];
        }
        videoFrame['data'] = new Uint8ClampedArray(
            frameBuffer,
            offsetToRawFrame,
            rawFrameByteLength,
        );

        if (version > 1) {
            console.warn(`FrameBuffer memory layout in version ${version} may not be fully supported`);
        }

        this.originWidth = videoFrame['width'];
        this.originHeight = videoFrame['height'];
        this.originVideoFrame = videoFrame['data'];

        if (
            !this.changedVideoFrame ||
            this.changedVideoFrame.byteLength !== this.originVideoFrame.byteLength
        ) {
            this.changedVideoFrame = new Uint8ClampedArray( new SharedArrayBuffer(this.originVideoFrame.byteLength));
        }

        this.convert(videoFrame);
        videoFrame['data'] = this.changedVideoFrame;
        // start timing
        if (this.evalType === EvaluationType.speedReal || this.evalType === EvaluationType.speedFull) {
            this.oneTime = performance.now();
        }

        this.sendToVideoApp({
            func: VideoEvents.newVideoFrame,
            args: [videoFrame],
        });
        return true;
    }

    private slimcoreMessageHandler(messageEvent: any) {
        const msgType = messageEvent.data.type;
        console.log(msgType);

        // begin save factor and format
        const hashString = window.location.hash.substring(1);
        const pairs = hashString.split('&');
        pairs.forEach((pair) => {
            const tokens = pair.split('=');
            if (tokens.length >= 2) {
                if (tokens[0] === 'resolution') {
                    this.targetFactor = Number(tokens[1]);
                }
                if (tokens[0] === 'format') {
                    this.targetFormat = tokens[1];
                }
            }
        });
        if (msgType === EventsFromSlimcore.ipcChangedEvent) {
            const vxOptions = {
                frameProcessedEventName: messageEvent.data.frameProcessedEventName,
                frameReadyEventName: messageEvent.data.frameReadyEventName,
                sharedMemoryName: messageEvent.data.sharedMemoryName,
            };
            if (this.videoExtensibility !== undefined) {
                this.videoExtensibility.stop();
            }
            // pass the share memory name, frameReadyEvent and frameProcessedEvent name to Electron
            this.videoExtensibility = new VideoExtensibility(vxOptions);
            this.videoExtensibility.registerForVideoFrame(this.sendFrameBufferToWebview.bind(this));
            if (!this.videoExtensibility.start()) {
                console.log('videoExtensibility start failed');
            } else {
                console.log('videoExtensibility start successfully');
            }
        } else if (
            this.videoAppMessagePort !== null &&
            msgType === EventsFromSlimcore.messageChannelEstablished
        ) {
            this.messageChannelEstablished = true;
            // When message change is established, send the message to enable the video effect
            this.videoAppMessagePort.postMessage({
                type: VideoEvents.enableVideoExtensibility,
                enable: true,
                config: this.videoAppConfig,
            });
        }
    }
}

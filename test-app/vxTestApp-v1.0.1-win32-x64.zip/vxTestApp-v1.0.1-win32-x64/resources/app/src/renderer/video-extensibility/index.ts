/// <reference path="../../../../lib/slimcore.d.ts" />
/// <reference path="../../../../lib/video-renderer.d.ts" />

import * as CanvasVideoRendererModule from '../canvas-video-renderer';
import { MainWindowOptions, RendererType } from '../ipc';

declare const CanvasVideoRenderer: typeof CanvasVideoRendererModule.CanvasVideoRenderer;
declare const slimcore: SlimCore.Engine;
declare const electronIpc: Pick<Electron.IpcRenderer, 'send' | 'sendSync' | 'on' | 'once'>;
declare const options: MainWindowOptions;
declare const hcChart: any;
declare const electronVersion: { version: number, build: number };

const vxTestAppVersion = '1.0.0';
function updateVersions() {
    getElementById('electron-version').innerText = electronVersion.version.toString();
    getElementById('slimcore-version').innerText = SlimCore.getVersion();
    getElementById('test_app-version').innerText = vxTestAppVersion;
}

const hostedSampleUrl = 'https://microsoft.github.io/teams-videoapp-sample';
function isUpdateAvailable(remoteVersion: string): boolean {
    const currentVersion = vxTestAppVersion.split('.');
    const targetVersion = remoteVersion.split('.');
    if (currentVersion[0] < targetVersion[0]) {
        return true;
    }
    if (currentVersion[1] < targetVersion[1]) {
        return true;
    }
    if (currentVersion[2] < targetVersion[2]) {
        return true;
    }
    return false;
}
function checkForUpdate() {
    fetch(`${hostedSampleUrl}/test-app/versions.json`)
        .then((res) => res.json())
        .then((res) => {
            const latestVersion = res.latest.version.slice(1);
            console.log('Latest test-app version:', latestVersion);
            if (isUpdateAvailable(latestVersion)) {
                getElementById('update-prompt').style.display = 'inline';
                getElementById('latest-test_app-version').innerText = latestVersion;
            }
        })
        .catch((err) => console.log('Fail to fetch latest test-app version.', err));
}

import Enums = SlimCore.Enums;

const propKeyEnums = {
    [Enums.Property.AccountStatus]: Enums.AccountStatus,
    [Enums.Property.CallStatus]: Enums.CallStatus,
    [Enums.Property.ContentSharingFailureReason]: Enums.ContentSharingFailureReason,
    [Enums.Property.ContentSharingStatus]: Enums.ContentSharingStatus,
    [Enums.Property.DataChannelStatus]: Enums.DataChannelStatus,
    [Enums.Property.ParticipantContentRole]: Enums.ContentSharingRole,
    [Enums.Property.ParticipantFailureReason]: Enums.ParticipantFailureReason,
    [Enums.Property.ParticipantIdentity]: Enums.IdentityType,
    [Enums.Property.ParticipantStatus]: Enums.CallStatus,
    [Enums.Property.VideoStatus]: Enums.VideoStatus,
    [Enums.Property.VideoType]: Enums.VideoType,
};

function prettifyValue(propKey: Enums.Property, value: any) {
    const propKeyEnum = propKeyEnums[propKey];
    if (!propKeyEnum) return value;

    return propKeyEnum[value] || value;
}

function prettifyObjectPropertyChangedArgs(args: SlimCore.Engine.Events.ObjectPropertyChangedArgs) {
    return {
        objectId: args.objectId,
        objectType: Enums.ObjectType[args.objectType] || args.objectType,
        propKey: Enums.Property[args.propKey] || args.propKey,
        value: prettifyValue(args.propKey, args.value),
    };
}

function prettifyQualityChangedArgs(args: SlimCore.Engine.Events.QualityChangedArgs) {
    return {
        objectId: args.objectId,
        objectType: Enums.ObjectType[args.objectType] || args.objectType,
        type: Enums.QualityEventType[args.type] || args.type,
        value: Enums.QualityLevel[args.value] || args.value,
        mediaType: Enums.MediaType[args.mediaType] || args.mediaType,
    };
}

function prettifyAudioStreamStateChangedArgs(args: SlimCore.CallHandler.Events.AudioStreamStateChangedArgs) {
    return {
        callObjectId: args.callObjectId,
        direction: Enums.MediaDirection[args.direction] || args.direction,
        streamState: Enums.MediaStreamState[args.streamState] || args.streamState,
    };
}

function prettifyDataDeviceEvent(args: SlimCore.DataDevice.Events.EventArgs) {
    return {
        event: Enums.DataDeviceEvent[args.event] || args.event,
    };
}

function enableTracing() {
    const slimcore = window['SlimCore'];
    const videoRenderer = window['VideoRenderer'];

    const methodsToIgnore = new Set<Function>();

    if (!options.usePluginHost) {
        methodsToIgnore.add(slimcore.ChromiumFrameSink.prototype.log);
    }

    function hookMethod(object: Object, name: string) {
        const origMethod = object[name];
        if (!origMethod) return;

        if (name === 'emit') return;
        if (methodsToIgnore.has(origMethod)) return;

        object[name] = function (this: any) {
            const method = `${object.constructor.name}::${name}`;

            console.time(method);
            console.log(method, arguments);

            // tslint:disable-next-line:no-invalid-this
            const result = origMethod.apply(this, arguments);

            const finish = (value: any) => {
                console.timeEnd(method);
                console.log(value);
                return value;
            };

            if (result instanceof Promise) {
                return result.then(finish);
            } else {
                return finish(result);
            }
        };
    }

    const emitHooked = Symbol('emitHooked');

    function hookEmit(object: NodeJS.EventEmitter) {
        if (object[emitHooked]) return;

        const emit = object.emit;
        object.emit = function (this: any, event: string, ...args: any[]) {
            if (event === 'object-property-changed') {
                args = [prettifyObjectPropertyChangedArgs(args[0])];
            }
            else if (event === 'quality-changed') {
                args = [prettifyQualityChangedArgs(args[0])];
            }
            else if (event === 'audio-stream-state-changed') {
                args = [prettifyAudioStreamStateChangedArgs(args[0])];
            }
            else if (event === 'event') {
                args = [prettifyDataDeviceEvent(args[0])];
            }

            // tslint:disable-next-line:no-invalid-this
            console.log(`${this.constructor.name}::emit`, event, ...args);

            // tslint:disable-next-line:no-invalid-this
            return emit.apply(this, arguments);
        };

        object[emitHooked] = true;
    }

    function hookMethods(object: Object) {
        for (const [name, value] of Object.entries(object)) {
            if (typeof value === 'function') {
                hookMethod(object, name);
            }
        }
    }

    function hookClass(cls: Function) {
        if (!cls) return;

        hookMethods(cls);
        hookMethods(cls.prototype);
        hookEmit(cls.prototype);
    }

    if (!options.usePluginHost) {
        const classes = new Set([
            slimcore.SlimCore,
            slimcore.Account,
            slimcore.Setup,
            slimcore.CallHandler,
            slimcore.VideoBinding,
            slimcore.VideoBindingRenderer,
            slimcore.VideoBindingScreenShare,
            slimcore.FrameSink,
            slimcore.ChromiumFrameSink,
            slimcore.ContentSharing,
            slimcore.DataChannel,
            slimcore.DataSource,
            slimcore.DataSink,
            slimcore.Trouter,
            slimcore.TrouterListener,
            slimcore.TrouterRequest,
            slimcore.TrouterResponse,
            slimcore.Ndi,
            slimcore.NdiFrameSink,
            slimcore.NdiParticipantStream,
        ]);

        for (const [name, value] of Object.entries(slimcore)) {
            if (typeof value === 'function') {
                if (classes.has(value)) {
                    hookClass(value);
                } else {
                    hookMethod(slimcore, name);
                }
            }
        }
    }

    hookClass(videoRenderer.ChromiumVideoRenderer);
    hookMethod(videoRenderer, 'createChromiumVideoRenderer');
}

enableTracing();

console.log('slimcore.version', SlimCore.getVersion());
console.log('slimcore.apiVersion', SlimCore.getApiVersion());

let scenario = 'pre_meeting';
let videoObjectId: number;
let videoBindingRenderer: SlimCore.VideoBindingRenderer;

class ConsoleLogger implements SlimCore.VideoRenderer.Logger {
    public constructor(private _namespace: string[] = []) {
        // noop
    }

    public createChild(namespace: string): SlimCore.VideoRenderer.Logger {
        return new ConsoleLogger([...this._namespace, namespace]);
    }

    public log(...args: any[]): void {
        return console.log.call(console, this._prefix, ...args);
    }

    public debug(...args: any[]): void {
        return console.debug.call(console, this._prefix, ...args);
    }

    public info(...args: any[]): void {
        return console.info.call(console, this._prefix, ...args);
    }

    public warn(...args: any[]): void {
        return console.warn.call(console, this._prefix, ...args);
    }

    public error(...args: any[]): void {
        return console.error.call(console, this._prefix, ...args);
    }

    private get _prefix() {
        return this._namespace.join('/');
    }
}

const logger = new ConsoleLogger();

function initSlimCore() {
    slimcore.start(false);

    slimcore.handle('device-list-changed', undefined, (args) => {
        if (args.video) {
            updateVideoDeviceList();
            if (!videoObjectId) {
                createVideoRenderer();
            }
        }
    });
}

const roundSize = 60 * 1000; // 60 seconds
let roundEndTime: number;

let evaluationType: string = null;

// all data
const speedRealData: any = {
    count: 0,
    ranges: [],
    averages: [],
};

const speedFullData: any = {
    current_count: 0,
    current_ranges: [],
    current_averages: [],
    recent: [],
    raw: [],
};

const memoryRealData: any = {
    count: 0,
    maxLen: 100,
    totalRaw: [],
    activeRaw: [],
};

const memoryFullData: any = {
    current_count: 0,
    current_totalRaw: [],
    current_activeRaw: [],
    totalRaw: [],
    activeRaw: [],
};

let speedRealChart: Highcharts.Chart;
let speedFullOneroundChart: Highcharts.Chart;
let speedFullDistChart: Highcharts.Chart;
let memoryRealChart: Highcharts.Chart;
let memoryFullOneroundChart: Highcharts.Chart;
let memoryFullDistChart: Highcharts.Chart;

function round(num: number): number {
    return Math.round(num * 100) / 100;
}

function add(a: number, b: number): number {
    return a + b;
}

function sum(arr: number[]) {
    return arr.reduce(add, 0);
}

function memoryFormatter(
    this: Highcharts.AxisLabelsFormatterContextObject,
    ctx: Highcharts.AxisLabelsFormatterContextObject,
) {
    return Number(ctx.value) / 1000 + 'k';
}

function calculateHist(allPoints: number[]): [number[], number, number] {
    const chunks = 50;
    const minP = Math.min(...allPoints);
    const maxP = Math.max(...allPoints);
    let bins = Array<number>(chunks).fill(0);
    const oneWidth = (maxP - minP) / chunks;
    for (const thisVal of allPoints) {
        const busket = Math.floor((thisVal - minP) / oneWidth);
        bins[busket] += 1;
    }
    bins = bins.map((x) => round(x / allPoints.length));
    return [bins, minP, oneWidth];
}

function initSpeedCharts() {
    speedRealChart = hcChart.createChart('chart_speed_real', {
        title: {
            text: 'Speed Evaluation',
        },
        xAxis: {
            title: {
                text: 'running time(second)',
            },
            allowDecimals: false,
        },
        yAxis: {
            title: {
                text: 'time per frame(millisecond)',
            },
            minorTickInterval: 'auto',
        },
        tooltip: {
            shared: true,
        },
        series: [{
            type: 'line',
            name: 'Average Time Per Frame (millisecond)',
            data: speedRealData.averages,
            zIndex: 1,
            marker: {
                fillColor: 'white',
                lineWidth: 2,
                lineColor: hcChart.getOptions().colors[0],
            },
        }, {
            type: 'arearange',
            name: 'Range',
            data: speedRealData.ranges,
            lineWidth: 0,
            linkedTo: ':previous',
            color: hcChart.getOptions().colors[0],
            fillOpacity: 0.15,
            zIndex: 0,
            marker: {
                enabled: false,
            },
        }],
    });

    speedFullOneroundChart = hcChart.createChart('chart_speed_full_oneround', {
        title: {
            text: 'Speed Evaluation This round',
        },
        xAxis: {
            title: {
                text: 'running time(second)',
            },
            allowDecimals: false,
        },
        yAxis: {
            title: {
                text: 'time per frame(millisecond)',
            },
            minorTickInterval: 'auto',
        },
        tooltip: {
            shared: true,
        },
        series: [{
            type: 'line',
            name: 'Average Time Per Frame (millisecond)',
            data: speedFullData.current_averages,
            zIndex: 1,
            marker: {
                fillColor: 'white',
                lineWidth: 2,
                lineColor: hcChart.getOptions().colors[0],
            },
        }, {
            name: 'Range',
            data: speedFullData.current_ranges,
            type: 'arearange',
            lineWidth: 0,
            linkedTo: ':previous',
            color: hcChart.getOptions().colors[0],
            fillOpacity: 0.15,
            zIndex: 0,
            marker: {
                enabled: false,
            },
        }],
    });

    speedFullDistChart = hcChart.createChart('chart_speed_full_dist', {
        chart: {
          type: 'area',
        },
        title: {
          text: 'Distribution of Time per Frame (millisecond)',
        },
        xAxis: {
          title: {
            text: 'Time per frame (millisecond)',
          },
          allowDecimals: false,
        },
        yAxis: {
          title: {
            text: 'Probability density',
          },
        },
        tooltip: {
          pointFormat: 'The probability of time per frame being in range {point.x} and {point.x + 0.02} is {point.y}.',
        },
        plotOptions: {
          area: {
            pointStart: 0,
            pointInterval: 0.02,
            marker: {
              enabled: false,
              symbol: 'circle',
              radius: 2,
              states: {
                hover: {
                  enabled: true,
                },
              },
            },
          },
        },
        series: [{
            type: 'area',
            name: 'Time per frame',
            data: [],
            pointStart: 0,
            pointInterval: 0.15,
        }],
    });
}

function initMemoryCharts() {
    memoryRealChart = hcChart.createChart('chart_memory_real', {
        title: {
          text: 'Memory Usage',
        },
        xAxis: {
          allowDecimals: false,
        },
        yAxis: {
          title: {
            text: 'Heap size (byte)',
          },
          labels: {
            // formatter: function () {
            //   return Number(this.value) / 1000 + 'k';
            // },
            formatter: memoryFormatter,
          },
        },
        tooltip: {
          pointFormat: '{series.name} is <b>{point.y:,.0f}</b><br/>in the {point.x}th previous frame',
        },
        plotOptions: {
          area: {
            pointStart: 0,
            pointInterval: 1,
            marker: {
              enabled: false,
              symbol: 'circle',
              radius: 2,
              states: {
                hover: {
                  enabled: true,
                },
              },
            },
          },
        },
        series: [{
            type: 'area',
            name: 'Active segment of JS heap (byte)',
            data: [],
        }, {
            type: 'area',
            name: 'Total allocated heap size (byte)',
            data: [],
        }],
    });

    memoryFullOneroundChart = hcChart.createChart('chart_memory_full_oneround', {
        title: {
          text: 'Memory Usage This Round',
        },
        xAxis: {
          allowDecimals: false,
        },
        yAxis: {
          title: {
            text: 'Heap size (byte)',
          },
          labels: {
            formatter: memoryFormatter,
          },
        },
        tooltip: {
          pointFormat: '{series.name} is <b>{point.y:,.0f}</b><br/>in the {point.x}th previous frame',
        },
        plotOptions: {
          area: {
            pointStart: 0,
            pointInterval: 1,
            marker: {
              enabled: false,
              symbol: 'circle',
              radius: 2,
              states: {
                hover: {
                  enabled: true,
                },
              },
            },
          },
        },
        series: [{
            type: 'area',
            name: 'Active segment of JS heap (byte)',
            data: [],
        }, {
            type: 'area',
            name: 'Total allocated heap size (byte)',
            data: [],
        }],
    });

    memoryFullDistChart = hcChart.createChart('chart_memory_full_dist', {
        title: {
          text: 'Distribution of Memory Usage (byte)',
        },
        xAxis: {
          title: {
            text: 'Memory Usage (byte)',
          },
          allowDecimals: false,
        },
        yAxis: {
          title: {
            text: 'Probability density',
          },
        },
        tooltip: {
          pointFormat: 'The probability of memory usage {point.x} and {point.x + 0.02} is {point.y}.',
        },
        plotOptions: {
          area: {
            pointStart: 0,
            pointInterval: 0.02,
            marker: {
              enabled: false,
              symbol: 'circle',
              radius: 2,
              states: {
                hover: {
                  enabled: true,
                },
              },
            },
          },
        },
        series: [{
            type: 'area',
            name: 'Active Memory',
            data: [],
            pointStart: 0,
            pointInterval: 0.15,
        }, {
            type: 'area',
            name: 'Total Memory',
            data: [],
            pointStart: 0,
            pointInterval: 0.15,
        }],
    });
}

function getElementById<T extends HTMLElement>(id: string) {
    return document.getElementById(id) as T;
}

function showElementById<T extends HTMLElement>(id: string) {
    getElementById<T>(id).style.display = 'inline';
}

function hideElementById<T extends HTMLElement>(id: string) {
    getElementById<T>(id).style.display = 'none';
}

function getWebview(): Electron.WebviewTag | null {
    return getElementById('webview');
}

function sendToWebview(func: string, ...args: any[]) {
    const wv = getWebview();
    if (wv) {
        wv.send('main-renderer-to-webview-postmessage', { data: { func, args } });
    } else {
        console.log('SendToWebView failed, webview element not found.');
    }
}

function sendEvaluationStart(evaluationType: string) {
    sendToWebview('video.evaluationStart', evaluationType);
}

function sendEvaluationEnd() {
    sendToWebview('video.evaluationEnd');
}

function sendFormatParameters(param: string) {
    sendToWebview('video.formatParameterChange', param);
}

function sendResolutionParameters(param: string) {
    sendToWebview('video.resolutionParameterChange', param);
}

function sendEffectParameters(param: string) {
    sendToWebview('video.effectParameterChange', param);
}

// helper perf2
function endEvaluation() {
    sendEvaluationEnd();
    evaluationType = null;
    roundEndTime = null;
}

function ipcMessageHandler(event: any) {
    const message = event.args[1];
    console.log(event);
    if (event.channel === 'send-performance') {
        // case on four types of eval options
        if (evaluationType === 'speed_real') {
            speedRealData.averages[speedRealData.count] = ([speedRealData.count, round(sum(event.args[0]) / (event.args[0].length))]);
            speedRealData.ranges[speedRealData.count] = ([speedRealData.count, Math.min(...event.args[0]), Math.max(...event.args[0])]);
            speedRealData.count += 1;

            // update chart
            speedRealChart.series[0].setData(speedRealData.averages);
            speedRealChart.series[1].setData(speedRealData.ranges);
        } else if (evaluationType === 'speed_full') {
            // save data
            const thisAvg = round(sum(event.args[0]) / (event.args[0].length));

            speedFullData.current_averages[speedFullData.current_count] = ([speedFullData.current_count, thisAvg]);
            speedFullData.current_ranges[speedFullData.current_count] = ([speedFullData.current_count, Math.min(...event.args[0]), Math.max(...event.args[0])]);
            speedFullData.current_count += 1;

            speedFullData.raw = speedFullData.raw.concat(event.args[0]);
            if (speedFullData.recent.length < 10) {
                speedFullData.recent.push(thisAvg);
            } else {
                speedFullData.recent.shift();
                speedFullData.recent.push(thisAvg);
            }

            // update chart distribution
            const distri = calculateHist(speedFullData.raw);
            speedFullDistChart.series[0].update({
                type: 'area',
                data: distri[0],
                pointStart: distri[1],
                pointInterval: distri[2],
            });

            // update chart real time speed
            speedFullOneroundChart.series[0].setData(speedFullData.current_averages);
            speedFullOneroundChart.series[1].setData(speedFullData.current_ranges);

            // if we finish one round, archine the data of current round and reinitialize the data
            if (Date.now() > roundEndTime) {
                endEvaluation();
                speedFullData.current_ranges = [];
                speedFullData.current_averages = [];
            }
        } else if (evaluationType === 'memory_real') {
            // maintain a queue
            memoryRealData.activeRaw = memoryRealData.activeRaw.concat(event.args[0]);
            memoryRealData.totalRaw = memoryRealData.totalRaw.concat(event.args[1]);

            // update chart
            memoryRealChart.series[0].setData(memoryRealData.activeRaw);
            memoryRealChart.series[1].setData(memoryRealData.totalRaw);
        } else if (evaluationType === 'memory_full') {
            memoryFullData.current_activeRaw = memoryFullData.current_activeRaw.concat(event.args[0]);
            memoryFullData.current_totalRaw = memoryFullData.current_totalRaw.concat(event.args[1]);

            memoryFullData.activeRaw = memoryFullData.activeRaw.concat(event.args[0]);
            memoryFullData.totalRaw = memoryFullData.totalRaw.concat(event.args[1]);

            // update one round chart
            memoryFullOneroundChart.series[0].setData(memoryFullData.current_activeRaw);
            memoryFullOneroundChart.series[1].setData(memoryFullData.current_totalRaw);

            // update dist chart
            const distributionActive = calculateHist(memoryFullData.activeRaw);
            const distributionReal = calculateHist(memoryFullData.totalRaw);
            memoryFullDistChart.series[0].update({
                type: 'area',
                data: distributionActive[0],
                pointStart: distributionActive[1],
                pointInterval: distributionActive[2],
            });
            memoryFullDistChart.series[1].update({
                type: 'area',
                data: distributionReal[0],
                pointStart: distributionReal[1],
                pointInterval: distributionReal[2],
            });

            // if we finish one round, reinitialize
            if (Date.now() > roundEndTime) {
                endEvaluation();
                memoryFullData.current_activeRaw = [];
                memoryFullData.current_totalRaw = [];
            }
        }
    }

    if (message && message.func === 'iframeLoaded') {
        return;
    }

    if (scenario === 'pre_meeting' && message && message.func === 'video.effectParameterChanged') {
        sendEffectParameters(undefined);
        return;
    }
}

function clearElement(element: HTMLElement) {
    while (element.firstChild) {
        element.removeChild(element.firstChild);
    }
}

function createOption(title: string, value: string) {
    const option = document.createElement('option');
    option.innerText = title;
    option.value = value;

    return option;
}

function updateDeviceList(id: string, list: SlimCore.DeviceInfo[]) {
    const select = getElementById<HTMLSelectElement>(id);
    clearElement(select);

    for (const info of list) {
        select.appendChild(createOption(info.label, info.id));
    }
}

function initRendererTypes() {
    const select = getElementById<HTMLSelectElement>('renderer-type');
    clearElement(select);

    if (VideoRenderer.isChromiumVideoRendererAvailable()) {
        select.appendChild(createOption('Chromium', `${RendererType.Chromium}`));
    }

    if (CanvasVideoRenderer.isAvailable()) {
        select.appendChild(createOption('WebGL', `${RendererType.WebGL}`));
    }
}

function updateVideoDeviceList() {
    updateDeviceList('camera-list', slimcore.getCameraList());
}

function getSelectedCameraId() {
    return getElementById<HTMLSelectElement>('camera-list').value;
}

function getSelectedCameraName() {
    return getElementById<HTMLSelectElement>('camera-list').selectedOptions[0].textContent;
}

function getSelectedRendererType() {
    return parseInt(getElementById<HTMLSelectElement>('renderer-type').value, 10) as RendererType;
}

function createVideoRendererImpl(args: SlimCore.VideoRenderer.ConstructorArgs) {
    const type = getSelectedRendererType();
    const frameSink = SlimCore.createChromiumFrameSink({
        enableTextureSharing: options.enableTextureSharing,
        enableTextureUpload: options.enableTextureUpload,
        enableEventObject: type === RendererType.WebGL,
    });

    switch (type) {
        case RendererType.WebGL:
            return new CanvasVideoRenderer(args, frameSink);
        case RendererType.Chromium:
            return VideoRenderer.createChromiumVideoRenderer(frameSink, args);
        default:
            throw new Error(`Invalid renderer type: ${type}`);
    }
}

async function createVideoRenderer() {
    if (videoObjectId) {
        await destroyVideoRenderer();
    }

    const deviceId = getSelectedCameraId();
    const deviceName = getSelectedCameraName();

    videoObjectId = slimcore.createPreviewVideo(Enums.VideoType.Video, deviceName, deviceId);
    slimcore.videoStart(videoObjectId);

    const container = getElementById('skypevideo-container');

    const videoRenderer = createVideoRendererImpl({
        container: container,
        transparent: false,
        scalingMode: SlimCore.VideoRenderer.ScalingMode.Fit,
        logger: logger,
        useBufferSharing: true,
    });

    videoBindingRenderer = slimcore.createVideoBindingRenderer({
        enableDXVA: true,
        enableBGRA: true,
    });

    videoBindingRenderer.addFrameSink(videoRenderer.getFrameSink());
    slimcore.videoCreateBinding(videoObjectId, videoBindingRenderer);
}

async function destroyVideoRenderer() {
    if (videoObjectId) {
        slimcore.videoStop(videoObjectId);
        await slimcore.videoReleaseBinding(videoObjectId, videoBindingRenderer);
        videoObjectId = null;
        videoBindingRenderer = null;

        const container = getElementById('skypevideo-container');
        clearElement(container);
    }
}

function createWebView(url: string) {
    const wv = document.createElement('webview');
    wv.id = 'webview';
    wv.src = url;
    return wv;
}

function initWebView(resolution = 1, format = 'NV12') {
    const videoapp = getElementById('webview-wrapper');
    const appUrl = getElementById<HTMLInputElement>('app_url');
    if (!appUrl.value) {
        appUrl.value = `${hostedSampleUrl}/app/`;
    }
    const wv = createWebView(`${hostedSampleUrl}/container/iframe.html#iframeurl=`
        + encodeURIComponent(appUrl.value) + '&skipDomainValidation=true&multiwindow=true&resolution=' + resolution + '&format=' + format);
    videoapp.appendChild(wv);
    wv.addEventListener('did-finish-load', () => {
        wv.openDevTools();
    });

    wv.addEventListener('ipc-message', ipcMessageHandler);
}

export function loadVideoApp() {
    const wv = getWebview();
    if (wv) {
        wv.remove();
    }
    initWebView();
}

export function openMultithread() {
    getElementById<HTMLInputElement>('app_url').value = `${hostedSampleUrl}/app/multithread.html`;

    if (!getWebview()) {
        initWebView();
    }
}

function setScenario(tartgetScenario: string) {
    if (scenario !== tartgetScenario) {
        console.log(`Setting scenario to '${tartgetScenario}'`);
        scenario = tartgetScenario;
        sendToWebview(scenario === 'pre_meeting' ? 'video.inPreview' : 'video.videoOn', undefined);
    }
}

function initScenarioList() {
    const select = getElementById<HTMLSelectElement>('scenario-list');
    clearElement(select);

    select.appendChild(createOption('prejoin', 'pre_meeting'));
    select.appendChild(createOption('in-meeting', 'in_meeting'));

    select.value = 'pre_meeting';
    select.addEventListener('change', () => {
        setScenario(select.value);
    });
}

export function applyEffect() {
    console.log(`Applying effect`);
    sendToWebview('video.applyClicked');
}

export function sendEffectParams() {
    const effctParams = getElementById<HTMLInputElement>('effect_params').value;
    sendEffectParameters(effctParams);
}

export function clearEffect() {
    sendToWebview('video.clearEffect');
}

// Send resolution and format parameters
function setResolution(targetRes: string) {
    console.log(`Changing resolution to ${targetRes}`);
    if (getWebview()) {
        sendResolutionParameters(targetRes);
    }
}

function initResolutionList() {
    const select = getElementById<HTMLSelectElement>('resolution-list');
    clearElement(select);

    select.appendChild(createOption('0.5x', '0.5'));
    select.appendChild(createOption('1.0x', '1.0'));
    select.appendChild(createOption('2.0x', '2.0'));

    select.value = '1.0';
    select.addEventListener('change', () => {
        setResolution(select.value);
    });
}

export function setImageFormat(format: string) {
    console.log(`Changing image format to ${format}`);
    if (getWebview()) {
        sendFormatParameters(format);
    }
}

export function startSpeedRealtimeEvaluation() {
    evaluationType = 'speed_real';
    sendEvaluationStart('speed_real');
    showElementById('chart_speed_real');
}

export function startSpeedFullEvaluation() {
    evaluationType = 'speed_full';
    sendEvaluationStart('speed_full');
    showElementById('chart_speed_full_oneround');
    showElementById('chart_speed_full_dist');
    roundEndTime = Date.now() + roundSize;
}

export function endSpeedEvaluation() {
    endEvaluation();
}

export function resetSpeedCharts() {
    if (evaluationType === 'speed_real' || 'speed_full') {
        endEvaluation();
    }

    // Hide speed charts
    hideElementById('chart_speed_real');
    hideElementById('chart_speed_full_oneround');
    hideElementById('chart_speed_full_dist');

    // Reset speed realtime chart
    speedRealData.count = 0;
    speedRealData.averages = [];
    speedRealData.ranges = [];
    speedRealChart.series[0].setData(speedRealData.averages);
    speedRealChart.series[1].setData(speedRealData.ranges);

    // Reset speed full charts
    speedFullData.current_count =  0;
    speedFullData.current_ranges =  [];
    speedFullData.current_averages =  [];
    speedFullData.recent =  [];
    speedFullData.raw =  [];
    speedFullOneroundChart.series[0].setData(speedFullData.current_averages);
    speedFullOneroundChart.series[1].setData(speedFullData.current_ranges);
    speedFullDistChart.series[0].update({
        type: 'area',
        data: [],
        pointStart: 0,
        pointInterval: 0.15,
    });
}

export function startMemoryRealtimeEvaluation() {
    evaluationType = 'memory_real';
    sendEvaluationStart('memory_real');
    showElementById('chart_memory_real');
}

export function startMemoryFullEvaluation() {
    evaluationType = 'memory_full';
    sendEvaluationStart('memory_full');
    showElementById('chart_memory_full_oneround');
    showElementById('chart_memory_full_dist');
    roundEndTime = Date.now() + roundSize;
}

export function endMemeoryEvaluation() {
    endEvaluation();
}

export function resetMemoryCharts() {
    if (evaluationType === 'memory_real' || evaluationType === 'memory_full') {
        endEvaluation();
    }

    // Hide memory charts
    hideElementById('chart_memory_real');
    hideElementById('chart_memory_full_oneround');
    hideElementById('chart_memory_full_dist');

    // Reset memory realtime chart
    memoryRealData.count =  0;
    memoryRealData.maxLen =  100;
    memoryRealData.totalRaw =  [];
    memoryRealData.activeRaw =  [];
    memoryRealChart.series[0].setData(memoryRealData.activeRaw);
    memoryRealChart.series[1].setData(memoryRealData.totalRaw);

    // Reset memory full charts
    memoryFullData.current_count = 0;
    memoryFullData.current_totalRaw = [];
    memoryFullData.current_activeRaw = [];
    memoryFullData.totalRaw = [];
    memoryFullData.activeRaw = [];
    memoryFullOneroundChart.series[0].setData(memoryFullData.current_activeRaw);
    memoryFullOneroundChart.series[1].setData(memoryFullData.current_totalRaw);
    memoryFullDistChart.series[0].update({
        type: 'area',
        data: [],
        pointStart: 0,
        pointInterval: 0.15,
    });
    memoryFullDistChart.series[1].update({
        type: 'area',
        data: [],
        pointStart: 0,
        pointInterval: 0.15,
    });
}

let videoExtensibilityMessagePortToVideoApp: MessagePort;
function turnOnVideoExtensibility(config: any) {
    const deviceId = getSelectedCameraId();
    const result = slimcore.sendMessageDeviceVideoExtensibility(deviceId, {
        type: 'Enable',
        options: {
            format: 'NV12',
        },
    });
    console.log('turnOnVideoExtensibility -', result);
}

let eventRegistered = false;
function turnOffVideoExtensibility() {
    const deviceId = getSelectedCameraId();
    const result = slimcore.sendMessageDeviceVideoExtensibility(deviceId, {
        type: 'Disable',
    });
    console.log('turnOffVideoExtensibility -', result);
}

function onVideoAppMessageChannelMessage(event: MessageEvent) {
    const messageType = event.data.type;
    if (messageType === 'video.enableVideoExtensibility') {
        if (event.data.enable) {
            if (!eventRegistered) {
                // register new video frame event to slimcore instance through device manager
                slimcore.handle('video-extensibility-ipc-changed-event', undefined, (args) => {
                    console.log('video-extensibility-ipc-changed-event', args);
                    notifyIpcChanged(args);
                });
                slimcore.handle('video-extensibility-error', undefined, (args) => {
                    console.log('video-extensibility-error', args);
                });
                eventRegistered = true;
            }
            turnOnVideoExtensibility(event.data.config);
        } else {
            turnOffVideoExtensibility();
        }
    }
}

let queuedIpcChangedEvent: SlimCore.Engine.Events.VideoExtensibilityIpcChangedEventArgs | undefined | null;
function notifyIpcChanged(args: SlimCore.Engine.Events.VideoExtensibilityIpcChangedEventArgs) {
    if (videoExtensibilityMessagePortToVideoApp === undefined) {
        queuedIpcChangedEvent = args;
    } else {
        videoExtensibilityMessagePortToVideoApp.postMessage(Object.assign({ type: 'video.videoExtensibilityIpcChangedEvent' }, args));
        queuedIpcChangedEvent = null;
    }
}

window.addEventListener('message', (event) => {
    console.log('MessageEvent:', event);
    if (typeof event.data !== 'string' || event.data !== 'video.sendMessagePortToMainWorld') {
        return;
    }
    videoExtensibilityMessagePortToVideoApp = event.ports[0];
    videoExtensibilityMessagePortToVideoApp.onmessage = onVideoAppMessageChannelMessage;
    videoExtensibilityMessagePortToVideoApp.addEventListener('close', () => {
        turnOffVideoExtensibility();
        videoExtensibilityMessagePortToVideoApp = undefined;
    });
    videoExtensibilityMessagePortToVideoApp.postMessage({
        type: 'video.messageChannelEstablished',
    });
    if (queuedIpcChangedEvent) {
        notifyIpcChanged(queuedIpcChangedEvent);
    }
});

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOMContentLoaded, initializing...');
    updateVersions();
    checkForUpdate();
    initSlimCore();
    initRendererTypes();
    initScenarioList();
    initResolutionList();

    getElementById('camera-list').addEventListener('change', () => {
        createVideoRenderer();
    });
    getElementById('renderer-type').addEventListener('change', () => {
        createVideoRenderer();
    });

    // init charts
    console.log('Initialize charts...');
    const colors = ['#074e84', '#95b5c7', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4'];
    hcChart.setOptions({ colors });
    initSpeedCharts();
    initMemoryCharts();

    electronIpc.send('video-extensibility-ready');
});

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EvaluationType;
(function (EvaluationType) {
    EvaluationType["speedReal"] = "speed_real";
    EvaluationType["speedFull"] = "speed_full";
    EvaluationType["memoryReal"] = "memory_real";
    EvaluationType["memoryFull"] = "memory_full";
})(EvaluationType = exports.EvaluationType || (exports.EvaluationType = {}));
var VideoEvents;
(function (VideoEvents) {
    VideoEvents["sendMessagePortToMainWindow"] = "video.sendMessagePortToMainWindow";
    VideoEvents["enableVideoExtensibility"] = "video.enableVideoExtensibility";
    VideoEvents["videoEffectParameterChanged"] = "video.effectParameterChanged";
    VideoEvents["videoEffectChanged"] = "video.videoEffectChanged";
    VideoEvents["newVideoFrame"] = "video.newVideoFrame";
    // add resolution change and img format change
    VideoEvents["videoResolutionParameterChanged"] = "video.resolutionParameterChanged";
    VideoEvents["videoFormatParameterChanged"] = "video.formatParameterChanged";
})(VideoEvents = exports.VideoEvents || (exports.VideoEvents = {}));
var VideoAppEvents;
(function (VideoAppEvents) {
    VideoAppEvents["videoFrameProcessed"] = "video.videoFrameProcessed";
    VideoAppEvents["registerForVideoFrame"] = "video.registerForVideoFrame";
    VideoAppEvents["notifyError"] = "video.notifyError";
})(VideoAppEvents = exports.VideoAppEvents || (exports.VideoAppEvents = {}));
var EventsFromHostWebView;
(function (EventsFromHostWebView) {
    EventsFromHostWebView["inPreview"] = "video.inPreview";
    EventsFromHostWebView["applyClicked"] = "video.applyClicked";
    EventsFromHostWebView["videoOn"] = "video.videoOn";
    EventsFromHostWebView["videoAppLoaded"] = "video.videoAppLoaded";
})(EventsFromHostWebView = exports.EventsFromHostWebView || (exports.EventsFromHostWebView = {}));
var EventsFromSlimcore;
(function (EventsFromSlimcore) {
    EventsFromSlimcore["ipcChangedEvent"] = "video.videoExtensibilityIpcChangedEvent";
    EventsFromSlimcore["performanceErrorEvent"] = "video.videoExtensibilityPerfErrorEvent";
    EventsFromSlimcore["performanceAlertEvent"] = "video.videoExtensibilityPerfAlertEvent";
    EventsFromSlimcore["messageChannelEstablished"] = "video.messageChannelEstablished";
    EventsFromSlimcore["videoEffectDisabled"] = "video.videoEffectDisabled";
})(EventsFromSlimcore = exports.EventsFromSlimcore || (exports.EventsFromSlimcore = {}));
var EvaluationEvents;
(function (EvaluationEvents) {
    EvaluationEvents["evaluationStart"] = "video.evaluationStart";
    EvaluationEvents["evaluationEnd"] = "video.evaluationEnd";
    EvaluationEvents["isIsolate"] = "video.isolate";
})(EvaluationEvents = exports.EvaluationEvents || (exports.EvaluationEvents = {}));
//# sourceMappingURL=utils.js.map
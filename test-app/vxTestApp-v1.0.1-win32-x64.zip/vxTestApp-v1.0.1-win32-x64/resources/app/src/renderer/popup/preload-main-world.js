"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const canvas_video_renderer_1 = require("../canvas-video-renderer");
function exposeModules() {
    // tslint:disable-next-line:no-require-imports
    const videoRenderer = require('slimcore/lib/video-renderer');
    window['VideoRenderer'] = videoRenderer;
    window['CanvasVideoRenderer'] = canvas_video_renderer_1.CanvasVideoRenderer;
    window['EventEmitter'] = events_1.EventEmitter;
}
exposeModules();
//# sourceMappingURL=preload-main-world.js.map
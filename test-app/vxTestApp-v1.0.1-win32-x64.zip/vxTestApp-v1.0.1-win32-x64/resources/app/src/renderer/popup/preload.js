"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const utils_1 = require("../utils");
function exposeModules() {
    electron_1.contextBridge.exposeInMainWorld('electronIpc', utils_1.electronIpc);
    electron_1.contextBridge.exposeInMainWorld('createFrameSinkReader', utils_1.createFrameSinkReader);
    utils_1.executePreload(utils_1.invokeSync('get-preload-main-world'));
}
if (location.origin === 'file://') {
    exposeModules();
}
// index.js: Object.defineProperty(exports, "__esModule", { value: true });
electron_1.webFrame.executeJavaScript(`var exports = {};`);
console.log('pid', process.pid);
//# sourceMappingURL=preload.js.map
"use strict";
/// <reference path="../../../../lib/slimcore.d.ts" />
/// <reference path="../../../../lib/video-renderer.d.ts" />
Object.defineProperty(exports, "__esModule", { value: true });
let videoRenderer = null;
class FrameSinkProxy extends EventEmitter {
    constructor(_bufferName) {
        super();
        this._bufferName = _bufferName;
        this._isDisposed = false;
    }
    dispose() {
        this._isDisposed = true;
    }
    isDisposed() {
        return this._isDisposed;
    }
    setVideoPreference(width, height) {
        this.invoke('setVideoPreference', width, height);
    }
    setIgnoreMirroring(ignore) {
        this.invoke('setIgnoreMirroring', ignore);
    }
    setTextureSharingSupported(supported) {
        this.invoke('setTextureSharingSupported', supported);
    }
    _setForceI420(enabled) {
        this.invoke('_setForceI420', enabled);
    }
    getBufferName() {
        return this._bufferName;
    }
    getStats() {
        return undefined;
    }
    getFrameType() {
        return undefined;
    }
    getMetadata() {
        return undefined;
    }
    log(level, message) {
        this.invoke('log', level, message);
    }
    invoke(method, ...args) {
        electronIpc.send('frame-sink-invoke', method, ...args);
    }
}
function createVideoRendererImpl(params, args) {
    const frameSink = new FrameSinkProxy(params.bufferName);
    switch (params.rendererType) {
        case 0 /* WebGL */:
            return new CanvasVideoRenderer(args, frameSink);
        case 1 /* Chromium */:
            return VideoRenderer.createChromiumVideoRenderer(frameSink, args);
        default:
            throw new Error(`Invalid renderer type: ${params.rendererType}`);
    }
}
document.addEventListener('DOMContentLoaded', () => {
    const args = JSON.parse(decodeURIComponent(location.hash.substr(1)));
    videoRenderer = createVideoRendererImpl(args, {
        container: document.getElementById('container'),
        transparent: false,
        scalingMode: 2 /* Fit */,
        useBufferSharing: true,
    });
    videoRenderer.on('video-size-changed', (args) => {
        console.log('video-size-changed', args);
    });
});
//# sourceMappingURL=index.js.map
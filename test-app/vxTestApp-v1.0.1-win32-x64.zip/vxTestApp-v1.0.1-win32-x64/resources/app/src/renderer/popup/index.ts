/// <reference path="../../../../lib/slimcore.d.ts" />
/// <reference path="../../../../lib/video-renderer.d.ts" />

import * as eventsModule from 'events';

// types
import * as CanvasVideoRendererModule from '../canvas-video-renderer';
import { RendererType, OpenPopupArgs } from '../ipc';

declare const CanvasVideoRenderer: typeof CanvasVideoRendererModule.CanvasVideoRenderer;

declare const EventEmitter: typeof eventsModule.EventEmitter;
declare const electronIpc: Pick<Electron.IpcRenderer, 'send' | 'sendSync' | 'on' | 'once'>;
declare const VideoRenderer: SlimCore.VideoRendererModule;

let videoRenderer: SlimCore.VideoRenderer = null;

class FrameSinkProxy extends EventEmitter implements SlimCore.ChromiumFrameSink
{
    private _isDisposed = false;

    public constructor(private _bufferName: string) {
        super();
    }

    public dispose() {
        this._isDisposed = true;
    }

    public isDisposed() {
        return this._isDisposed;
    }

    public setVideoPreference(width: number, height: number) {
        this.invoke('setVideoPreference', width, height);
    }

    public setIgnoreMirroring(ignore: boolean) {
        this.invoke('setIgnoreMirroring', ignore);
    }

    public setTextureSharingSupported(supported: boolean) {
        this.invoke('setTextureSharingSupported', supported);
    }

    public _setForceI420(enabled: boolean) {
        this.invoke('_setForceI420', enabled);
    }

    public getBufferName() {
        return this._bufferName;
    }

    public getStats(): SlimCore.ChromiumFrameSink.Stats {
        return undefined;
    }

    public getFrameType(): SlimCore.FrameSink.FrameType {
        return undefined;
    }

    public getMetadata(): SlimCore.FrameSink.Metadata {
        return undefined;
    }

    public log(level: SlimCore.FrameSink.LogLevel, message: string) {
        this.invoke('log', level, message);
    }

    private invoke(method: string, ...args: any[]) {
        electronIpc.send('frame-sink-invoke', method, ...args);
    }
}

function createVideoRendererImpl(params: OpenPopupArgs, args: SlimCore.VideoRenderer.ConstructorArgs)
{
    const frameSink = new FrameSinkProxy(params.bufferName);

    switch (params.rendererType) {
        case RendererType.WebGL:
            return new CanvasVideoRenderer(args, frameSink);

        case RendererType.Chromium:
            return VideoRenderer.createChromiumVideoRenderer(frameSink, args);

        default:
            throw new Error(`Invalid renderer type: ${params.rendererType}`);
    }
}

document.addEventListener('DOMContentLoaded', () =>
{
    const args = JSON.parse(decodeURIComponent(location.hash.substr(1)));

    videoRenderer = createVideoRendererImpl(args, {
        container: document.getElementById('container'),
        transparent: false,
        scalingMode: SlimCore.VideoRenderer.ScalingMode.Fit,
        useBufferSharing: true,
    });

    videoRenderer.on('video-size-changed', (args) => {
        console.log('video-size-changed', args);
    });
});

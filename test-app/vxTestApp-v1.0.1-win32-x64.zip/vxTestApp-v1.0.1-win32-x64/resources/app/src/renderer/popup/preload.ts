import { contextBridge, webFrame } from 'electron';
import { electronIpc, invokeSync, executePreload, createFrameSinkReader } from '../utils';

function exposeModules()
{
    contextBridge.exposeInMainWorld('electronIpc', electronIpc);
    contextBridge.exposeInMainWorld('createFrameSinkReader', createFrameSinkReader);
    executePreload(invokeSync('get-preload-main-world'));
}

if (location.origin === 'file://') {
    exposeModules();
}

// index.js: Object.defineProperty(exports, "__esModule", { value: true });
webFrame.executeJavaScript(`var exports = {};`);

console.log('pid', process.pid);

(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const utils_1 = require("../utils");
function exposeModules() {
    electron_1.contextBridge.exposeInMainWorld('electronIpc', utils_1.electronIpc);
    electron_1.contextBridge.exposeInMainWorld('createFrameSinkReader', utils_1.createFrameSinkReader);
    utils_1.executePreload(utils_1.invokeSync('get-preload-main-world'));
}
if (location.origin === 'file://') {
    exposeModules();
}
// index.js: Object.defineProperty(exports, "__esModule", { value: true });
electron_1.webFrame.executeJavaScript(`var exports = {};`);
console.log('pid', process.pid);

},{"../utils":2,"electron":undefined}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
exports.electronIpc = {
    send: electron_1.ipcRenderer.send.bind(electron_1.ipcRenderer),
    sendSync: electron_1.ipcRenderer.sendSync.bind(electron_1.ipcRenderer),
    on: electron_1.ipcRenderer.on.bind(electron_1.ipcRenderer),
    once: electron_1.ipcRenderer.once.bind(electron_1.ipcRenderer),
};
function invokeSync(command, ...args) {
    const [error, result] = electron_1.ipcRenderer.sendSync(command, ...args);
    if (error) {
        throw error;
    }
    else {
        return result;
    }
}
exports.invokeSync = invokeSync;
function executePreload(preload) {
    electron_1.webFrame.executeJavaScript(`(() => {${preload}})();`);
}
exports.executePreload = executePreload;
function createFrameSinkReaderImpl(bufferName) {
    const reader = new electron_1.FrameSinkReader();
    reader.on('log', (level, message) => {
        postMessage({ bufferName, level, message }, '*');
    });
    const processFrame = () => {
        const frame = reader.getFrame();
        if (frame !== undefined) {
            postMessage({ bufferName, frame }, '*');
        }
    };
    if (!reader.connect(bufferName, true)) {
        throw new Error('FrameSinkReader.prototype.connect() failed');
    }
    let handle;
    const tick = () => {
        processFrame();
        handle = requestAnimationFrame(tick);
    };
    if (reader.isNewFrameEventAvailable) {
        reader.on('new-frame', processFrame);
    }
    else {
        handle = requestAnimationFrame(tick);
    }
    return {
        dispose: () => {
            cancelAnimationFrame(handle);
            reader.disconnect();
        },
    };
}
exports.createFrameSinkReader = electron_1.FrameSinkReader ? createFrameSinkReaderImpl : undefined;

},{"electron":undefined}]},{},[1]);

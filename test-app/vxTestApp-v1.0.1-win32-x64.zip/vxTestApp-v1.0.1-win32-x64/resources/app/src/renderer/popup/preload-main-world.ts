import { EventEmitter } from 'events';
import { CanvasVideoRenderer } from '../canvas-video-renderer';

function exposeModules()
{
    // tslint:disable-next-line:no-require-imports
    const videoRenderer = require('slimcore/lib/video-renderer');

    window['VideoRenderer'] = videoRenderer;
    window['CanvasVideoRenderer'] = CanvasVideoRenderer;
    window['EventEmitter'] = EventEmitter;
}

exposeModules();

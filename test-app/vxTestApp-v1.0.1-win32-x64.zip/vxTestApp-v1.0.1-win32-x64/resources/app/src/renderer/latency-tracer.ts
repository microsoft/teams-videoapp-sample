// types
import { RemoteClientHooks, RemoteClientMetrics } from '../remote-host/remote-client';

type MethodCounts = {
    count: number;
    duration: number;
    durationInHost: number;
};

type MessageCounts = {
    incomingMessage: number;
    outgoingMessage: number;
    outgoingMessageSync: number;
};

export class LatencyTracer implements RemoteClientHooks
{
    private _methods = new Map<string, MethodCounts>();
    private _messages: MessageCounts[] = [];
    private _totalMessages = LatencyTracer.makeMessageCounts();
    private _startTime = performance.now();

    private static roundTo(x: number, n: number) {
        return Math.round(x * Math.pow(10, n)) / Math.pow(10, n);
    }

    private static makeMethodCounts(): MethodCounts
    {
        return {
            count: 0,
            duration: 0,
            durationInHost: 0,
        };
    }

    private static makeMessageCounts(): MessageCounts
    {
        return {
            incomingMessage: 0,
            outgoingMessage: 0,
            outgoingMessageSync: 0,
        };
    }

    public incomingMessage() {
        this._getMessageBucket().incomingMessage += 1;
        this._totalMessages.incomingMessage += 1;
    }

    public outgoingMessage() {
        this._getMessageBucket().outgoingMessage += 1;
        this._totalMessages.outgoingMessage += 1;
    }

    public outgoingMessageSync() {
        this._getMessageBucket().outgoingMessageSync += 1;
        this._totalMessages.outgoingMessageSync += 1;
    }

    public require(module: string, metrics: RemoteClientMetrics) {
        this._addMethodCall(`require('${module}')`, metrics);
    }

    public functionConstructor(name: Object, metrics: RemoteClientMetrics) {
        this._addMethodCall(`new ${name || 'Function'}()`, metrics);
    }

    public functionCall(name: string, metrics: RemoteClientMetrics) {
        this._addMethodCall(`${name || 'Function'}()`, metrics);
    }

    public memberConstructor(target: Object, name: string, metrics: RemoteClientMetrics) {
        this._addMethodCall(`new ${target.constructor.name}::${name}()`, metrics);
    }

    public memberCall(target: Object, name: string, metrics: RemoteClientMetrics) {
        this._addMethodCall(`${target.constructor.name}::${name}()`, metrics);
    }

    public memberGet(target: Object, name: string, metrics: RemoteClientMetrics) {
        this._addMethodCall(`get ${target.constructor.name}::${name}`, metrics);
    }

    public memberSet(target: Object, name: string, metrics: RemoteClientMetrics) {
        this._addMethodCall(`set ${target.constructor.name}::${name}`, metrics);
    }

    public reset()
    {
        this._methods.clear();
        this._messages = [];
        this._totalMessages = LatencyTracer.makeMessageCounts();
        this._startTime = performance.now();
    }

    public dump()
    {
        console.group('IPC messages');
        console.table(this._messages);
        console.table(this._totalMessages);
        console.groupEnd();

        console.group('method calls');
        console.table(this._getMethodData());
        console.groupEnd();
    }

    private _getMessageBucket()
    {
        const timestamp = performance.now();
        const index = Math.floor((timestamp - this._startTime) / 1000);

        return this._messages[index] = this._messages[index] || LatencyTracer.makeMessageCounts();
    }

    private _addMethodCall(method: string, metrics: RemoteClientMetrics)
    {
        if (metrics.async) {
            method += ' async';
        }

        if (!this._methods.has(method)) {
            this._methods.set(method, LatencyTracer.makeMethodCounts());
        }

        const data = this._methods.get(method);

        data.count += 1;
        data.duration += metrics.duration || 0;
        data.durationInHost += metrics.durationInHost || 0;
    }

    private _getMethodData()
    {
        const result = {};

        for (const [method, data] of this._methods) {
            result[method] = {
                '# of calls': data.count,
                'total latency (avg)': LatencyTracer.roundTo(data.duration / data.count, 3),
                'native latency (avg)': LatencyTracer.roundTo(data.durationInHost / data.count, 3),
                'IPC overhead (avg)': LatencyTracer.roundTo((data.duration - data.durationInHost) / data.count, 3),
            };
        }

        return result;
    }
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class LatencyTracer {
    constructor() {
        this._methods = new Map();
        this._messages = [];
        this._totalMessages = LatencyTracer.makeMessageCounts();
        this._startTime = performance.now();
    }
    static roundTo(x, n) {
        return Math.round(x * Math.pow(10, n)) / Math.pow(10, n);
    }
    static makeMethodCounts() {
        return {
            count: 0,
            duration: 0,
            durationInHost: 0,
        };
    }
    static makeMessageCounts() {
        return {
            incomingMessage: 0,
            outgoingMessage: 0,
            outgoingMessageSync: 0,
        };
    }
    incomingMessage() {
        this._getMessageBucket().incomingMessage += 1;
        this._totalMessages.incomingMessage += 1;
    }
    outgoingMessage() {
        this._getMessageBucket().outgoingMessage += 1;
        this._totalMessages.outgoingMessage += 1;
    }
    outgoingMessageSync() {
        this._getMessageBucket().outgoingMessageSync += 1;
        this._totalMessages.outgoingMessageSync += 1;
    }
    require(module, metrics) {
        this._addMethodCall(`require('${module}')`, metrics);
    }
    functionConstructor(name, metrics) {
        this._addMethodCall(`new ${name || 'Function'}()`, metrics);
    }
    functionCall(name, metrics) {
        this._addMethodCall(`${name || 'Function'}()`, metrics);
    }
    memberConstructor(target, name, metrics) {
        this._addMethodCall(`new ${target.constructor.name}::${name}()`, metrics);
    }
    memberCall(target, name, metrics) {
        this._addMethodCall(`${target.constructor.name}::${name}()`, metrics);
    }
    memberGet(target, name, metrics) {
        this._addMethodCall(`get ${target.constructor.name}::${name}`, metrics);
    }
    memberSet(target, name, metrics) {
        this._addMethodCall(`set ${target.constructor.name}::${name}`, metrics);
    }
    reset() {
        this._methods.clear();
        this._messages = [];
        this._totalMessages = LatencyTracer.makeMessageCounts();
        this._startTime = performance.now();
    }
    dump() {
        console.group('IPC messages');
        console.table(this._messages);
        console.table(this._totalMessages);
        console.groupEnd();
        console.group('method calls');
        console.table(this._getMethodData());
        console.groupEnd();
    }
    _getMessageBucket() {
        const timestamp = performance.now();
        const index = Math.floor((timestamp - this._startTime) / 1000);
        return this._messages[index] = this._messages[index] || LatencyTracer.makeMessageCounts();
    }
    _addMethodCall(method, metrics) {
        if (metrics.async) {
            method += ' async';
        }
        if (!this._methods.has(method)) {
            this._methods.set(method, LatencyTracer.makeMethodCounts());
        }
        const data = this._methods.get(method);
        data.count += 1;
        data.duration += metrics.duration || 0;
        data.durationInHost += metrics.durationInHost || 0;
    }
    _getMethodData() {
        const result = {};
        for (const [method, data] of this._methods) {
            result[method] = {
                '# of calls': data.count,
                'total latency (avg)': LatencyTracer.roundTo(data.duration / data.count, 3),
                'native latency (avg)': LatencyTracer.roundTo(data.durationInHost / data.count, 3),
                'IPC overhead (avg)': LatencyTracer.roundTo((data.duration - data.durationInHost) / data.count, 3),
            };
        }
        return result;
    }
}
exports.LatencyTracer = LatencyTracer;
//# sourceMappingURL=latency-tracer.js.map
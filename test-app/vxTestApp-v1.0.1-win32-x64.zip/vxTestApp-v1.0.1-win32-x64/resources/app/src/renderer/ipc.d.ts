export interface MainWindowOptions {
    usePluginHost: boolean;
    enableTextureSharing: boolean;
    enableTextureUpload: boolean;
    enableWatchdog: boolean;
    pluginHostDirectChannel: boolean;
    pluginHostTracing: boolean;
    pluginHostLatencyTracing: boolean;
    pluginHostWatchdog: boolean;
    slimcoreStdoutLogging: boolean;
    slimcoreDataPath: string;
    slimcoreMediaLogsPath: string;
    decoupledTrouterClient: boolean;
    useTestAppSpecificECSPlatformID: boolean;
}

export interface PluginHostOptions {
    enableWatchdog: boolean;
    enableTracing: boolean;
    mainWindowId: number;
}

export const enum CompositorLayout {
    Vertical = 0,
    PictureInPicture = 1,
    NewsAnchor = 2,
}

export const enum RendererType {
    WebGL,
    Chromium,
}

export interface OpenPopupArgs {
    rendererType: RendererType;
    bufferName: string;
}

import { BrowserWindow, ipcMain, screen } from 'electron';
import * as fs from 'fs';
import { EventEmitter } from 'events';
import { SharingIndicator, displayVideoDeviceSetting } from 'slimcore/lib/sharing-indicator';
import { NativeRenderer } from 'slimcore/lib/native-renderer';
import { PluginHost } from './plugin-host';
import { IpcEventEmitter } from './ipc-event-emitter';
import * as utils from './utils';

// types
import { MainWindowOptions, OpenPopupArgs } from './renderer/ipc';

const kInitPluginHostTimeout = 1000 * 10;

type ConstructorArgs = {
    title: string;
    enableContextIsolation: boolean;
    enableSandbox: boolean;
    enableWatchdog: boolean;
    usePluginHost: boolean;
    preloadPluginHost: boolean;
    pluginHostDirectChannel: boolean;
    pluginHostTracing: boolean;
    pluginHostLatencyTracing: boolean;
    pluginHostWatchdog: boolean;
    slimcoreStdoutLogging: boolean;
    openMainWindowDevTools: boolean;
    openPluginHostDevTools: boolean;
    openBlankPage: boolean;
    decoupledTrouterClient: boolean;
    enableTextureSharing: boolean;
    enableTextureUpload: boolean;
    useTestAppSpecificECSPlatformID: boolean;
    isVideoExtensibilityTestApp: boolean;
};

export class MainWindow extends EventEmitter
{
    private _window: Electron.BrowserWindow = null;
    private _ipc: IpcEventEmitter = null;
    private _pluginHost: PluginHost = null;
    private _sharingIndicator: SharingIndicator = null;
    private _nativeRenderer: NativeRenderer = null;
    private _nextPopupId = 1;
    private _compositorWindow: Electron.BrowserWindow = null;

    public constructor(args: ConstructorArgs)
    {
        super();

        if (!args.isVideoExtensibilityTestApp) {
            this._window = new BrowserWindow({
                title: args.title,
                webPreferences: {
                    preload: utils.getPreloadPath('src/renderer/main-window/preload.js', args.enableSandbox),
                    allowVideoRendererInSandbox: true,
                    worldSafeExecuteJavaScript: true,
                    contextIsolation: args.enableContextIsolation,
                    sandbox: args.enableSandbox,
                    additionalArguments: ['--ms-renderer-type=main-window'],
                },
            });
        } else {
            ipcMain.on('video.sendMessagePortToMainWindow', (event: Electron.IpcMainEvent) => {
                const [port] = event.ports;
                this._window.webContents.postMessage('video.sendMessagePortToMainWindow', null, [port]);
            });

            this._window = new BrowserWindow({
                title: args.title,
                width: 1200,
                height: 900,
                webPreferences: {
                    preload: utils.getPreloadPath('src/renderer/video-extensibility/preload.js', args.enableSandbox),
                    allowVideoRendererInSandbox: true,
                    worldSafeExecuteJavaScript: true,
                    contextIsolation: false, // We need to expose Highcharts APIs to loaded page
                    sandbox: args.enableSandbox,
                    webviewTag: true,
                    additionalArguments: ['--ms-renderer-type=main-window'],
                },
            });

            this._window.webContents.on('will-attach-webview', (e, webPreferences, ps) => {
                webPreferences.preload = utils.getPreloadPath('src/renderer/video-extensibility/videoapp/preload.js', true);
                webPreferences.contextIsolation = true;
                webPreferences.allowVideoRendererInSandbox = true;
                webPreferences.allowVideoExtensibilityInSandbox = true;
                webPreferences.sandbox = true;
                webPreferences.worldSafeExecuteJavaScript = true;
                webPreferences.additionalArguments = ['--enable-precise-memory-info'];
            });
        }

        this._ipc = new IpcEventEmitter(this._webContents);

        utils.handleSync(this._ipc, 'get-options', () => {
            this._log('get-options');
            return this._getOptions(args);
        });

        utils.handleSync(this._ipc, 'get-preload-main-world', async () => {
            this._log('get-preload-main-world');
            return fs.promises.readFile(utils.getPreloadPath('src/renderer/main-window/preload-main-world.js', true), 'utf8');
        });

        utils.handleSync(this._ipc, 'init-plugin-host', () => {
            this._log('init-plugin-host');
            return this._initPluginHost(args);
        });

        this._ipc.on('open-popup', (event: Electron.IpcMainEvent, args: OpenPopupArgs) => {
            this._log('open-popup');
            event.returnValue = this._openPopup(args);
        });

        this._ipc.on('open-compositor', (event: Electron.IpcMainEvent) => {
            this._log('open-compositor');
            this._openCompositor();
            event.returnValue = true;
        });

        this._ipc.on('open-native-compositor', (event: Electron.IpcMainEvent) => {
            this._log('open-native-compositor');
            this._openNativeCompositor();
            this._log('leave event open-native-compositor');
            event.returnValue = true;
        });

        this._ipc.on('page-ready', (event: Electron.IpcMainEvent) => {
            this._log('page-ready');
        });

        this._ipc.on('video-extensibility-ready', (event: Electron.IpcMainEvent) => {
            this._log('video-extensibility-ready');
        });

        this._window.once('closed', () => {
            this._log('closed');
            this._window.removeAllListeners();
            this._window = null;
            this._ipc.removeAllListeners();
            this._ipc = null;
            this._hideSharingIndicator();
            this._destroyPluginHost();
            this.emit('closed');
        });

        this._webContents.on('render-process-gone', (event, details) => {
            this._log('render-process-gone', details);
            this._hideSharingIndicator();
            this._destroyPluginHost();
        });

        this._webContents.on('will-navigate', () => {
            this._log('will-navigate');
        });

        this._webContents.on('did-navigate', () => {
            this._log('did-navigate');
            this._hideSharingIndicator();
            this._destroyPluginHost();

            if (args.usePluginHost && args.preloadPluginHost) {
                try {
                    this._pluginHost = this._createPluginHost(args);
                }
                catch (error) {
                    this._log(`_createPluginHost failed: ${error}`);
                }
            }
        });

        this._webContents.on('did-finish-load', () => {
            this._log('did-finish-load');
        });

        this._webContents.on('did-fail-load', () => {
            this._log('did-fail-load');
        });

        this._ipc.on('native-renderer:start', (event: Electron.IpcMainEvent, nativeHandle: Buffer) => {
            this._log('_ipc.on(native-renderer:start)');
            if (this._nativeRenderer == null)
            {
                this._nativeRenderer = new NativeRenderer({
                    windowId: nativeHandle,
                });
            }
            event.returnValue = this._nativeRenderer.start();
        });

        this._ipc.on('native-renderer:stop', (event: Electron.IpcMainEvent, nativeHandle: Buffer) => {
            this._log('_ipc.on(native-renderer:stop)');
            if (this._nativeRenderer != null)
            {
                this._nativeRenderer.stop();
            }
        });

        this._ipc.on('sharing-indicator:show', (event: Electron.IpcMainEvent, position: SharingIndicator.Position) => {
            this._showSharingIndicator(position);
        });

        this._ipc.on('sharing-indicator:hide', (event: Electron.IpcMainEvent) => {
            this._hideSharingIndicator();
        });

        this._ipc.on('sharing-indicator:setPosition', (event: Electron.IpcMainEvent, position: SharingIndicator.Position) => {
            if (this._sharingIndicator) {
                this._sharingIndicator.setPosition(position);
            }
        });

        this._ipc.on('sharing-indicator:setWindow', (event: Electron.IpcMainEvent, windowId: number) => {
            if (this._sharingIndicator) {
                this._sharingIndicator.setWindow(windowId);
            }
        });

        this._ipc.on('sharing-indicator:displayVideoDeviceSetting', (event: Electron.IpcMainEvent, deviceId: string) => {
            const parentWindowHandle = this._window.getNativeWindowHandle();
            if (displayVideoDeviceSetting) {
                displayVideoDeviceSetting(parentWindowHandle, deviceId);
            }
        });

        this._ipc.on('create-regular-renderer', (event: Electron.IpcMainEvent, ...args: any[]) => {
            this._compositorWindow.webContents.send('create-regular-renderer', ...args);
        });

        this._ipc.on('create-compositor-renderer', (event: Electron.IpcMainEvent, ...args: any[]) => {
            this._compositorWindow.webContents.send('create-compositor-renderer', ...args);
        });

        this._log('loadURL');

        if (args.openBlankPage) {
            this._window.loadURL('about:blank');
        } else if (args.isVideoExtensibilityTestApp) {
            this._window.loadFile('src/renderer/video-extensibility/index.html');
        } else {
            this._window.loadFile('src/renderer/main-window/index.html');
        }

        if (args.openMainWindowDevTools) {
            this._webContents.openDevTools();
        }

        this._handleDisplaysChanged();
    }

    private get _webContents() {
        return this._window && this._window.webContents;
    }

    private _getOptions(args: ConstructorArgs): MainWindowOptions
    {
        return {
            usePluginHost: args.usePluginHost,
            enableTextureSharing: args.enableTextureSharing,
            enableTextureUpload: args.enableTextureUpload,
            enableWatchdog: args.enableWatchdog,
            pluginHostDirectChannel: args.pluginHostDirectChannel,
            pluginHostTracing: args.pluginHostTracing,
            pluginHostLatencyTracing: args.pluginHostLatencyTracing,
            pluginHostWatchdog: args.pluginHostWatchdog,
            slimcoreStdoutLogging: args.slimcoreStdoutLogging,
            slimcoreDataPath: utils.getUserDataPath('skylib'),
            slimcoreMediaLogsPath: utils.getUserDataPath('media-stack'),
            decoupledTrouterClient: args.decoupledTrouterClient,
            useTestAppSpecificECSPlatformID: args.useTestAppSpecificECSPlatformID,
        };
    }

    private _createPluginHost(args: ConstructorArgs)
    {
        return new PluginHost({
            enableWatchdog: args.enableWatchdog,
            enableTracing: args.pluginHostTracing,
            mainWindowId: this._webContents.id,
            openDevTools: args.openPluginHostDevTools,
        });
    }

    private async _initPluginHost(args: ConstructorArgs)
    {
        if (!this._pluginHost) {
            this._pluginHost = this._createPluginHost(args);
        }

        return this._pluginHost.waitForReady(kInitPluginHostTimeout);
    }

    private _destroyPluginHost()
    {
        if (this._pluginHost) {
            this._pluginHost.destroy();
            this._pluginHost = null;
        }
    }

    private _showSharingIndicator(position: SharingIndicator.Position)
    {
        this._hideSharingIndicator();
        this._sharingIndicator = new SharingIndicator({
            position: position,
            borderColor: { red: 1.0, green: 0.0, blue: 0.0, alpha: 1.0 },
            lineWidth: 5.0,
            modulePath: __dirname + '/../node_modules/slimcore',
        });
    }

    private _hideSharingIndicator()
    {
        if (this._sharingIndicator) {
            this._sharingIndicator.dispose();
            this._sharingIndicator = null;
        }
    }

    private _openPopup(args: OpenPopupArgs)
    {
        let popup = new BrowserWindow({
            webPreferences: {
                preload: utils.getPreloadPath('src/renderer/popup/preload.js', true),
                additionalArguments: ['--ms-renderer-type=popup'],
                allowVideoRendererInSandbox: true,
                enableRemoteModule: false,
                contextIsolation: true,
                worldSafeExecuteJavaScript: true,
                sandbox: true,
            },
        });

        popup.loadFile('src/renderer/popup/index.html', {
            hash: JSON.stringify(args),
        });

        const popupId = this._nextPopupId++;
        let popupIpc = new IpcEventEmitter(popup.webContents);

        utils.handleSync(popupIpc, 'get-preload-main-world', async () => {
            return fs.promises.readFile(utils.getPreloadPath('src/renderer/popup/preload-main-world.js', true), 'utf8');
        });

        popupIpc.on('frame-sink-invoke', (event: Electron.IpcMainEvent, method: string, ...args: any[]) => {
            this._webContents.send(`frame-sink-invoke-${popupId}`, method, ...args);
        });

        popup.once('closed', () => {
            this._webContents.send(`popup-closed-${popupId}`);
            popup = null;

            popupIpc.removeAllListeners();
            popupIpc.destroy();
            popupIpc = null;
        });

        return popupId;
    }

    private _openCompositor()
    {
        if (this._compositorWindow != null) return;
        this._compositorWindow = new BrowserWindow({
            webPreferences: {
                preload: utils.getPreloadPath('src/renderer/compositor-test/preload.js', false),
                additionalArguments: ['--ms-renderer-type=compositor-test'],
                allowVideoRendererInSandbox: true,
                sandbox: false,
            },
        });

        this._compositorWindow.loadFile('src/renderer/compositor-test/index.html');
        let popupIpc = new IpcEventEmitter(this._compositorWindow.webContents);

        popupIpc.on('compositor-frame-sink-invoke', (event: Electron.IpcMainEvent, bufferName: string, method: string, ...args: any[]) => {
            this._webContents.send(`compositor-frame-sink-invoke`, bufferName, method, ...args);
        });

        popupIpc.on('compositor-view-update', (event: Electron.IpcMainEvent, bufferName: string, id: number, x: number, y: number, w: number, h: number) => {
            this._webContents.send('compositor-view-update', bufferName, id, x, y, w, h);
        });

        popupIpc.on('compositor-update', (event: Electron.IpcMainEvent, w: number, h: number) => {
            this._webContents.send('compositor-update', 0, 0, w, h);
        });

        popupIpc.on('compositor-window-ready', (event: Electron.IpcMainEvent) => {
            this._log(`compositor-window-ready ${this._compositorWindow.webContents}`);
            this._webContents.send('compositor-window-ready');
        });

        this._compositorWindow.once('closed', () => {
            this._webContents.send(`compositor-closed`);
            this._compositorWindow = null;

            popupIpc.removeAllListeners();
            popupIpc.destroy();
            popupIpc = null;
        });
    }

    private _openNativeCompositor()
    {
        if (this._compositorWindow != null) return;
        this._compositorWindow = new BrowserWindow({
            webPreferences: {
                preload: utils.getPreloadPath('src/renderer/native-compositor/preload.js', false),
                sandbox: false,
            },
            backgroundColor: '#00aaaaaa',
        });
        this._compositorWindow.loadFile('src/renderer/native-compositor/index.html');

        let popupIpc = new IpcEventEmitter(this._compositorWindow.webContents);

        popupIpc.on('compositor-view-update', (event: Electron.IpcMainEvent, bufferName: string, id: number, x: number, y: number, w: number, h: number) => {
            this._webContents.send('compositor-view-update', bufferName, id, x, y, w, h);
        });

        popupIpc.on('compositor-update', (event: Electron.IpcMainEvent, x: number, y: number, w: number, h: number) => {
            this._webContents.send('compositor-update', x, y, w, h);
        });

        popupIpc.on('compositor-window-ready', (event: Electron.IpcMainEvent) => {
            this._log(`compositor-window-ready ${this._compositorWindow.webContents}`);
            this._webContents.send('compositor-window-ready', this._compositorWindow.getNativeWindowHandle());
        });

        this._compositorWindow.once('closed', () => {
            this._webContents.send(`compositor-closed`);
            this._compositorWindow = null;

            popupIpc.removeAllListeners();
            popupIpc.destroy();
            popupIpc = null;
        });
    }

    private _handleDisplaysChanged()
    {
        const handleDisplaysChanged = () => {
            if (this._webContents) {
                this._webContents.send('displays-changed');
            }
        };

        screen.on('display-added', handleDisplaysChanged);
        screen.on('display-removed', handleDisplaysChanged);
        screen.on('display-metrics-changed', handleDisplaysChanged);
    }

    private _log(message: string, ...args: any[])
    {
        utils.log(`MainWindow - ${message}`, ...args);
    }
}

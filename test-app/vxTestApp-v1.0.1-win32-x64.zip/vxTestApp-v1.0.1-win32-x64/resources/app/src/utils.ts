import * as path from 'path';
import { app } from 'electron';
import { IpcEventEmitter } from './ipc-event-emitter';

export type Deferred<T> = {
    promise: Promise<T>;
    resolve(value?: T): void;
    reject(error?: Error): void;
};

export function defer<T>(): Deferred<T>
{
    let resolve;
    let reject;

    // tslint:disable-next-line: promise-must-complete
    const promise = new Promise<T>((resolveFn, rejectFn) => {
        resolve = resolveFn;
        reject = rejectFn;
    });

    return { promise, resolve, reject };
}

export function log(...args: any[])
{
    console.log((new Date()).toISOString(), ...args);
}

export function getPreloadPath(filename: string, sandbox = false)
{
    const pathObject = path.parse(getAppFilePath(filename));

    return path.format({
        dir: pathObject.dir,
        name: `${pathObject.name}${sandbox ? '-bundle' : ''}`,
        ext: pathObject.ext,
    });
}

export function getAppFilePath(filename: string)
{
    return path.resolve(app.getAppPath(), filename);
}

export function getUserDataPath(filename: string)
{
    return path.resolve(app.getPath('userData'), filename);
}

type IpcHandler = (event: Electron.IpcMainEvent, ...args: any[]) => any;

export function handleSync<T extends IpcHandler>(emitter: IpcEventEmitter, channel: string, handler: T)
{
    emitter.on(channel, async (event, ...args) =>
    {
        try {
            event.returnValue = [null, await handler(event, ...args)];
        } catch (error) {
            event.returnValue = [error];
        }
    });
}

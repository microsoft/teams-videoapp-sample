import { app, Menu } from 'electron';
import { MainWindow } from './main-window';
import { menu } from './menu';

const { hasSwitch } = app.commandLine;

app.commandLine.appendSwitch('enable-features', 'ContextBridgeMutability');

let mainWindow: MainWindow;

if (hasSwitch('sanity-check')) {
    try {
        module.require('slimcore');
        module.require('slimcore/lib/platform');
        module.require('slimcore/lib/sharing-indicator');
        module.require('slimcore/lib/native-renderer');
        module.require('slimcore/lib/trouter-client');
        process.exit(0);
    }
    catch (error) {
        console.error(`${error}`);
        process.exit(1);
    }
}

app.on('window-all-closed', () => {
    app.quit();
});

app.on('ready', () =>
{
    Menu.setApplicationMenu(menu);

    // const isVideoExtensibilityTestApp = hasSwitch('video-extensibility');
    const isVideoExtensibilityTestApp = true;

    mainWindow = new MainWindow({
        title: isVideoExtensibilityTestApp ? 'Video Extensibility Test App' : 'SlimCore test',
        enableContextIsolation: hasSwitch('main-window-context-isolation'),
        enableSandbox: hasSwitch('main-window-sandbox'),
        enableWatchdog: hasSwitch('main-window-watchdog'),
        usePluginHost: hasSwitch('use-plugin-host'),
        preloadPluginHost: hasSwitch('preload-plugin-host'),
        pluginHostDirectChannel: hasSwitch('plugin-host-direct-channel'),
        pluginHostTracing: hasSwitch('plugin-host-tracing'),
        pluginHostLatencyTracing: hasSwitch('plugin-host-latency-tracing'),
        pluginHostWatchdog: hasSwitch('plugin-host-watchdog'),
        slimcoreStdoutLogging: hasSwitch('slimcore-stdout-logging'),
        openMainWindowDevTools: hasSwitch('open-main-window-devtools'),
        openPluginHostDevTools: hasSwitch('open-plugin-host-devtools'),
        openBlankPage: hasSwitch('open-blank-page'),
        decoupledTrouterClient: hasSwitch('decoupled-trouter-client'),
        enableTextureSharing: hasSwitch('enable-texture-sharing'),
        enableTextureUpload: hasSwitch('enable-texture-upload'),
        useTestAppSpecificECSPlatformID: hasSwitch('use-test-app-specific-ecs-platform-id'),
        isVideoExtensibilityTestApp: isVideoExtensibilityTestApp,
    });

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
});

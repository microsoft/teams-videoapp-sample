import { app, shell, Menu, MenuItemConstructorOptions } from 'electron';

function isMac() {
    return process.platform === 'darwin';
}

const appMenu: MenuItemConstructorOptions =
{
    label: 'Electron',
    submenu: [
        {
            role: 'about',
        },
        {
            type: 'separator',
        },
        {
            role: 'services',
            submenu: [],
        },
        {
            type: 'separator',
        },
        {
            role: 'hide',
        },
        {
            role: 'hideOthers',
        },
        {
            role: 'unhide',
        },
        {
            type: 'separator',
        },
        {
            role: 'quit',
        },
    ],
};

const fileMenu: MenuItemConstructorOptions =
{
    label: 'File',
    submenu: [
    {
        role: 'quit',
    }],
};

const editMenu: MenuItemConstructorOptions =
{
    label: 'Edit',
    submenu: [
        {
            role: 'undo',
        },
        {
            role: 'redo',
        },
        {
            type: 'separator',
        },
        {
            role: 'cut',
        },
        {
            role: 'copy',
        },
        {
            role: 'paste',
        },
        {
            role: 'pasteAndMatchStyle',
        },
        {
            role: 'delete',
        },
        {
            role: 'selectAll',
        },
    ],
};

const viewMenu: MenuItemConstructorOptions =
{
    label: 'View',
    submenu: [
        {
            role: 'reload',
        },
        {
            role: 'forceReload',
        },
        {
            role: 'toggleDevTools',
        },
        {
            type: 'separator',
        },
        {
            role: 'resetZoom',
        },
        {
            role: 'zoomIn',
        },
        {
            role: 'zoomOut',
        },
        {
            type: 'separator',
        },
        {
            role: 'togglefullscreen',
        },
    ],
};

const windowMenu: MenuItemConstructorOptions =
{
    role: 'window',
    submenu: isMac()
    ? [
        {
            role: 'close',
        },
        {
            role: 'minimize',
        },
        {
            role: 'zoom',
        },
        {
            type: 'separator',
        },
        {
            role: 'front',
        },
    ]
    : [
        {
            role: 'minimize',
        },
        {
            role: 'close',
        },
    ],
};

const helpMenu: MenuItemConstructorOptions =
{
    role: 'help',
    submenu: [
        {
            label: 'Electron',
            click() {
                shell.openExternal('https://electronjs.org');
            },
        },
        {
            label: 'SlimCoreElectron',
            click() {
                shell.openExternal('https://skype.visualstudio.com/DefaultCollection/SCC/_git/client-shared_electron_slimcore');
            },
        },
        {
            type: 'separator',
        },
        {
            label: 'Open userData path',
            click() {
                shell.openPath(app.getPath('userData'));
            },
        },
    ],
};

export const menu = Menu.buildFromTemplate([
    isMac() ? appMenu : fileMenu,
    editMenu,
    viewMenu,
    windowMenu,
    helpMenu,
]);

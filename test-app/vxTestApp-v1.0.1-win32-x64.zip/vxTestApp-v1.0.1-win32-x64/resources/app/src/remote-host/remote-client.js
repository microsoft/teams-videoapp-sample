"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const callbacks_registry_1 = require("./lib/callbacks-registry");
const ipcMessages = require("./lib/ipc-messages");
const utils = require("./lib/utils");
class RemoteClient extends events_1.EventEmitter {
    constructor(host, options) {
        super();
        this.host = host;
        this.hooks = {};
        this.callbacksRegistry = new callbacks_registry_1.CallbacksRegistry();
        this.remoteObjectCache = new Map();
        this.electronIds = new WeakMap();
        this.enableTracing = false;
        this.enableOptimizationConstant = true;
        this.enableOptimizationPromise = true;
        this.enableOptimizationVoid = true;
        this.enableOptimizationSimpleArgs = true;
        this._usingDirectChannel = false;
        this.enableTracing = !!options.enableTracing;
        this.finalizationRegistry = new FinalizationRegistry((id) => {
            const ref = this.remoteObjectCache.get(id);
            if (ref !== undefined && ref.deref() === undefined) {
                this.remoteObjectCache.delete(id);
                this.send(ipcMessages.remoteServerDereference, id);
            }
        });
        if (options.enableDirectChannel) {
            try {
                this.host.on('ms-connect-event', (event, connected) => {
                    if (this.enableTracing) {
                        console.log(`ms-connect-event: ${connected}`);
                    }
                    this._usingDirectChannel = connected;
                    this.emit('using-direct-channel-changed', this.usingDirectChannel);
                    if (connected) {
                        this.send(ipcMessages.remoteServerConnect);
                    }
                });
                this.host.connect();
            }
            catch (error) {
                if (this.enableTracing) {
                    console.log(`connectToRenderer failed: ${error}`);
                }
            }
        }
        // Host calls a callback in renderer.
        this.handleMessage(ipcMessages.remoteClientCallbackInvoke, (id, args) => {
            this.callbacksRegistry.apply(id, this.metaToValue(args));
        });
        // A callback in host is released.
        this.handleMessage(ipcMessages.remoteClientCallbackRelease, (id) => {
            this.callbacksRegistry.remove(id);
        });
        process.on('exit', () => {
            this.send(ipcMessages.remoteServerContextRelease);
        });
    }
    get usingDirectChannel() {
        return this._usingDirectChannel;
    }
    require(module) {
        const api = `remote-client: require() / ${module}`;
        const [meta, metrics] = this.sendSync(ipcMessages.remoteServerRequire, [module], api);
        if (this.hooks && this.hooks.require) {
            this.hooks.require(module, metrics);
        }
        return this.metaToValue(meta);
    }
    getCachedRemoteObject(id) {
        const ref = this.remoteObjectCache.get(id);
        if (ref !== undefined) {
            const deref = ref.deref();
            if (deref !== undefined)
                return deref;
        }
    }
    setCachedRemoteObject(id, value) {
        const wr = new WeakRef(value);
        this.remoteObjectCache.set(id, wr);
        this.finalizationRegistry.register(value, id);
        return value;
    }
    handleMessage(channel, handler) {
        this.host.on(channel, ({ isDirectChannel }, passedContextId, ...args) => {
            if (this.hooks.incomingMessage) {
                this.hooks.incomingMessage(channel);
            }
            if (this.enableTracing) {
                console.group('handleMessage', channel);
                console.log('hostId:', this.host.id, 'isDirectChannel:', isDirectChannel, 'contextId:', passedContextId, 'args:', ...args);
            }
            if (passedContextId === this.host.contextId) {
                handler(...args);
            }
            if (this.enableTracing) {
                console.groupEnd();
            }
        });
    }
    send(command, ...args) {
        if (this.hooks.outgoingMessage) {
            this.hooks.outgoingMessage(command);
        }
        if (this.enableTracing) {
            console.group('sendTo', command);
            console.log('hostId:', this.host.id, 'contextId:', this.host.contextId, 'args:', ...args);
        }
        const timeStart = utils.now();
        this.host.send(command, [this.host.contextId, ...args]);
        const duration = utils.now() - timeStart;
        if (this.enableTracing) {
            console.log('duration:', utils.precise(duration));
            console.groupEnd();
        }
        return { duration, async: true };
    }
    sendSync(command, args, api) {
        if (this.hooks.outgoingMessageSync) {
            this.hooks.outgoingMessageSync(command);
        }
        if (this.enableTracing) {
            console.group('sendToSync', command);
            console.log('hostId:', this.host.id, 'contextId:', this.host.contextId, 'args:', ...args);
        }
        const timeStart = utils.now();
        const [result, durationInHost] = this.host.sendSync(command, [this.host.contextId, ...args], api);
        const duration = utils.now() - timeStart;
        if (this.enableTracing) {
            console.log('duration:', utils.precise(duration), 'durationInHost:', utils.precise(durationInHost), 'result:', result);
            console.groupEnd();
        }
        return [result, { duration, durationInHost }];
    }
    // Convert the arguments object into an array of meta data.
    wrapArgs(args, simple = false, visited = new Set()) {
        if (simple) {
            return args.map((value) => ({
                type: 'value',
                value: value,
            }));
        }
        const valueToMeta = (value) => {
            // Check for circular reference.
            if (visited.has(value)) {
                return {
                    type: 'value',
                    value: null,
                };
            }
            if (Array.isArray(value)) {
                visited.add(value);
                const meta = {
                    type: 'array',
                    value: this.wrapArgs(value, simple, visited),
                };
                visited.delete(value);
                return meta;
            }
            else if (value instanceof Buffer) {
                return {
                    type: 'buffer',
                    value,
                };
            }
            else if (utils.isSerializableObject(value)) {
                return {
                    type: 'value',
                    value,
                };
            }
            else if (typeof value === 'object') {
                if (utils.isPromise(value)) {
                    return {
                        type: 'promise',
                        then: valueToMeta((onFulfilled, onRejected) => {
                            value.then(onFulfilled, onRejected);
                        }),
                    };
                }
                else if (this.electronIds.has(value)) {
                    return {
                        type: 'remote-object',
                        id: this.electronIds.get(value),
                    };
                }
                const meta = {
                    type: 'object',
                    name: value.constructor ? value.constructor.name : '',
                    members: [],
                };
                visited.add(value);
                // tslint:disable-next-line
                for (const prop in value) {
                    meta.members.push({
                        name: prop,
                        value: valueToMeta(value[prop]),
                    });
                }
                visited.delete(value);
                return meta;
            }
            else if (typeof value === 'function') {
                return {
                    type: 'function',
                    id: this.callbacksRegistry.add(value),
                    length: value.length,
                };
            }
            else {
                return {
                    type: 'value',
                    value,
                };
            }
        };
        return args.map(valueToMeta);
    }
    // Populate object's members from descriptors.
    // The |ref| will be kept referenced by |members|.
    // This matches |getObjectMemebers| in rpc-server.
    setObjectMembers(ref, object, metaId, members) {
        if (!Array.isArray(members))
            return;
        for (const member of members) {
            if (Object.prototype.hasOwnProperty.call(object, member.name))
                continue;
            const descriptor = { enumerable: member.enumerable };
            if (member.type === 'method') {
                const remoteMemberFunction = this.makeRemoteMemberFunction(ref, metaId, member);
                let descriptorFunction = this.proxyFunctionProperties(remoteMemberFunction, ref, metaId, member.name);
                descriptor.get = () => {
                    descriptorFunction.ref = ref; // The member should reference its object.
                    return descriptorFunction;
                };
                // Enable monkey-patch the method
                descriptor.set = (value) => {
                    descriptorFunction = value;
                    return value;
                };
                descriptor.configurable = true;
            }
            else if (member.type === 'get') {
                descriptor.get = this.makePropertyGetter(ref, metaId, member);
                if (member.writable) {
                    descriptor.set = this.makePropertySetter(ref, metaId, member);
                }
            }
            else if (member.type === 'value') {
                descriptor.value = member.value;
                descriptor.writable = member.writable;
            }
            Object.defineProperty(object, member.name, descriptor);
        }
    }
    // Populate object's prototype from descriptor.
    // This matches |getObjectPrototype| in rpc-server.
    setObjectPrototype(ref, object, metaId, descriptor) {
        if (descriptor === null)
            return;
        const proto = {};
        this.setObjectMembers(ref, proto, metaId, descriptor.members);
        this.setObjectPrototype(ref, proto, metaId, descriptor.proto);
        Object.setPrototypeOf(object, proto);
    }
    // Wrap function in Proxy for accessing remote properties
    proxyFunctionProperties(remoteMemberFunction, target, metaId, name) {
        let loaded = false;
        // Lazily load function properties
        const loadRemoteProperties = () => {
            if (loaded)
                return;
            loaded = true;
            const api = `remote-client: get ${getClassName(target)}.${name}`;
            const [meta, metrics] = this.sendSync(ipcMessages.remoteServerMemberGet, [metaId, name], api);
            if (this.hooks.memberGet) {
                this.hooks.memberGet(target, name, metrics);
            }
            this.setObjectMembers(remoteMemberFunction, remoteMemberFunction, meta.id, meta.members);
        };
        return new Proxy(remoteMemberFunction, {
            set: (target, property, value) => {
                if (property !== 'ref')
                    loadRemoteProperties();
                target[property] = value;
                return true;
            },
            get: (target, property) => {
                if (!Object.prototype.hasOwnProperty.call(target, property))
                    loadRemoteProperties();
                const value = target[property];
                if (property === 'toString' && typeof value === 'function') {
                    return value.bind(target);
                }
                return value;
            },
            ownKeys: (target) => {
                loadRemoteProperties();
                return Object.getOwnPropertyNames(target);
            },
            getOwnPropertyDescriptor: (target, property) => {
                const descriptor = Object.getOwnPropertyDescriptor(target, property);
                if (descriptor)
                    return descriptor;
                loadRemoteProperties();
                return Object.getOwnPropertyDescriptor(target, property);
            },
        });
    }
    makePropertyGetter(target, metaId, member) {
        return () => {
            const api = `remote-client: get ${getClassName(target)}.${member.name}`;
            const [result, metrics] = this.sendSync(ipcMessages.remoteServerMemberGet, [metaId, member.name], api);
            if (this.hooks.memberGet) {
                this.hooks.memberGet(target, member.name, metrics);
            }
            return this.metaToValue(result);
        };
    }
    makePropertySetter(target, metaId, member) {
        return (value) => {
            const args = this.wrapArgs([value]);
            const api = `remote-client: set ${getClassName(target)}.${member.name}`;
            const [result, metrics] = this.sendSync(ipcMessages.remoteServerMemberSet, [metaId, member.name, args], api);
            if (this.hooks.memberSet) {
                this.hooks.memberSet(target, member.name, metrics);
            }
            if (result != null)
                this.metaToValue(result);
            return value;
        };
    }
    makeRemoteMemberFunction(target, metaId, member) {
        // tslint:disable-next-line
        const self = this;
        const remoteMemberFunction = function (...args) {
            // tslint:disable-next-line:no-invalid-this
            const isConstructCall = this && this.constructor === remoteMemberFunction;
            const simpleArgs = self.enableOptimizationSimpleArgs && member.simpleArgs;
            if (!isConstructCall) {
                if (self.enableOptimizationVoid && member.returnType === 'void') {
                    const metrics = self.send(ipcMessages.remoteServerMemberCallAsync, metaId, member.name, self.wrapArgs(args, simpleArgs));
                    if (self.hooks.memberCall) {
                        self.hooks.memberCall(target, member.name, metrics);
                    }
                    return;
                }
                else if (self.enableOptimizationPromise && member.returnType === 'promise') {
                    return new Promise((resolve, reject) => {
                        args.push((error, result) => {
                            if (error) {
                                reject(error);
                            }
                            else {
                                resolve(result);
                            }
                        });
                        const metrics = self.send(ipcMessages.remoteServerMemberCallAsync, metaId, member.name, self.wrapArgs(args, simpleArgs));
                        if (self.hooks.memberCall) {
                            self.hooks.memberCall(target, member.name, metrics);
                        }
                    });
                }
            }
            const command = isConstructCall
                ? ipcMessages.remoteServerMemberConstructor
                : ipcMessages.remoteServerMemberCall;
            const api = `remote-client: ${isConstructCall ? 'new' : 'call'} ${getClassName(target)}.${member.name}()`;
            const [result, metrics] = self.sendSync(command, [metaId, member.name, self.wrapArgs(args, simpleArgs)], api);
            if (isConstructCall) {
                if (self.hooks.memberConstructor) {
                    self.hooks.memberConstructor(target, member.name, metrics);
                }
            }
            else {
                if (self.hooks.memberCall) {
                    self.hooks.memberCall(target, member.name, metrics);
                }
            }
            return self.metaToValue(result);
        };
        if (this.enableOptimizationConstant && member.returnType === 'constant') {
            return this.cacheReturnValue(remoteMemberFunction);
        }
        return remoteMemberFunction;
    }
    makeRemoteFunction(meta) {
        // tslint:disable-next-line
        const self = this;
        const remoteFunction = function (...args) {
            // tslint:disable-next-line:no-invalid-this
            const isConstructCall = this && this.constructor === remoteFunction;
            const simpleArgs = self.enableOptimizationSimpleArgs && meta.simpleArgs;
            if (!isConstructCall) {
                if (self.enableOptimizationVoid && meta.returnType === 'void') {
                    const metrics = self.send(ipcMessages.remoteServerFunctionCallAsync, meta.id, self.wrapArgs(args, simpleArgs));
                    if (self.hooks.functionCall) {
                        self.hooks.functionCall(meta.name, metrics);
                    }
                    return;
                }
                else if (self.enableOptimizationPromise && meta.returnType === 'promise') {
                    return new Promise((resolve, reject) => {
                        args.push((error, result) => {
                            if (error) {
                                reject(error);
                            }
                            else {
                                resolve(result);
                            }
                        });
                        const metrics = self.send(ipcMessages.remoteServerFunctionCallAsync, meta.id, self.wrapArgs(args, simpleArgs));
                        if (self.hooks.functionCall) {
                            self.hooks.functionCall(meta.name, metrics);
                        }
                    });
                }
            }
            const command = isConstructCall
                ? ipcMessages.remoteServerConstructor
                : ipcMessages.remoteServerFunctionCall;
            const api = `remote-client: ${isConstructCall ? 'new' : 'call'} ${meta.name}()`;
            const [result, metrics] = self.sendSync(command, [meta.id, self.wrapArgs(args, simpleArgs)], api);
            if (isConstructCall) {
                if (self.hooks.functionConstructor) {
                    self.hooks.functionConstructor(meta.name, metrics);
                }
            }
            else {
                if (self.hooks.functionCall) {
                    self.hooks.functionCall(meta.name, metrics);
                }
            }
            return self.metaToValue(result);
        };
        if (this.enableOptimizationConstant && meta.returnType === 'constant') {
            return this.cacheReturnValue(remoteFunction);
        }
        return remoteFunction;
    }
    cacheReturnValue(func) {
        let value;
        let cached = false;
        // tslint:disable-next-line:no-invalid-this
        return function (...args) {
            if (!cached) {
                // tslint:disable-next-line:no-invalid-this
                value = func.apply(this, args);
                cached = true;
            }
            return value;
        };
    }
    // Convert meta data from host into real value.
    metaToValue(meta) {
        if (meta.type === 'value') {
            return meta.value;
        }
        else if (meta.type === 'array') {
            return meta.members.map((member) => this.metaToValue(member));
        }
        else if (meta.type === 'buffer') {
            return Buffer.from(meta.value.buffer, meta.value.byteOffset, meta.value.byteLength);
        }
        else if (meta.type === 'promise') {
            return Promise.resolve({ then: this.metaToValue(meta.then) });
        }
        else if (meta.type === 'exception') {
            throw this.metaToValue(meta.value);
        }
        let ret;
        const cached = this.getCachedRemoteObject(meta.id);
        if (cached !== undefined) {
            return cached;
        }
        // A shadow class to represent the remote function object.
        if (meta.type === 'function') {
            ret = this.makeRemoteFunction(meta);
        }
        else {
            ret = {};
        }
        this.setObjectMembers(ret, ret, meta.id, meta.members);
        this.setObjectPrototype(ret, ret, meta.id, meta.proto);
        Object.defineProperty(ret.constructor, 'name', { value: meta.constructorName });
        // Track delegate obj's lifetime & tell host to clean up when object is GCed.
        this.electronIds.set(ret, meta.id);
        this.setCachedRemoteObject(meta.id, ret);
        return ret;
    }
}
exports.RemoteClient = RemoteClient;
function getClassName(obj) {
    return obj.constructor ? obj.constructor.name : '<object>';
}
//# sourceMappingURL=remote-client.js.map